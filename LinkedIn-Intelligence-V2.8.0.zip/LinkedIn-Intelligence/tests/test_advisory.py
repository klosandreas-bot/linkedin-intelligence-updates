"""Minimal smoketest: production modules import without personal data."""
import unittest

class DistributionSmokeTest(unittest.TestCase):
    def test_importable(self):
        import analytics, advisory, updater
        self.assertEqual(updater.local_version(), '2.8.0')
