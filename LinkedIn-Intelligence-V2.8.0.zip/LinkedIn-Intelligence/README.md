# LinkedIn Intelligence V2.8

Lokales Windows-Dashboard zur Auswertung eigener LinkedIn-Daten. Keine Verbindung zu LinkedIn ohne eigene Autorisierung.

1. Python 3.11 oder neuer installieren.
2. Dieses ZIP in einen eigenen Ordner entpacken.
3. `Start-Dashboard.bat` doppelklicken.
4. Eigenen LinkedIn-ZIP-Export importieren oder den eigenen DMA-API-Zugriff einrichten.
5. Unter „Datenquellen & Abruf“ die Datenstände pro Bereich ansehen.

Seit V2.4 werden bei jedem Start signierte Softwareupdates von GitHub geprüft. Lokale SQLite-Daten, Exporte, Token und persönliche Berichte bleiben unverändert. Für die initiale Installation sind keine fremden Entwicklerzugangsdaten erforderlich.

Neu in V2.7: echte Versionsanzeige aus `version.json`, exakte Dublettenbereinigung bei Kennzahlen, Datenstand pro Bereich mit Quelle und letztem erfolgreichen Import, letzte API-Prüfung separat, Zeitanzeige in MEZ/MESZ sowie die Bezeichnung „Bericht für KI Auswertung / GitHub“.

Eine Zeile wird nur dann bei den Kennzahlen zusammengefasst, wenn ihr JSON-Inhalt vollständig identisch ist. Ähnliche Ereignisse werden nicht allein nach Namen oder Datum zusammengelegt. Originaldateien und gespeicherte Snapshots bleiben vollständig erhalten. Für Kontakte wird die Anzahl unterschiedlicher Kennungen getrennt ausgewiesen.

Scoring-Daten sind interne LinkedIn-Modellwerte, keine veröffentlichten Feed-Rankingfaktoren. Dieses Projekt ist unabhängig von LinkedIn.


## V2.8 – Reichweite & Diskussion

Die neue Seite „Reichweite & Diskussion“ importiert den offiziellen LinkedIn-Einzelbeitrags-Excel-Export (XLSX, Spalten A/B) lokal. Für eigene Unternehmensseitenbeiträge und Screenshots können Messstände manuell erfasst werden. Erfasste Beobachtungen werden separat in der lokalen SQLite-Datenbank gespeichert; die Rohdaten-/API-Snapshots bleiben unverändert.

Erst **zwei Messstände desselben Beitrags** erlauben Aussagen über dessen zeitlichen Verlauf. Die Analyse benennt beobachtete Veränderungen, behauptet aber weder Algorithmus-Sanktionen noch die Ursache einer geringen Ausspielung. Die fachliche Qualität von Kommentaren, die Zahl neuer Diskussionsteilnehmer und eigene Kommentare werden nur bei ausdrücklich erfassten Angaben berücksichtigt. Persönliche Bekanntschaften werden niemals als Gefälligkeitsreaktionen abgewertet.

Die persönliche Member Data Portability API liefert nicht zuverlässig Kommentare anderer Mitglieder unter eigenen Beiträgen und keine allgemeinen Unternehmensseiten-Analysen. Der Monitor versendet keine Messwerte an GitHub; sie sind auch nicht Bestandteil des kuratierten Berichtsexports.
