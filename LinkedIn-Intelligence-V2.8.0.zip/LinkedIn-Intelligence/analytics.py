"""Curated analytics, exact-topic scoring comparison, no unsupported causal claims."""
from __future__ import annotations
import collections, datetime as dt, json, re
from storage import ROOT,snapshot_list,latest_domain,scores_history
from advisory import advise, fingerprint, distinct_rows

DIMENSIONS=['Role and scope','Tenure and experience','Content and output','Education and credentials','Validation and influence']
TERMS={'PPWR':r'\bPPWR\b','EUDR':r'\bEUDR\b','CBAM':r'\bCBAM\b',
       'CSRD':r'\bCSRD\b','CSDDD':r'\b(?:CSDDD|CS3D)\b',
       'EmpCo':r'\b(?:EmpCo|Green Claims)\b','FLR':r'\bFLR\b',
       'ESPR/DPP':r'\b(?:ESPR|DPP)\b','Steuern':r'\b(?:Steuer|Wertschöpfung|Steuern)\w*'}


def as_rows(rows):
    if isinstance(rows,dict): return [rows]
    return rows if isinstance(rows,list) else []


def profile_info(cx,until=None):
    profile=distinct_rows(as_rows(latest_domain(cx,'PROFILE',until)))
    positions=distinct_rows(as_rows(latest_domain(cx,'POSITIONS',until)))
    skills=distinct_rows(as_rows(latest_domain(cx,'SKILLS',until)))
    ed=distinct_rows(as_rows(latest_domain(cx,'EDUCATION',until)))
    return {'profile':profile[0] if profile else {},'positions':positions,
            'skills':[r.get('Name',r) if isinstance(r,dict) else r for r in skills],
            'education':ed,'skill_count':len(skills),'position_count':len(positions)}


def score_info(cx,until=None):
    rows=scores_history(cx,until)
    grouped=collections.defaultdict(dict)
    notability=[]; normalized=[]; topics=[]
    for r in rows:
        typ=r['score_type']; topic=r['topic'];cat=r['category'];date=r['measured_at']
        if typ=='Notability':
            notability.append(r)
        elif cat=='Topic normalized score':normalized.append(r)
        elif cat in DIMENSIONS:topics.append(r)
    latest={}
    for r in topics:
        key=(r['topic'],r['category'])
        if key not in latest or r['measured_at']>latest[key]['measured_at']:latest[key]=r
    for (topic,cat),r in latest.items():grouped[topic][cat]={'score':r['value'],'date':r['measured_at']}
    latest_norm={}
    for r in normalized:
        key=r['topic']
        if key not in latest_norm or r['measured_at']>latest_norm[key]['measured_at']:latest_norm[key]=r
    def last(cat):
        matches=[r for r in notability if r['category']==cat]
        return max(matches,key=lambda r:r['measured_at']) if matches else None
    ns=last('Aggregated notability score');nt=last('Discrete notability tier')
    return {'dimensions':DIMENSIONS,'topics':[{'name':k,'dimensions':v} for k,v in sorted(grouped.items())],
            'top_knowledge':[{'topic':r['topic'],'score':r['value'],'date':r['measured_at']}
                             for r in sorted(latest_norm.values(),key=lambda r:-r['value'])[:25]],
            'notability':{'score':ns['value'] if ns else None,'date':ns['measured_at'] if ns else None,
                           'tier':nt['value'] if nt else None},
            'history':sorted([r for r in topics+notability+normalized if r['category'] in DIMENSIONS or
                              r['category'] in ['Aggregated notability score','Discrete notability tier']],
                              key=lambda r:(r['measured_at'],r['topic'],r['category'])),
            'point_count':len(rows),'measured_through':max((r['measured_at'] for r in rows),default=None)}


def net_info(cx,until=None):
    raw_connections=as_rows(latest_domain(cx,'CONNECTIONS',until))
    con=distinct_rows(raw_connections)
    raw_invites=as_rows(latest_domain(cx,'INVITATIONS',until))
    invites=distinct_rows(raw_invites)
    sent=sum(1 for r in invites if isinstance(r,dict) and str(r.get('Direction','')).upper()=='OUTGOING')
    received=sum(1 for r in invites if isinstance(r,dict) and str(r.get('Direction','')).upper()=='INCOMING')
    # Separate contact identity from exact record equality: two different exports
    # of the same account may contain different additional fields.
    identifiable=set()
    for r in con:
        if not isinstance(r,dict):continue
        key=str(r.get('URL') or r.get('Profile URL') or '').strip().lower().rstrip('/')
        if not key:
            key='|'.join(str(r.get(x,'')).strip().casefold() for x in ('First Name','Last Name','Company'))
        if key.strip('| '):identifiable.add(key)
    return {'connections_rows':len(con),'connections_raw_rows':len(raw_connections),
            'connections_exact_duplicates':len(raw_connections)-len(con),
            'unique_identifiers':len(identifiable),
            'invitations_rows':len(invites),'invitations_raw_rows':len(raw_invites),
            'invitation_exact_duplicates':len(raw_invites)-len(invites),
            'invitation_unique_records':len(invites), 'outgoing':sent,'incoming':received}


def content_info(cx,until=None):
    shares=distinct_rows(as_rows(latest_domain(cx,'MEMBER_SHARE_INFO',until)))
    comments=distinct_rows(as_rows(latest_domain(cx,'ALL_COMMENTS',until)))
    media=distinct_rows(as_rows(latest_domain(cx,'RICH_MEDIA',until)))
    counts=collections.Counter();dated=[]
    # Additional topics from the user's own declared skills make this useful
    # beyond ESG/Compliance. Exact phrase matching, not AI classification.
    skill_rows=distinct_rows(as_rows(latest_domain(cx,'SKILLS',until)))
    skill_labels=[]
    for item in skill_rows:
        name=str(item.get('Name','')).strip() if isinstance(item,dict) else str(item).strip()
        if 5<=len(name)<=45 and name not in skill_labels:
            skill_labels.append(name)
    skill_labels=skill_labels[:30]
    for r in shares:
        if not isinstance(r,dict):continue
        body=str(r.get('ShareCommentary') or r.get('shareCommentary') or r.get('Media Description') or '')
        hits=[name for name,regex in TERMS.items() if re.search(regex,body,re.I)]
        for name in skill_labels:
            if re.search(r'(?<!\w)'+re.escape(name)+r'(?!\w)',body,re.I):
                hits.append('Kenntnis: '+name)
        counts.update(hits)
        dated.append({'date':str(r.get('Date') or ''),'topics':hits,'preview':body[:130],
                      'url':str(r.get('ShareLink') or '')})
    return {'posts':len(shares),'comments':len(comments),'media':len(media),
            'topics':dict(counts),'recent_posts':dated[:25]}


def ad_info(cx,until=None):
    rows=as_rows(latest_domain(cx,'AD_TARGETING',until))
    if not rows:return {'skill_count':None,'skills':[]}
    row=rows[0]
    raw=row.get('Member Skills','') if isinstance(row,dict) else ''
    skills=sorted(set(x.strip() for x in str(raw).split(';') if x.strip()))
    return {'skill_count':len(skills),'skills':skills,
            'job_seniority':row.get('Job Seniorities',''),
            'experience':row.get('Years of Experience','')}


def data_inventory(cx,until=None):
    """Last saved dataset per domain, with explicit source and freshness.

    No payload, names, messages or content leave the local API response. The
    data_status returned to the UI contains only counts and import metadata.
    An unsuccessful API probe must never erase or refresh a previous dataset.
    """
    sql=('SELECT d.domain,d.payload,s.id,s.source,s.label,s.imported_at,s.reference_date '
         'FROM datasets d JOIN snapshots s ON s.id=d.snapshot_id')
    args=[]
    if until is not None:
        sql+=' WHERE s.id<=?';args=[int(until)]
    sql+=' ORDER BY s.id DESC, d.domain'
    seen=set(); result=[]
    for r in cx.execute(sql,args):
        if r['domain'] in seen:continue
        seen.add(r['domain'])
        try:raw=as_rows(json.loads(r['payload']))
        except (ValueError,TypeError):raw=[]
        distinct=len(distinct_rows(raw))
        result.append({'domain':r['domain'],'source':r['source'],
                       'label':r['label'],'snapshot_id':r['id'],
                       'imported_at':r['imported_at'],'reference_date':r['reference_date'],
                       'raw_records':len(raw),'effective_records':distinct,
                       'exact_duplicates':len(raw)-distinct})
    return result


def overview(cx,until=None,share_safe=False):
    snapshots=snapshot_list(cx)
    if until is not None:snapshots=[x for x in snapshots if x['id']<=int(until)]
    scoring=score_info(cx,until);p=profile_info(cx,until);n=net_info(cx,until)
    a=ad_info(cx,until);c=content_info(cx,until)
    result={'snapshots':snapshots,'scores':scoring,'profile':p,'network':n,'ads':a,'content':c}
    if not share_safe:result['data_inventory']=data_inventory(cx,until)
    result['analysis']=advise(cx,p,n,c,scoring,until)
    if share_safe:
        coverage={}
        raw_coverage={}
        duplicates_coverage={}
        for rec in cx.execute('SELECT domain,payload FROM datasets WHERE snapshot_id IN (SELECT max(snapshot_id) FROM datasets GROUP BY domain)'):
            # Counts only, no payload values, no names or individual records.
            try:
                items=__import__('json').loads(rec['payload'])
                rows=as_rows(items)
                coverage[rec['domain']]=len(distinct_rows(rows))
                raw_coverage[rec['domain']]=len(rows)
                duplicates_coverage[rec['domain']]=len(rows)-coverage[rec['domain']]
            except (TypeError,ValueError):pass
        # Baseline is intentionally historical; never pass it off as a new API score.
        score_origin=('Lokale historische Score-Daten bis '+str(scoring.get('measured_through'))+
                      ', nicht als neue API-Bewertung bestätigt') if scoring['point_count'] else 'Kein Score-Wert vorhanden'
        retained=[]
        if not scoring['point_count']:
            baseline=ROOT/'reference'/'credibility-baseline.json'
            if baseline.is_file():
                try:
                    historic=json.loads(baseline.read_text(encoding='utf-8')).get('scores')
                    if isinstance(historic,dict) and historic.get('point_count',0)>0:
                        scoring=historic
                        retained=['scores']
                        score_origin=('Historische Score-Basis bis '+str(historic.get('measured_through'))+
                                      '; nicht neu durch die LinkedIn-API bestätigt')
                except (ValueError,OSError):
                    pass
        last_sync=None
        try:
            syncrow=cx.execute('SELECT executed_at,requested,statuses_json FROM sync_runs ORDER BY id DESC LIMIT 1').fetchone()
            if syncrow:
                detail=json.loads(syncrow['statuses_json'])
                statuses=detail.get('domains',detail)
                last_sync={'executed_at':syncrow['executed_at'],
                           'requested_domains':syncrow['requested'],
                           'authorization':detail.get('authorization',{'state':'not_checked'}),
                           'domains_with_data':sum(isinstance(v,dict) and v.get('rows',0)>0 for v in statuses.values()),
                           'status_by_domain':{k:('data' if isinstance(v,dict) and v.get('rows',0)>0 else
                               ('HTTP '+re.search(r'HTTP\s+(\d{3})',str(v.get('message',''))).group(1) if
                                 isinstance(v,dict) and re.search(r'HTTP\s+(\d{3})',str(v.get('message',''))) else
                                'empty/unavailable')) for k,v in statuses.items()}}
        except Exception:
            pass
        # Published to GitHub: only professional score categories, no contact lists,
        # emails, tokens, personal messages, exact profile text or post text.
        return {'generated_at':dt.datetime.now(dt.timezone.utc).isoformat(),
                'source_notice':'LinkedIn export/API classifications; not evidence of feed ranking.',
                'latest_snapshot':snapshots[0]['reference_date'] or snapshots[0]['imported_at'] if snapshots else None,
                'coverage':{'domains':coverage,'raw_domains':raw_coverage,
                            'exact_duplicates_by_domain':duplicates_coverage,'domain_count':len(coverage)},
                'scores':scoring,
                'score_data_origin':score_origin,
                'retained_historical_sections':retained,
                'latest_api_sync':last_sync,
                'network':n,'content':{'posts':c['posts'],'comments':c['comments'],
                                      'media':c['media'],'topics':c['topics']},
                'profile':{'skill_count':p['skill_count'],'position_count':p['position_count']},
                'ads':{'skill_count':a['skill_count']},
                'analysis':{'method':result['analysis']['method'],
                            'endorsements':{k:v for k,v in result['analysis']['endorsements'].items() if k!='received_by_skill'},
                            'quality':{k:{a:v for a,v in d.items() if a!='source'} for k,d in result['analysis']['quality'].items()},
                            'recommendations':result['analysis']['recommendations']}}
    return result


# V2.8: observation log for real LinkedIn post statistics. This deliberately
# does not confuse the member's OWN comments with incoming post discussion.
import urllib.parse
import hashlib
from datetime import datetime, timezone

REACH_NUMBERS = ('impressions','reach','reactions','comments','reposts','saves','clicks',
                 'video_views','substantive_comments','new_participants','own_comments')


def _integer_or_none(val,name,required=False):
    if val is None or val=='':
        if required:raise ValueError(name+' ist erforderlich.')
        return None
    if isinstance(val,bool):raise ValueError(name+' muss eine Zahl sein.')
    if isinstance(val,float) and not val.is_integer():raise ValueError(name+' muss ganzzahlig sein.')
    if not str(val).strip().isdigit():raise ValueError(name+' muss eine nichtnegative Ganzzahl sein.')
    num=int(val)
    if num>1_000_000_000:raise ValueError(name+' ist zu groß.')
    return num


def _observation_time(value):
    if not value:return datetime.now(timezone.utc).isoformat(timespec='seconds')
    if not isinstance(value,str) or len(value)>40:raise ValueError('Ungültiges Messdatum.')
    try:
        raw=value.replace('Z','+00:00')
        d=datetime.fromisoformat(raw)
        if d.tzinfo is None:raise ValueError()
        d=d.astimezone(timezone.utc)
        if d>datetime.now(timezone.utc)+dt.timedelta(minutes=5):raise ValueError()
        return d.isoformat(timespec='seconds')
    except (TypeError,ValueError):raise ValueError('Messdatum muss eine gültige Uhrzeit mit Zeitzone sein.')


def _post_identity(channel,url,title,published):
    if channel not in ('private','company'):raise ValueError('Kanal muss Privatprofil oder Unternehmensseite sein.')
    url=str(url or '').strip()
    if len(url)>1000:raise ValueError('Link zu lang.')
    if url:
        try:
            parsed=urllib.parse.urlsplit(url)
            if parsed.scheme!='https' or (parsed.hostname or '').lower() not in ('linkedin.com','www.linkedin.com'):
                raise ValueError()
            if not parsed.path.startswith(('/posts/','/feed/update/','/pulse/')):
                raise ValueError()
            normalized='linkedin.com'+parsed.path.rstrip('/').lower()
        except ValueError:raise ValueError('Nur gültige https-Links zu LinkedIn-Beiträgen verwenden.')
    else:
        if not title.strip() or not published.strip():
            raise ValueError('Ohne Beitragslink sind Titel und Veröffentlichungsdatum nötig.')
        normalized=title.strip().casefold()+'|'+published.strip()
    return hashlib.sha256((channel+'|'+normalized).encode('utf-8')).hexdigest()[:28],url


def save_post_observation(cx, record, source='manual'):
    if not isinstance(record,dict):raise ValueError('Ungültiger Messstand.')
    channel=str(record.get('channel') or '').strip()
    title=str(record.get('title') or '').strip()[:240]
    published=str(record.get('published_at') or '').strip()[:40]
    post_key,url=_post_identity(channel,record.get('url'),title,published)
    values={key:_integer_or_none(record.get(key),key,key=='impressions') for key in REACH_NUMBERS}
    if values['reach'] is not None and values['reach']>values['impressions']:
        raise ValueError('Erreichte Mitglieder dürfen Impressionen nicht übersteigen.')
    for k in ('substantive_comments','new_participants','own_comments'):
        if values[k] is not None and values['comments'] is not None and values[k]>values['comments']:
            raise ValueError(k+' darf die Kommentarzahl nicht übersteigen.')
    watch=record.get('avg_watch_seconds')
    if watch is not None and watch!='':
        try:
            watch=float(watch)
            if watch<0 or watch>100000:raise ValueError()
        except (ValueError,TypeError):raise ValueError('Ungültige Wiedergabezeit.')
    else:watch=None
    notes=str(record.get('notes') or '').strip()[:500]
    observed_at=_observation_time(record.get('observed_at'))
    fields=['channel','post_key','post_url','title','published_at','observed_at','source',*REACH_NUMBERS,'avg_watch_seconds','notes']
    data=[channel,post_key,url,title,published,observed_at,source]+[values[k] for k in REACH_NUMBERS]+[watch,notes]
    sql='INSERT INTO post_observations ('+','.join(fields)+') VALUES ('+','.join('?' for _ in fields)+')'
    cursor=cx.execute(sql,data);cx.commit()
    return {'id':cursor.lastrowid,'post_key':post_key,'observed_at':observed_at}


def delete_post_observation(cx, obs_id):
    if not isinstance(obs_id,int) or isinstance(obs_id,bool) or obs_id<1:raise ValueError('Ungültiger Messstand.')
    cursor=cx.execute('DELETE FROM post_observations WHERE id=?',(obs_id,));cx.commit()
    return bool(cursor.rowcount)


def _parse_datetime_for_age(value):
    if not value:return None
    try:
        raw=value.replace('Z','+00:00')
        if len(raw)==10:raw+='T00:00:00'
        result=datetime.fromisoformat(raw)
        if result.tzinfo is None:
            try:
                from zoneinfo import ZoneInfo
                result=result.replace(tzinfo=ZoneInfo('Europe/Berlin'))
            except Exception:
                # Native Windows Python may have no IANA timezone database.
                # Europe/Berlin DST: last Sunday in March through last Sunday
                # in October. Transition-hour posts have indeterminate local
                # time and therefore no reliable age.
                import calendar
                def last_sunday(year,month):
                    last=calendar.monthrange(year,month)[1]
                    return last-(datetime(year,month,last).weekday()+1)%7
                year=result.year
                summer_start=datetime(year,3,last_sunday(year,3),2)
                summer_end=datetime(year,10,last_sunday(year,10),3)
                if summer_start<=result<summer_start+dt.timedelta(hours=1) or \
                   summer_end-dt.timedelta(hours=1)<=result<summer_end:
                    return None
                offset=2 if summer_start<=result<summer_end else 1
                result=result.replace(tzinfo=dt.timezone(dt.timedelta(hours=offset)))
        return result
    except ValueError:return None


def _reach_diagnosis(latest,older):
    impressions=latest['impressions'];comments=latest['comments']
    result={'level':'unknown','title':'Noch keine Verlaufsdiagnose',
            'detail':'Ein einzelner Datenstand zeigt nicht, ob LinkedIn die Ausspielung verzögert oder begrenzt hat.'}
    if not older:
        if impressions<100:
            result['detail']='Wenige Impressionen im bisherigen Messstand. Für die Ursachenanalyse ist eine zweite Messung desselben Beitrags nötig.'
        if comments and comments>0:
            result['detail']+=' Kommentare sind vorhanden; deren fachliche Qualität ist aus den Zählwerten nicht ablesbar.'
        return result
    previous=older['impressions'];gain=impressions-previous
    if gain<0:
        return {'level':'warning','title':'Messwerte nicht vergleichbar',
                'detail':'Der neuere Export weist weniger Impressionen als der ältere aus. Mögliche Korrektur durch LinkedIn oder abweichende Messgrundlage.'}
    if gain==0 and comments and comments>0:
        return {'level':'watch','title':'Diskussion bei unveränderter Impressionenzahl',
                'detail':'Seit der letzten Messung keine zusätzlichen Impressionen, obwohl Kommentare vorhanden sind. Ob diese vor oder nach der ersten Messung entstanden, ist nicht gesichert.'}
    if comments is not None and older['comments'] is not None and comments>older['comments']:
        return {'level':'watch','title':'Kommentar- und Reichweitenverlauf gemeinsam betrachten',
                'detail':f"Zwischen den Messungen: {comments-older['comments']} zusätzliche Kommentarereignisse und {gain} zusätzliche Impressionen. Das belegt weder einen positiven noch einen negativen Algorithmuseffekt."}
    if gain==0:
        return {'level':'watch','title':'Ausspielung im Messintervall unverändert',
                'detail':'Seit dem vorherigen Messstand sind keine weiteren Impressionen hinzugekommen. Einzelne Intervalle beweisen keine kontoweite Drosselung.'}
    return {'level':'info','title':'Reichweite hat zugenommen',
            'detail':f'{gain} zusätzliche Impressionen seit der letzten Messung. Ohne geeignete Vergleichsbeiträge lässt sich das Wachstum nicht als gut oder schlecht einstufen.'}


def reach_monitor(cx,limit_posts=100):
    records=[dict(r) for r in cx.execute('SELECT * FROM post_observations ORDER BY observed_at DESC,id DESC LIMIT 2000')]
    by_key=collections.defaultdict(list)
    for r in records:by_key[(r['channel'],r['post_key'])].append(r)
    posts=[]
    for key,history in by_key.items():
        if len(posts)>=limit_posts:break
        latest=history[0];previous=history[1] if len(history)>1 else None
        observed=_parse_datetime_for_age(latest['observed_at'])
        pub=_parse_datetime_for_age(latest['published_at'])
        age_hours=round((observed-pub).total_seconds()/3600,1) if observed and pub else None
        if age_hours is not None and age_hours<0:age_hours=None
        info=_reach_diagnosis(latest,previous)
        summary={'channel':latest['channel'],'post_key':latest['post_key'],'title':latest['title'],
                 'url':latest['post_url'],'published_at':latest['published_at'],
                 'observed_at':latest['observed_at'],'age_hours':age_hours,
                 'latest':latest,'previous':previous,'diagnosis':info,
                 'history':history[:30],'measurements':len(history)}
        posts.append(summary)
    posts.sort(key=lambda x:(x['latest']['observed_at'],x['latest']['id']),reverse=True)
    return {'posts':posts,'total_posts':len(by_key),'total_observations':len(records),
            'method':'Persönliche Messstände. Kommentare, fachlicher Gehalt und neue Teilnehmer nur soweit ausdrücklich erfasst. Keine automatische Freundeswertung.',
            'limitations':['Die persönliche DMA-API liefert nicht zuverlässig eingehende Kommentare und Unternehmensseiten-Analysen.',
                           'Persönliche Beziehungen dürfen nicht als Gefälligkeitskommentar klassifiziert werden.',
                           'Interaktionsereignisse sind keine unterschiedlichen Personen und kein bestätigtes Ranking-Signal.']}
