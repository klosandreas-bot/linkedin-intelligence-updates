"""Local SQLite snapshot store. Secrets are never stored here."""
from __future__ import annotations
import json, os, sqlite3, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('LI_DB_PATH', ROOT / 'data' / 'linkedin.db')).expanduser()


def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    cx = sqlite3.connect(DB_PATH)
    cx.row_factory = sqlite3.Row
    cx.execute('PRAGMA journal_mode=WAL')
    cx.execute('PRAGMA foreign_keys=ON')
    cx.executescript('''
        CREATE TABLE IF NOT EXISTS snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT NOT NULL, label TEXT NOT NULL, imported_at TEXT NOT NULL,
            reference_date TEXT, note TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS datasets (
            snapshot_id INTEGER NOT NULL REFERENCES snapshots(id) ON DELETE CASCADE,
            domain TEXT NOT NULL, payload TEXT NOT NULL,
            PRIMARY KEY(snapshot_id,domain)
        );
        CREATE TABLE IF NOT EXISTS scores (
            snapshot_id INTEGER NOT NULL REFERENCES snapshots(id) ON DELETE CASCADE,
            score_type TEXT NOT NULL, topic TEXT NOT NULL, category TEXT NOT NULL,
            measured_at TEXT NOT NULL, value REAL NOT NULL,
            PRIMARY KEY(snapshot_id,score_type,topic,category,measured_at)
        );
        CREATE TABLE IF NOT EXISTS change_events (
            event_id TEXT PRIMARY KEY, event_time TEXT, resource TEXT, method TEXT,
            summary TEXT, captured_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS change_event_payloads (
            event_id TEXT PRIMARY KEY REFERENCES change_events(event_id) ON DELETE CASCADE,
            payload TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_scores_date ON scores(measured_at);
        CREATE TABLE IF NOT EXISTS post_observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            channel TEXT NOT NULL CHECK(channel IN ('private','company')),
            post_key TEXT NOT NULL,
            post_url TEXT NOT NULL DEFAULT '',
            title TEXT NOT NULL DEFAULT '',
            published_at TEXT NOT NULL DEFAULT '',
            observed_at TEXT NOT NULL,
            source TEXT NOT NULL CHECK(source IN ('manual','linkedin_xlsx')),
            impressions INTEGER NOT NULL CHECK(impressions>=0),
            reach INTEGER CHECK(reach IS NULL OR reach>=0),
            reactions INTEGER CHECK(reactions IS NULL OR reactions>=0),
            comments INTEGER CHECK(comments IS NULL OR comments>=0),
            reposts INTEGER CHECK(reposts IS NULL OR reposts>=0),
            saves INTEGER CHECK(saves IS NULL OR saves>=0),
            clicks INTEGER CHECK(clicks IS NULL OR clicks>=0),
            video_views INTEGER CHECK(video_views IS NULL OR video_views>=0),
            avg_watch_seconds REAL CHECK(avg_watch_seconds IS NULL OR avg_watch_seconds>=0),
            substantive_comments INTEGER CHECK(substantive_comments IS NULL OR substantive_comments>=0),
            new_participants INTEGER CHECK(new_participants IS NULL OR new_participants>=0),
            own_comments INTEGER CHECK(own_comments IS NULL OR own_comments>=0),
            notes TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_post_observations_key ON post_observations(channel,post_key,observed_at);
        CREATE TABLE IF NOT EXISTS sync_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            executed_at TEXT NOT NULL, requested INTEGER NOT NULL,
            statuses_json TEXT NOT NULL
        );
    ''')
    cx.commit()
    return cx


def new_snapshot(cx, source, label, reference_date='', note=''):
    cx.execute('INSERT INTO snapshots(source,label,imported_at,reference_date,note) VALUES(?,?,?,?,?)',
               (source,label,time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),reference_date,note))
    return cx.execute('SELECT last_insert_rowid()').fetchone()[0]


def put_data(cx, sid, domain, rows):
    cx.execute('INSERT OR REPLACE INTO datasets VALUES (?,?,?)',
               (sid, domain.upper(), json.dumps(rows, ensure_ascii=False, separators=(',',':'))))


def get_data(cx, sid, domain):
    r=cx.execute('SELECT payload FROM datasets WHERE snapshot_id=? AND domain=?', (sid,domain.upper())).fetchone()
    return json.loads(r['payload']) if r else []


def snapshot_list(cx):
    return [dict(r) for r in cx.execute('SELECT * FROM snapshots ORDER BY id DESC')]


def latest_domain(cx, domain, until=None):
    sql='SELECT d.payload FROM datasets d JOIN snapshots s ON s.id=d.snapshot_id WHERE d.domain=?'
    params=[domain.upper()]
    if until is not None:
        sql+=' AND s.id<=?'
        params.append(int(until))
    sql+=' ORDER BY s.id DESC LIMIT 1'
    r=cx.execute(sql,params).fetchone()
    return json.loads(r['payload']) if r else []


def scores_history(cx, until=None):
    """Unique time-series keyed by exact topic and dimension, newest import wins."""
    sql='SELECT score_type,topic,category,measured_at,value,snapshot_id FROM scores'
    params=[]
    if until is not None:
        sql+=' WHERE snapshot_id<=?'
        params=[int(until)]
    sql+=' ORDER BY snapshot_id DESC'
    seen=set(); result=[]
    for r in cx.execute(sql,params):
        key=(r['score_type'],r['topic'],r['category'],r['measured_at'])
        if key in seen: continue
        seen.add(key); result.append(dict(r))
    return result
