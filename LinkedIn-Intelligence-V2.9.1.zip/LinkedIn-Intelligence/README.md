# LinkedIn Intelligence V2.9

Lokales Windows-Dashboard zur Auswertung eigener LinkedIn-Daten. Keine Verbindung zu LinkedIn ohne eigene Autorisierung.

1. Python 3.11 oder neuer installieren.
2. Dieses ZIP in einen eigenen Ordner entpacken.
3. `Start-Dashboard.bat` doppelklicken.
4. Eigenen LinkedIn-ZIP-Export importieren oder den eigenen DMA-API-Zugriff einrichten.
5. Unter „Datenquellen & Abruf“ die Datenstände pro Bereich ansehen.

Seit V2.4 werden bei jedem Start signierte Softwareupdates von GitHub geprüft. Lokale SQLite-Daten, Exporte, Token und persönliche Berichte bleiben unverändert. Für die initiale Installation sind keine fremden Entwicklerzugangsdaten erforderlich.

Neu in V2.7: echte Versionsanzeige aus `version.json`, exakte Dublettenbereinigung bei Kennzahlen, Datenstand pro Bereich mit Quelle und letztem erfolgreichen Import, letzte API-Prüfung separat, Zeitanzeige in MEZ/MESZ sowie die Bezeichnung „Bericht für KI Auswertung / GitHub“.

Eine Zeile wird nur dann bei den Kennzahlen zusammengefasst, wenn ihr JSON-Inhalt vollständig identisch ist. Ähnliche Ereignisse werden nicht allein nach Namen oder Datum zusammengelegt. Originaldateien und gespeicherte Snapshots bleiben vollständig erhalten. Für Kontakte wird die Anzahl unterschiedlicher Kennungen getrennt ausgewiesen.

Scoring-Daten sind interne LinkedIn-Modellwerte, keine veröffentlichten Feed-Rankingfaktoren. Dieses Projekt ist unabhängig von LinkedIn.


## V2.8 – Reichweite & Diskussion

Die neue Seite „Reichweite & Diskussion“ importiert den offiziellen LinkedIn-Einzelbeitrags-Excel-Export (XLSX, Spalten A/B) lokal. Für eigene Unternehmensseitenbeiträge und Screenshots können Messstände manuell erfasst werden. Erfasste Beobachtungen werden separat in der lokalen SQLite-Datenbank gespeichert; die Rohdaten-/API-Snapshots bleiben unverändert.

Erst **zwei Messstände desselben Beitrags** erlauben Aussagen über dessen zeitlichen Verlauf. Die Analyse benennt beobachtete Veränderungen, behauptet aber weder Algorithmus-Sanktionen noch die Ursache einer geringen Ausspielung. Die fachliche Qualität von Kommentaren, die Zahl neuer Diskussionsteilnehmer und eigene Kommentare werden nur bei ausdrücklich erfassten Angaben berücksichtigt. Persönliche Bekanntschaften werden niemals als Gefälligkeitsreaktionen abgewertet.

Die persönliche Member Data Portability API liefert nicht zuverlässig Kommentare anderer Mitglieder unter eigenen Beiträgen und keine allgemeinen Unternehmensseiten-Analysen. Der Monitor versendet keine Messwerte an GitHub; sie sind auch nicht Bestandteil des kuratierten Berichtsexports.


## V2.9 – Unternehmensseite, API-Dubletten und transparente Datenstände

**Unternehmensseite:** Der neue Menüpunkt „Unternehmensseite“ importiert offizielle Seitenanalysen als XLS (altes Excel-Format), XLSX oder CSV. Inhalte/Beiträge, Follower und Besucher können einzeln exportiert und später kombiniert werden. Das Programm nutzt keine fremden Zugangsdaten und keine Unternehmensseiten-API. Es unterstützt eindeutig erkannte Tages- und Beitragskennzahlen; nicht erkannte Tabellen werden gemeldet, nicht mit geratenen Werten ergänzt. Importierte Originaldateien werden nur lokal unter `data/company_exports/` archiviert. Ein identischer Export wird nur einmal importiert; bei überlappenden Zeiträumen ersetzt der jeweils neuere Export den älteren Wert derselben Kennzahl. **Nicht** mehrere Exporte addieren.

Export auf LinkedIn in der Unternehmensseiten-Adminansicht: **Analysen → Inhalte** (oder Besucher/Follower) **→ Exportieren → Zeitraum wählen**. Bei unterschiedlichen Exportformaten kann es nötig sein, Tabellenüberschriften nach einem echten Beispiel gezielt zu ergänzen. Fehlende Tage bleiben unbekannt. Kein pauschaler Ranking- oder Benchmarkvergleich wird behauptet.

**Statusanzeige:** „Letzter API-Lauf“ und der Prüfstatus jedes angefragten Bereichs werden nun auch im lokalen Dashboard tatsächlich mitgesendet. Ein erfolgreicher Import ist von einer erfolglosen erneuten API-Abfrage unterscheidbar. Die lokale MEZ/MESZ-Anzeige bleibt erhalten.

**Dubletten & Speicher:** Bei neuen API-Importen führt nur vollständig gleicher Inhalt zur Deduplizierung der Auswertung. Das ungekürzte Original inklusive aller Zeilen wird lokal unter `data/api_raw/` als SHA-256-verifiziertes gzip-Archiv gespeichert und ist weiterhin als JSON abrufbar. Erkennen wir während der API-Seitennavigation dieselbe ganze Seite erneut, wird der betroffene Bereich als fehlerhaft gemeldet und nicht als unvollständiger neuer Snapshot gespeichert.

**Altbestände optimieren (freiwillig):** Unter „Datenquellen & Abruf → Lokaler Speicher & Dubletten“ steht eine manuell bestätigte verlustfreie Bereinigung vorhandener API-Snapshots. Zuerst entsteht eine vollständige und geprüfte SQLite-Sicherung unter `data/backups/`. Danach werden identische API-Rohzeilen komprimiert archiviert und die gespeicherten Arbeitskopien platzsparend gehalten. Historische Snapshot-IDs, Scores, ZIP-Dateien und sämtliche Unternehmenswerte bleiben erhalten. **Niemals manuell das Verzeichnis `data/` leeren.**

Sicherheit: Originaldateien und Sicherungen bleiben auf dem Rechner. Für den kuratierten KI-Bericht werden keine privaten Unternehmensseitenrohdaten an GitHub oder Dritte übermittelt.


## V2.9.1 – Originaler LinkedIn-Inhalteexport repariert

Der native deutsche XLS-Export der Unternehmensseite wird jetzt mit seinen beiden Blättern
**„Kennzahlen“** und **„Alle Beiträge“** korrekt eingelesen. Erkannt werden die
organischen, gesponserten und gesamten Tageswerte, die individuellen organischen Impressionen,
die Interaktionsrate sowie die Beitragskennzahlen einschließlich der Klickrate. Die
Tagesdaten aus dem LinkedIn-Export stehen im US-Datumsformat Monat/Tag/Jahr;
die Anwendung erkennt dieses Format anhand eindeutiger Tagesangaben. Für europäische
CSV-Formate wird Tag/Monat/Jahr ebenfalls unterstützt.

Ein und derselbe Beitrag wird anhand seines dauerhaften LinkedIn-Links wiedererkannt;
aktualisierte Zahlen ersetzen bei überlappenden Exporten die bisherigen Werte.
Die lesbare Beitragsüberschrift bleibt separat erhalten. „Insgesamt“ darf niemals
mit den bereits darin enthaltenen organischen/gesponserten Zahlen addiert werden.
Vorherige V2.9-Importe anderer Exportformate und persönliche Daten bleiben unberührt.
