"""Lossless, local-first importer for LinkedIn account export ZIPs and API datasets.

Preserves the *entire original archive* plus parsed CSVs for dashboard analysis.
Never uploads to GitHub or a third party. Keep archives in data/ (gitignored).
"""
from __future__ import annotations
import csv, hashlib, io, json, re, zipfile
from pathlib import Path, PurePosixPath
from storage import new_snapshot, put_data, put_api_data, ROOT

MAX_ZIP_SIZE=250*1024*1024
MAX_UNCOMPRESSED=1024*1024*1024
MAX_FILES=6000
MAX_ONE=150*1024*1024

ALIASES={
 'profile.csv':'PROFILE','positions.csv':'POSITIONS','education.csv':'EDUCATION',
 'skills.csv':'SKILLS','connections.csv':'CONNECTIONS','invitations.csv':'INVITATIONS',
 'ad_targeting.csv':'AD_TARGETING','inferences_about_you.csv':'INFERENCE_TAKEOUT',
 'inferred credibility scores.csv':'CREDIBILITY_SCORES',
 'rich_media.csv':'RICH_MEDIA','registration.csv':'REGISTRATION',
 'searchqueries.csv':'SEARCHES','ads clicked.csv':'ADS_CLICKED',
 'lan ads engagement.csv':'ADS_LAN','company follows.csv':'COMPANY_FOLLOWS',
 'savedjobalerts.csv':'SAVED_JOB_ALERTS','saved_jobs.csv':'SAVED_JOBS',
 'endorsement_received_info.csv':'ENDORSEMENTS','events.csv':'EVENTS',
 'learning.csv':'LEARNING','logins.csv':'LOGIN','phonenumbers.csv':'PHONE_NUMBERS',
 'email addresses.csv':'EMAIL_ADDRESSES','security challenges.csv':'SECURITY_CHALLENGE_PIPE',
 'profile summary.csv':'PROFILE_SUMMARY','messages.csv':'INBOX',
 'instantreposts_':'INSTANT_REPOSTS','shares_':'MEMBER_SHARE_INFO',
 'comments_':'ALL_COMMENTS','reactions_':'ALL_LIKES','votes_':'ALL_VOTES',
 'member_follows_':'MEMBER_FOLLOWING','saved_items_':'ACTOR_SAVE_ITEM',
}


def normalize_domain(filename):
    """Every CSV is parsed: unmatched files are also preserved, not discarded."""
    base=PurePosixPath(filename.replace('\\','/')).name.lower()
    if base in ALIASES:return ALIASES[base]
    for prefix,domain in ALIASES.items():
        if prefix.endswith('_') and base.startswith(prefix) and base.endswith('.csv'):
            return domain
    return 'ZIP_CSV_'+re.sub(r'[^A-Z0-9_]', '_',filename.upper())[:180]


def csv_rows(text):
    text=text.lstrip('\ufeff')
    lines=text.splitlines(keepends=True)
    if lines and lines[0].strip().lower().startswith('notes:'):
        for i, line in enumerate(lines):
            if line.lstrip().startswith('First Name,Last Name,URL'):
                text=''.join(lines[i:]);break
    return [dict(r) for r in csv.DictReader(io.StringIO(text)) if r and any(str(x).strip() for x in r.values() if x is not None)]


def score_rows(rows):
    result=[]
    for row in rows:
        typ=(row.get('ScoreType') or '').strip()
        topic=(row.get('Topic') or '').strip()
        cat=(row.get('Category') or '').strip()
        if not typ or not cat: continue
        for key,value in row.items():
            if not key or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',key): continue
            if value is None or str(value).strip()=='': continue
            try: val=float(str(value).replace(',','.'))
            except ValueError: continue
            result.append((typ,topic,cat,key,val))
    return result


def load_zip(cx, content, label='LinkedIn ZIP', reference_date=''):
    if len(content)>MAX_ZIP_SIZE:raise ValueError('ZIP größer als 250 MB.')
    parsed={}; inventory=[]
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        infos=z.infolist()
        if len(infos)>MAX_FILES or sum(i.file_size for i in infos)>MAX_UNCOMPRESSED:
            raise ValueError('ZIP überschreitet Sicherheitsgrenzen.')
        for info in infos:
            if (info.filename.startswith('/') or '..' in PurePosixPath(info.filename.replace('\\','/')).parts):
                raise ValueError('Unsicherer Pfad im ZIP.')
            if info.is_dir():continue
            if info.file_size>MAX_ONE:raise ValueError('Einzelne Datei im ZIP größer als 150 MB.')
            inventory.append({'name':info.filename,'bytes':info.file_size})
            if not info.filename.lower().endswith('.csv'):continue
            domain=normalize_domain(info.filename)
            text=z.read(info).decode('utf-8-sig',errors='replace')
            parsed.setdefault(domain,[]).extend(csv_rows(text))
    if not inventory:raise ValueError('Leeres ZIP.')
    # Keep immutable original archive (including articles, images, and unmatched files).
    digest=hashlib.sha256(content).hexdigest()
    archive_dir=ROOT/'data'/'archives'
    archive_dir.mkdir(parents=True,exist_ok=True)
    archive=archive_dir/(digest+'.zip')
    if not archive.exists():archive.write_bytes(content)
    sid=new_snapshot(cx,'zip',label,reference_date,note='raw-zip-sha256:'+digest)
    for domain,rows in parsed.items():
        if domain=='CREDIBILITY_SCORES':
            for rec in score_rows(rows):
                cx.execute('INSERT OR REPLACE INTO scores VALUES (?,?,?,?,?,?)',(sid,*rec))
        else:put_data(cx,sid,domain,rows)
    put_data(cx,sid,'ZIP_FILE_INDEX',inventory)
    cx.commit()
    return {'snapshot_id':sid,'domains':{k:len(v) for k,v in parsed.items()},
            'source_files':len(inventory),'archive_sha256':digest,
            'score_points':len(score_rows(parsed.get('CREDIBILITY_SCORES',[])))}


def load_api(cx, domains:dict, label='LinkedIn API', note=''):
    if not domains:raise ValueError('Keine API-Daten verfügbar.')
    sid=new_snapshot(cx,'api',label,note=note)
    storage_summary={}
    for domain,records in domains.items():
        if domain=='CREDIBILITY_SCORES':
            for rec in score_rows(records):
                cx.execute('INSERT OR REPLACE INTO scores VALUES (?,?,?,?,?,?)',(sid,*rec))
        else:
            storage_summary[domain]=put_api_data(cx,sid,domain,records)
            if domain=='INFERENCE_TAKEOUT' and isinstance(records,list):
                points=score_rows([r for r in records if isinstance(r,dict) and 'ScoreType' in r])
                for rec in points:
                    cx.execute('INSERT OR REPLACE INTO scores VALUES (?,?,?,?,?,?)',(sid,*rec))
    cx.commit()
    return {'snapshot_id':sid,'domains':{k:len(v) for k,v in domains.items()},'storage':storage_summary}


def load_changelog(cx, elements):
    changes=0
    for e in elements:
        eid=str(e.get('activityId') or e.get('id') or '')
        if not eid:continue
        when=e.get('capturedAt') or e.get('processedAt') or ''
        desc=(str(e.get('resourceName') or '')+' '+str(e.get('method') or '')).strip()
        cx.execute('INSERT OR IGNORE INTO change_events VALUES (?,?,?,?,?,datetime(\'now\'))',
                   (eid,str(when),str(e.get('resourceName') or ''),str(e.get('method') or ''),desc))
        was_new=cx.execute('SELECT changes()').fetchone()[0]
        # Preserve entire event locally, including comment and message context.
        cx.execute('INSERT OR REPLACE INTO change_event_payloads(event_id,payload) VALUES (?,?)',
                   (eid,json.dumps(e,ensure_ascii=False,separators=(',',':'))))
        if was_new:changes+=1
    cx.commit()
    return changes


# V2.8: import of LinkedIn's native SinglePostAnalytics XLSX via stdlib only.
# No external office services, no macros, no formulas evaluated.
import xml.etree.ElementTree as ET
import datetime as _dt

_XNS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
_RELNS='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
_PKGREL='http://schemas.openxmlformats.org/package/2006/relationships'
_MAX_ANALYTICS_FILE=15*1024*1024


def _xlsx_simple_cells(payload):
    if len(payload)>_MAX_ANALYTICS_FILE:raise ValueError('Excel-Datei zu groß (maximal 15 MB).')
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        if len(z.infolist())>250 or sum(x.file_size for x in z.infolist())>30*1024*1024:
            raise ValueError('Excel-Datei überschreitet die Sicherheitsgrenze.')
        names=set(z.namelist())
        if 'xl/workbook.xml' not in names or 'xl/_rels/workbook.xml.rels' not in names:
            raise ValueError('Keine gültige Excel-Arbeitsmappe.')
        def xml(name):
            if name not in names:raise ValueError('Excel-Daten fehlen: '+name)
            if z.getinfo(name).file_size>5*1024*1024:raise ValueError('Excel-Blatt ist zu groß.')
            payload_xml=z.read(name)
            if b'<!DOCTYPE' in payload_xml.upper() or b'<!ENTITY' in payload_xml.upper():
                raise ValueError('Excel-XML mit externen Entitäten wird nicht verarbeitet.')
            return ET.fromstring(payload_xml)
        workbook=xml('xl/workbook.xml')
        sheets=workbook.findall('.//{%s}sheet'%_XNS)
        if not sheets:raise ValueError('Excel-Datei enthält kein Tabellenblatt.')
        sheet=next((s for s in sheets if 'Beitragsanalysen' in s.get('name','')),sheets[0])
        sheet_rel=sheet.get('{%s}id'%_RELNS)
        rels=xml('xl/_rels/workbook.xml.rels')
        relation=next((r for r in rels if r.get('Id')==sheet_rel),None)
        if relation is None:raise ValueError('Excel-Blatt-Verknüpfung fehlt.')
        target=relation.get('Target','').replace('\\','/')
        if target.startswith('/'):
            filename=target.lstrip('/')
        else:
            import posixpath
            filename=posixpath.normpath('xl/'+target)
        if not filename.startswith('xl/worksheets/') or '..' in filename.split('/'):
            raise ValueError('Unerwarteter Tabellenblattpfad.')
        shared=[]
        if 'xl/sharedStrings.xml' in names:
            ss=xml('xl/sharedStrings.xml')
            for si in ss.findall('{%s}si'%_XNS):
                shared.append(''.join(t.text or '' for t in si.iter('{%s}t'%_XNS)))
        sheetxml=xml(filename)
        cells={}
        for c in sheetxml.findall('.//{%s}sheetData/{%s}row/{%s}c'%(_XNS,_XNS,_XNS)):
            addr=c.get('r','')
            typ=c.get('t','')
            v=c.find('{%s}v'%_XNS)
            if typ=='inlineStr':
                value=''.join(t.text or '' for t in c.iter('{%s}t'%_XNS))
            else:
                value=v.text if v is not None else ''
                if typ=='s' and value is not None:
                    index=int(value)
                    value=shared[index] if 0<=index<len(shared) else ''
            if addr:cells[addr]=str(value or '').strip()
        return cells


def parse_linkedin_post_analytics_xlsx(payload,channel='private'):
    """Parse labels in the actual LinkedIn SinglePostAnalytics A/B format.

    Returns an observation dictionary for explicit local storage, without
    guessing relevance, friendship or unprovided counts.
    """
    cells=_xlsx_simple_cells(payload)
    entries={cells.get('A'+str(i),'').strip():cells.get('B'+str(i),'').strip()
             for i in range(1,100) if cells.get('A'+str(i),'').strip()}
    if not any('Impressions' in x for x in entries) or 'URL des Beitrags' not in entries:
        raise ValueError('Keine unterstützte LinkedIn-Einzelbeitragsstatistik (Spalten A/B).')
    if not entries.get('URL des Beitrags',''):
        raise ValueError('Link zum Beitrag fehlt in der Excel-Datei.')
    def count(name):
        val=entries.get(name,'')
        if not val:return None
        normalized=re.sub(r'[\.\s\u00a0]', '',val)
        if not normalized.isdigit():raise ValueError('Unerwartete Zahl in '+name+'.')
        return int(normalized)
    published=entries.get('Veröffentlicht am','')
    published_time=entries.get('Uhrzeit für die Veröffentlichung des Beitrags','')
    if re.fullmatch(r'\d{2}\.\d{2}\.\d{4}',published):
        published=_dt.datetime.strptime(published,'%d.%m.%Y').strftime('%Y-%m-%d')
    if re.fullmatch(r'\d{2}:\d{2}',published_time):
        published+='T'+published_time+':00'
    watch=entries.get('Durchschnittliche Wiedergabezeit','')
    secs=None
    if watch:
        mins=re.search(r'(\d+)\s*Min',watch)
        seconds=re.search(r'(\d+)\s*Sek',watch)
        if mins or seconds:secs=(int(mins.group(1)) if mins else 0)*60+(int(seconds.group(1)) if seconds else 0)
    return {'channel':channel,'url':entries.get('URL des Beitrags'),
            'title':'LinkedIn-Beitrag '+published[:10], 'published_at':published,
            'impressions':count('Impressions'),'reach':count('Erreichte Mitglieder'),
            'reactions':count('Reaktionen'),'comments':count('Kommentare'),
            'reposts':count('Reposts'),'saves':count('Gespeicherte Beiträge'),
            'clicks':count('Engagements mit dem Link'),
            'video_views':count('Videoaufrufe'),'avg_watch_seconds':secs,
            'notes':'LinkedIn-Einzelbeitragsstatistik, manuell importiert. Keine automatischen Annahmen zur Kommentarqualität.'}
# V2.9: Company Page analytics export reader (LinkedIn XLSX and UTF-8 CSV).
# Standard library only; no formulas or macros evaluated, no network.
from datetime import timedelta as _timedelta
import posixpath as _posixpath
import unicodedata as _unicodedata

_COMPANY_ALIASES={
 'date':['date','datum','day','tag','time period','period','reporting date','post date','posted date','date posted','created date','date created','post created on','post created','published at','veroeffentlicht am','veroffentlicht am','publication date'],
 'post':['post url','post link','url des beitrags','beitragslink','content url','post id','post title','beitrag','post','content title','post text'],
 'impressions':['impressions','total impressions','impressionen','impressions total'],
 'organic_impressions':['organic impressions','impressions organic','organic impression','organic reach'],
 'sponsored_impressions':['sponsored impressions','impressions sponsored','paid impressions'],
 'unique_impressions':['unique impressions','unique impression','unique impressions count','unique impressions total','total unique impressions','eindeutige impressionen'],
 'reach':['members reached','erreichte mitglieder','unique reach'],
 'clicks':['clicks','total clicks','klicks','content clicks','link clicks'],
 'organic_clicks':['organic clicks','clicks organic'],
 'sponsored_clicks':['sponsored clicks','clicks sponsored'],
 'reactions':['reactions','reaktionen','likes','organic reactions'],
 'comments':['comments','kommentare','organic comments'],
 'reposts':['reposts','shares','geteilt','shares count','reposts count','organic reposts'],
 'engagement_rate':['engagement rate','engagementrate','engagement rate %','engagement rate (%)','engagement rate total','total engagement rate','interaktionsrate','engagement %','engagement-rate'],
 'click_through_rate':['click through rate','click through rate total','click-through rate','ctr','ctr total','klickrate'],
 'new_followers':['follows','new followers','followers gained','new followers organic','new organic followers','neue follower','neue follower insgesamt','new followers total'],
 'total_followers':['total followers','followers total','total follower count','total followers count','follower insgesamt','follower gesamt','gesamtzahl follower','total number of followers'],
 'organic_followers':['organic followers','new organic followers daily','organische follower'],
 'sponsored_followers':['sponsored followers','new sponsored followers','gesponserte follower'],
 'visitors':['visitors','page visitors','total visitors','besucher','seitenbesucher'],
 'unique_visitors':['unique visitors','unique page visitors','eindeutige besucher','unique page views visitors'],
 'page_views':['page views','views','total page views','seitenaufrufe','pageviews'],
 'custom_button_clicks':['custom button clicks','custom button click','custom button','cta clicks','klicks auf benutzerdefinierte schaltflaeche'],
}
# Native LinkedIn Page Analytics BIFF8 exports (German).  These headers were
# observed in an unmodified Content export dated 2026-10-16.  'insgesamt'
# already includes organic + sponsored: never sum these categories together.
_COMPANY_ALIASES.update({
 'date':_COMPANY_ALIASES['date']+['erstellt am'],
 'post_url':['link veroeffentlichen','link veröffentlichen','url des beitrags','post permalink'],
 'post_title':['titel des beitrags','post title','beitragstitel'],
 'impressions':_COMPANY_ALIASES['impressions']+['impressions (insgesamt)'],
 'organic_impressions':_COMPANY_ALIASES['organic_impressions']+['impressions (organische updates)'],
 'sponsored_impressions':_COMPANY_ALIASES['sponsored_impressions']+['impressions (sponsored updates)'],
 'organic_unique_impressions':['individuelle impressions (organische updates)'],
 'clicks':_COMPANY_ALIASES['clicks']+['klicks (insgesamt)'],
 'organic_clicks':_COMPANY_ALIASES['organic_clicks']+['klicks (organische updates)'],
 'sponsored_clicks':_COMPANY_ALIASES['sponsored_clicks']+['klicks (sponsored updates)'],
 'reactions':_COMPANY_ALIASES['reactions']+['reaktionen (insgesamt)'],
 'organic_reactions':['reaktionen (organisch)'],
 'sponsored_reactions':['reaktionen (gesponsert)'],
 'comments':_COMPANY_ALIASES['comments']+['kommentare (insgesamt)'],
 'organic_comments':['kommentare (organische updates)'],
 'sponsored_comments':['kommentare (sponsored updates)'],
 'reposts':_COMPANY_ALIASES['reposts']+['direkt geteilte beitrage','direkt geteilte beiträge',
                                       'direkt geteilte beitrage (insgesamt)','direkt geteilte beiträge (insgesamt)'],
 'organic_reposts':['direkt geteilte beitrage (organisch)','direkt geteilte beiträge (organisch)'],
 'sponsored_reposts':['direkt geteilte beitrage (gesponsert)','direkt geteilte beiträge (gesponsert)'],
 'engagement_rate':_COMPANY_ALIASES['engagement_rate']+['engagement rate (insgesamt)'],
 'organic_engagement_rate':['engagement rate (organische updates)'],
 'sponsored_engagement_rate':['engagement rate (sponsored updates)'],
 'click_through_rate':_COMPANY_ALIASES['click_through_rate']+['klickrate (ctr)'],
 'post_views':['aufrufe'],
 'offsite_views':['offsite-aufrufe'],
})
_COMPANY_LOOKUP={alias:key for key,aliases in _COMPANY_ALIASES.items() for alias in aliases}
_COMPANY_NUMERIC=set(_COMPANY_ALIASES)-{'date','post','post_url','post_title'}
_COMPANY_RATES={'engagement_rate','organic_engagement_rate','sponsored_engagement_rate','click_through_rate'}


def _norm_header(value):
    word=_unicodedata.normalize('NFKD',str(value or '')).casefold()
    word=''.join(ch for ch in word if not _unicodedata.combining(ch))
    return re.sub(r'\s+',' ',re.sub(r'[^a-z0-9%]+',' ',word)).strip()

_COMPANY_LOOKUP={_norm_header(alias):key for key,aliases in _COMPANY_ALIASES.items() for alias in aliases}


def _parse_company_number(value,ratio=False):
    v=str(value or '').strip().replace('\u00a0','').replace('\u202f','').replace(' ','')
    if not v or v in ('-','–','—','N/A','n/a'):return None
    percent='%' in v
    v=v.replace('%','')
    if ',' in v and '.' in v:
        if v.rfind(',')>v.rfind('.'):v=v.replace('.','').replace(',','.')
        else:v=v.replace(',','')
    elif ',' in v:
        parts=v.split(',')
        v=v.replace(',','' if len(parts[-1])==3 and len(parts)>1 and not ratio else '.')
    elif '.' in v and not ratio:
        parts=v.split('.')
        if len(parts)>1 and all(len(p)==3 for p in parts[1:]):v=v.replace('.','')
    try:value=float(v)
    except ValueError:return None
    if not (0<=value<=1_000_000_000):return None
    if ratio:
        if percent:value/=100.0
        # Rates without % are already ratios if <= 1; otherwise percent expressed 0-100.
        elif value>1 and value<=100:value/=100.0
        return round(value,6) if value<=1 else None
    if not value.is_integer():return None
    return int(value)


def _parse_company_date(value,slash_order="mdy"):
    text=str(value or '').strip()
    if not text:return None
    if re.fullmatch(r'\d{5}(?:\.\d+)?',text):
        serial=float(text)
        if 35000<=serial<=100000:
            return (_dt.datetime(1899,12,30)+_timedelta(days=serial)).strftime('%Y-%m-%d')
    # LinkedIn's native analytics export writes US dates (MM/DD/YYYY).
    # German / European exports can use DD/MM/YYYY, determined per sheet
    # from unambiguous values before parsing (e.g. 09/15 vs 15/09).
    date_patterns=('%Y-%m-%d','%Y/%m/%d','%d.%m.%Y',
                   '%d/%m/%Y' if slash_order=='dmy' else '%m/%d/%Y',
                   '%d-%m-%Y','%b %d, %Y','%B %d, %Y')
    for pattern in date_patterns:
        try:return _dt.datetime.strptime(text[:25],pattern).strftime('%Y-%m-%d')
        except ValueError:pass
    if re.match(r'^\d{4}-\d{2}-\d{2}[ T]',text):
        try:return _dt.date.fromisoformat(text[:10]).isoformat()
        except ValueError:pass
    return None


def _company_xlsx_sheets(payload):
    if len(payload)>_MAX_ANALYTICS_FILE:raise ValueError('Excel-Datei zu groß (maximal 15 MB).')
    try:z=zipfile.ZipFile(io.BytesIO(payload))
    except zipfile.BadZipFile:raise ValueError('Keine gültige XLSX-Datei.')
    with z:
        infos=z.infolist()
        if len(infos)>300 or sum(i.file_size for i in infos)>45*1024*1024:
            raise ValueError('Excel-Arbeitsmappe überschreitet Sicherheitsgrenzen.')
        names=set(z.namelist())
        def load_xml(name):
            if name not in names:raise ValueError('Ungültige Excel-Struktur: '+name)
            if z.getinfo(name).file_size>9*1024*1024:raise ValueError('Excel-Tabellenblatt zu groß.')
            raw=z.read(name)
            if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
                raise ValueError('Unsichere Excel-XML-Struktur.')
            return ET.fromstring(raw)
        book=load_xml('xl/workbook.xml')
        rels=load_xml('xl/_rels/workbook.xml.rels')
        targets={r.get('Id'):r.get('Target','') for r in rels}
        strings=[]
        if 'xl/sharedStrings.xml' in names:
            ss=load_xml('xl/sharedStrings.xml')
            strings=[''.join(t.text or '' for t in item.iter('{%s}t'%_XNS)) for item in ss.findall('{%s}si'%_XNS)]
        result=[]
        for entry in book.findall('.//{%s}sheet'%_XNS):
            sheet_name=entry.get('name','')[:120]
            target=targets.get(entry.get('{%s}id'%_RELNS),'').replace('\\','/')
            location=target.lstrip('/') if target.startswith('/') else _posixpath.normpath('xl/'+target)
            if not location.startswith('xl/worksheets/') or '..' in location.split('/'):
                raise ValueError('Excel-Tabellenblatt-Verweis ungültig.')
            root=load_xml(location)
            rows=[]
            for xmlrow in root.findall('.//{%s}sheetData/{%s}row'%(_XNS,_XNS)):
                values={}
                for cell in xmlrow.findall('{%s}c'%_XNS):
                    ref=cell.get('r','');match=re.match(r'^([A-Z]{1,3})\d+$',ref)
                    if not match:continue
                    number=0
                    for char in match.group(1):number=number*26+ord(char)-64
                    if number>100:continue
                    kind=cell.get('t','')
                    node=cell.find('{%s}v'%_XNS)
                    if kind=='inlineStr':val=''.join(t.text or '' for t in cell.iter('{%s}t'%_XNS))
                    else:
                        val=node.text if node is not None and node.text is not None else ''
                        if kind=='s' and val:
                            idx=int(val)
                            val=strings[idx] if 0<=idx<len(strings) else ''
                    values[number-1]=str(val).strip()
                if values:
                    limit=max(values)+1
                    rows.append([values.get(i,'') for i in range(min(limit,100))])
                if len(rows)>30000:raise ValueError('Zu viele Zeilen in Excel-Datei.')
            result.append((sheet_name,rows))
        return result


def _company_csv_sheet(payload,filename):
    if len(payload)>_MAX_ANALYTICS_FILE:raise ValueError('CSV-Datei zu groß.')
    raw=payload.decode('utf-8-sig',errors='strict')
    delim=';' if raw[:4000].count(';')>raw[:4000].count(',') else ','
    return [(filename, list(csv.reader(io.StringIO(raw),delimiter=delim))[:30000])]


def parse_company_analytics_export(payload,filename):
    """Parse native export tables where metric columns and explicit dates exist.

    Unknown sheets are reported, not silently assigned guessed meanings.
    Segment/demographic sheets without date columns are not represented as trends.
    """
    if not isinstance(payload,bytes) or not payload:raise ValueError('Leerer Export.')
    filename=str(filename or '')[:180]
    ext=Path(filename).suffix.lower()
    if ext=='.xlsx':sheets=_company_xlsx_sheets(payload)
    elif ext=='.xls':sheets=_company_xls_sheets(payload)
    elif ext=='.csv':sheets=_company_csv_sheet(payload,filename)
    else:raise ValueError('Für Unternehmensseiten bitte XLS-, XLSX- oder CSV-Dateien verwenden.')
    result=[];warnings=[];details=[]
    for sheetname,rows in sheets:
        best=None
        for index,line in enumerate(rows[:35]):
            mapped={key:i for i,label in enumerate(line) if (key:=_COMPANY_LOOKUP.get(_norm_header(label)))}
            metrics=[k for k in mapped if k in _COMPANY_NUMERIC]
            if 'date' in mapped and metrics:
                rank=len(metrics)
                if not best or rank>best[0]:best=(rank,index,mapped)
        if not best:
            warnings.append(f'{sheetname}: Keine erkannte Datums-/Kennzahlentabelle; Blatt nicht importiert.')
            continue
        _,header,mapped=best;accepted=0
        us_evidence=eu_evidence=False
        for data_line in rows[header+1:]:
            raw_date=str(data_line[mapped['date']]) if mapped['date']<len(data_line) else ''
            slash=re.fullmatch(r'(\d{1,2})/(\d{1,2})/(\d{4})',raw_date.strip())
            if not slash:continue
            first,second=int(slash.group(1)),int(slash.group(2))
            if first<=12 and second>12:us_evidence=True
            if second<=12 and first>12:eu_evidence=True
        if us_evidence and eu_evidence:
            warnings.append(f'{sheetname}: Gemischte Datumsformate; Tabelle zur Sicherheit nicht importiert.')
            continue
        slash_order='dmy' if eu_evidence else 'mdy'
        for values in rows[header+1:]:
            date=_parse_company_date(values[mapped['date']] if len(values)>mapped['date'] else '',slash_order)
            if not date:continue
            metrics={}
            for metric,col in mapped.items():
                if metric in _COMPANY_NUMERIC:
                    v=_parse_company_number(values[col] if col<len(values) else '',metric in _COMPANY_RATES)
                    if v is not None:metrics[metric]=v
            if not metrics:continue
            def field(name):
                col=mapped.get(name)
                return str(values[col]).strip() if col is not None and col<len(values) else ''
            link=field('post_url')
            # The stable LinkedIn permalink is the preferred identity for
            # recurring exports. Preserve human-readable text separately.
            title=(field('post_title') or field('post')).strip()[:350]
            post=(link or field('post') or title).strip()[:500]
            kind='post' if post else 'daily'
            result.append({'kind':kind,'sheet':sheetname,'date':date,'post':post,
                           'title':title if kind=='post' else '', 'metrics':metrics})
            accepted+=1
            if len(result)>50000:raise ValueError('Zu viele Datenpunkte im Export.')
        details.append({'sheet':sheetname,'parsed_rows':accepted,'metrics':[m for m in mapped if m in _COMPANY_NUMERIC]})
        if not accepted:warnings.append(f'{sheetname}: Keine auswertbaren Tageswerte gefunden.')
    if not result:
        raise ValueError('Keine unterstützten Tages-/Beitragsdaten erkannt. Bitte einen unveränderten LinkedIn-Seitenanalyse-Export (XLS/XLSX/CSV) verwenden. Nicht erkannte Tabellen wurden nicht gespeichert.')
    return {'rows':result,'warnings':warnings[:30],'sheets':details,'filename':filename,
            'sha256':hashlib.sha256(payload).hexdigest()}
# V2.9: Legacy XLS parser. Only local data cells, never executes macros or formulas.
import struct as _struct
from html.parser import HTMLParser as _HTMLParser

_OLE_MAGIC=b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'
_OLE_END=0xfffffffe
_OLE_FREE=0xffffffff


def _xls_html_tables(payload):
    class Extractor(_HTMLParser):
        def __init__(self):super().__init__(convert_charrefs=True);self.tables=[];self.table=None;self.row=None;self.cell=None;self.skip=0
        def handle_starttag(self,tag,attrs):
            if tag in ('script','style'):self.skip+=1
            if self.skip:return
            if tag=='table':self.table=[]
            elif tag=='tr' and self.table is not None:self.row=[]
            elif tag in ('td','th') and self.row is not None:self.cell=[]
        def handle_data(self,data):
            if not self.skip and self.cell is not None:self.cell.append(data)
        def handle_endtag(self,tag):
            if tag in ('script','style') and self.skip:self.skip-=1
            if self.skip:return
            if tag in ('td','th') and self.cell is not None:
                self.row.append(''.join(self.cell).strip());self.cell=None
            elif tag=='tr' and self.row is not None:
                self.table.append(self.row);self.row=None
            elif tag=='table' and self.table is not None:
                self.tables.append(self.table);self.table=None
    parser=Extractor()
    parser.feed(payload.decode('utf-8-sig',errors='replace'))
    return [(f'HTML-Blatt {i+1}',x) for i,x in enumerate(parser.tables)]


def _xls_xml2003_sheets(payload):
    if b'<!DOCTYPE' in payload.upper() or b'<!ENTITY' in payload.upper():raise ValueError('Unsichere XML-Tabellendatei.')
    tree=ET.fromstring(payload)
    tables=[]
    for sheet in tree.iter():
        if sheet.tag.split('}')[-1]!='Worksheet':continue
        name=next((v for k,v in sheet.attrib.items() if k.split('}')[-1]=='Name'),'Tabelle')
        rows=[]
        for row in sheet.iter():
            if row.tag.split('}')[-1]!='Row':continue
            vals=[]
            for cell in row:
                if cell.tag.split('}')[-1]!='Cell':continue
                index=next((v for k,v in cell.attrib.items() if k.split('}')[-1]=='Index'),None)
                if index and index.isdecimal():
                    col=int(index)-1
                    if 0<=col<100:vals.extend(['']*max(0,col-len(vals)))
                data=next((d for d in cell if d.tag.split('}')[-1]=='Data'),None)
                if len(vals)<100:vals.append(''.join(data.itertext()).strip() if data is not None else '')
            rows.append(vals)
            if len(rows)>30000:raise ValueError('Zu viele Excel-Zeilen.')
        tables.append((name,rows))
    return tables


def _ole_workbook_stream(blob):
    """Read just the Workbook/Book stream of a CFB compound file, including miniFAT."""
    if len(blob)<512 or blob[:8]!=_OLE_MAGIC:raise ValueError('Datei ist kein unterstütztes altes Excel-XLS.')
    sector_size=1<<_struct.unpack_from('<H',blob,30)[0]
    mini_size=1<<_struct.unpack_from('<H',blob,32)[0]
    if sector_size not in (512,4096) or mini_size!=64:raise ValueError('Nicht unterstützte XLS-Sektorgröße.')
    if len(blob)>_MAX_ANALYTICS_FILE:raise ValueError('XLS-Datei größer als 15 MB.')
    num_fat,dir_first,cutoff,mini_first,mini_count,difat_first,difat_count=(
        _struct.unpack_from('<I',blob,44)[0],_struct.unpack_from('<I',blob,48)[0],
        _struct.unpack_from('<I',blob,56)[0],_struct.unpack_from('<I',blob,60)[0],
        _struct.unpack_from('<I',blob,64)[0],_struct.unpack_from('<I',blob,68)[0],
        _struct.unpack_from('<I',blob,72)[0])
    def sector(index):
        pos=(index+1)*sector_size
        if index>=0xfffffffa or pos+sector_size>len(blob):raise ValueError('Ungültige XLS-Sektorkette.')
        return blob[pos:pos+sector_size]
    difat=list(_struct.unpack_from('<109I',blob,76));next_difat=difat_first
    for _ in range(min(difat_count,100)):
        if next_difat>=0xfffffffa:break
        values=_struct.unpack('<%dI'%(sector_size//4),sector(next_difat))
        difat.extend(values[:-1]);next_difat=values[-1]
    fat_sectors=[x for x in difat if x<_OLE_END]
    if len(fat_sectors)<num_fat:raise ValueError('XLS-FAT unvollständig.')
    fat=[]
    for id in fat_sectors[:num_fat]:fat.extend(_struct.unpack('<%dI'%(sector_size//4),sector(id)))
    def chain(start,table,unit,read_func,limit_bytes=32*1024*1024):
        parts=[];seen=set();id=start;count=0
        while id<_OLE_END:
            if id>=len(table) or id in seen:raise ValueError('Zyklische oder ungültige XLS-Kette.')
            seen.add(id);parts.append(read_func(id));count+=unit;id=table[id]
            if count>limit_bytes:raise ValueError('XLS-Stream zu groß.')
        return b''.join(parts)
    directory=chain(dir_first,fat,sector_size,sector)
    entries=[]
    for off in range(0,len(directory)-127,128):
        obj=directory[off:off+128]
        sz=_struct.unpack_from('<H',obj,64)[0]
        if 2<=sz<=64 and sz%2==0:
            name=obj[:sz-2].decode('utf-16le',errors='replace')
        else:name=''
        typ=obj[66]
        start=_struct.unpack_from('<I',obj,116)[0]
        size=_struct.unpack_from('<Q',obj,120)[0]
        entries.append((name,typ,start,size))
    root=next((x for x in entries if x[1]==5),None)
    book=next((x for x in entries if x[1]==2 and x[0].lower() in ('workbook','book')),None)
    if not root or not book:raise ValueError('XLS-Workbook-Stream fehlt.')
    _,_,start,size=book
    if size>30*1024*1024:raise ValueError('XLS-Datenteil zu groß.')
    if size<cutoff:
        mini_fat_data=chain(mini_first,fat,sector_size,sector)
        mini_fat=list(_struct.unpack('<%dI'%(len(mini_fat_data)//4),mini_fat_data))
        mini_stream=chain(root[2],fat,sector_size,sector,limit_bytes=40*1024*1024)[:root[3]]
        def get_mini(x):
            start=x*mini_size
            if start+mini_size>len(mini_stream):raise ValueError('Ungültige Mini-FAT.')
            return mini_stream[start:start+mini_size]
        content=chain(start,mini_fat,mini_size,get_mini)
    else:content=chain(start,fat,sector_size,sector)
    return content[:size]


def _biff_records(stream,start=0):
    index=start
    while index+4<=len(stream):
        record,size=_struct.unpack_from('<HH',stream,index)
        if index+4+size>len(stream):break
        yield index,record,stream[index+4:index+4+size]
        index+=4+size


def _biff_sst(chunks):
    """BIFF8 SST with basic CONTINUE handling, compressed and UTF-16 strings."""
    if not chunks or len(chunks[0])<8:return []
    data=chunks[0];current=0;offset=8
    unique=_struct.unpack_from('<I',data,4)[0]
    if unique>50000:raise ValueError('XLS-Texttabelle zu groß.')
    def take(n,is_chars=False):
        nonlocal data,current,offset
        out=bytearray()
        while len(out)<n:
            if offset>=len(data):
                current+=1
                if current>=len(chunks):raise ValueError('XLS-Textdaten unvollständig.')
                data=chunks[current];offset=0
                if is_chars:
                    if not data:raise ValueError('Leere XLS-Fortsetzung.')
                    flag=data[0]
                    offset=1
                    if flag not in (0,1):raise ValueError('XLS-Textkodierung nicht unterstützt.')
                    # Current Unicode segment must retain encoding. Real exports
                    # typically do not split individual strings across CONTINUE.
            count=min(n-len(out),len(data)-offset)
            if count==0:continue
            out.extend(data[offset:offset+count]);offset+=count
        return bytes(out)
    result=[]
    for _ in range(unique):
        length=_struct.unpack('<H',take(2))[0]
        flags=take(1)[0]
        runs=_struct.unpack('<H',take(2))[0] if flags&0x08 else 0
        ext=_struct.unpack('<I',take(4))[0] if flags&0x04 else 0
        wide=bool(flags&0x01)
        raw=take(length*(2 if wide else 1),True)
        result.append(raw.decode('utf-16le' if wide else 'latin1',errors='replace'))
        if runs:take(runs*4)
        if ext:take(ext)
    return result


def _biff_rk(value):
    is_int=value&2
    if is_int:
        signed=_struct.unpack('<i',_struct.pack('<I',value))[0]>>2
        number=float(signed)
    else:
        raw=(value&0xfffffffc)<<32
        number=_struct.unpack('<d',_struct.pack('<Q',raw))[0]
    return number/100 if value&1 else number


def _xls_biff_sheets(payload):
    stream=_ole_workbook_stream(payload)
    records=list(_biff_records(stream))
    sheets=[];strings=[]
    for ri,(_,code,rec) in enumerate(records):
        if code==0x85 and len(rec)>=8:
            pos=_struct.unpack_from('<I',rec,0)[0]
            n=rec[6];wide=bool(rec[7]&1)
            raw=rec[8:8+n*(2 if wide else 1)]
            sheets.append((raw.decode('utf-16le' if wide else 'latin1',errors='replace'),pos))
        elif code==0xFC:
            chunks=[rec]
            for _,other,val in records[ri+1:]:
                if other!=0x3C:break
                chunks.append(val)
            strings=_biff_sst(chunks)
    results=[]
    for title,offset in sheets:
        rowmap={}
        for _,typecode,body in _biff_records(stream,offset):
            if typecode==0x0A:break # EOF
            if len(body)<6:continue
            if typecode==0xFD and len(body)>=10: # LABELSST
                row,col,sst=_struct.unpack_from('<HH',body,0)+(_struct.unpack_from('<I',body,6)[0],)
                value=strings[sst] if sst<len(strings) else ''
            elif typecode==0x203 and len(body)>=14:
                row,col=_struct.unpack_from('<HH',body);value=str(_struct.unpack_from('<d',body,6)[0])
            elif typecode==0x27E and len(body)>=10:
                row,col=_struct.unpack_from('<HH',body);value=str(_biff_rk(_struct.unpack_from('<I',body,6)[0]))
            elif typecode==0xBD and len(body)>=12:
                row,col=_struct.unpack_from('<HH',body)
                last=_struct.unpack_from('<H',body,len(body)-2)[0]
                for pos in range(col,last+1):
                    offset_rk=4+(pos-col)*6
                    if offset_rk+6>len(body)-2:break
                    rk=_struct.unpack_from('<I',body,offset_rk+2)[0]
                    if row<30000 and pos<100:rowmap.setdefault(row,{})[pos]=str(_biff_rk(rk))
                continue
            elif typecode==0x204 and len(body)>=9:
                row,col=_struct.unpack_from('<HH',body)
                length=_struct.unpack_from('<H',body,6)[0]
                value=body[8:8+length].decode('latin1',errors='replace')
            else:continue
            if row<30000 and col<100:rowmap.setdefault(row,{})[col]=str(value)
        if rowmap:
            last=min(max(rowmap)+1,30000)
            rows=[]
            for number in range(last):
                vals=rowmap.get(number,{})
                rows.append([vals.get(i,'') for i in range(max(vals)+1)] if vals else [])
            results.append((title,rows))
    return results


def _company_xls_sheets(payload):
    if len(payload)>_MAX_ANALYTICS_FILE:raise ValueError('XLS-Datei zu groß.')
    if payload.startswith(b'PK\x03\x04'):return _company_xlsx_sheets(payload)
    if payload[:8]==_OLE_MAGIC:return _xls_biff_sheets(payload)
    text=payload[:500].lstrip().lower()
    if text.startswith((b'<html',b'<!doctype html',b'<table',b'<meta')):return _xls_html_tables(payload)
    if text.startswith((b'<?xml',b'<workbook')):return _xls_xml2003_sheets(payload)
    raise ValueError('XLS-Format nicht erkannt. Bei abweichendem Format bitte die Datei in Excel als XLSX speichern.')
