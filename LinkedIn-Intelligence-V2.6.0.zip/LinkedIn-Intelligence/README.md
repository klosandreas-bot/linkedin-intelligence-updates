# LinkedIn Intelligence V2.6

Lokales Dashboard zur Analyse eigener LinkedIn-Daten. Keine Verbindung zu LinkedIn ohne eigene Autorisierung.

1. Python 3.11+ unter Windows installieren.
2. Dieses ZIP entpacken.
3. `Start-Dashboard.bat` starten.
4. Vollstaendigen LinkedIn-ZIP-Export importieren oder eigenen DMA-API-Zugang einrichten.
5. `Auswertung & Empfehlungen` oeffnen.

Ab V2.4 werden signierte Updates automatisch geprueft. Lokale Exporte, SQLite-Daten, .env und Nachrichten werden nicht ueberschrieben. Falls GitHub nicht erreichbar ist, startet die installierte Version. Zum Abschalten `LINKEDIN_AUTO_UPDATE=0` setzen.

Credibility-Scores sind interne modellbasierte LinkedIn-Einschaetzungen, keine nachgewiesenen Feed-Rankingfaktoren. Niedrige Werte allein begruenden keine Profiländerung. Niemals Zertifikate, Kurse oder Endorsements kuenstlich erzeugen.

Das Quellprojekt und die ausfuehrlichen lokalen Entwickler-Tests bleiben getrennt vom datensparsamen Verteilungspaket.
