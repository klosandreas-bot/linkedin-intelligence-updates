"""Curated analytics, exact-topic scoring comparison, no unsupported causal claims."""
from __future__ import annotations
import collections, datetime as dt, json, re
from storage import ROOT,snapshot_list,latest_domain,scores_history
from advisory import advise, fingerprint

DIMENSIONS=['Role and scope','Tenure and experience','Content and output','Education and credentials','Validation and influence']
TERMS={'PPWR':r'\bPPWR\b','EUDR':r'\bEUDR\b','CBAM':r'\bCBAM\b',
       'CSRD':r'\bCSRD\b','CSDDD':r'\b(?:CSDDD|CS3D)\b',
       'EmpCo':r'\b(?:EmpCo|Green Claims)\b','FLR':r'\bFLR\b',
       'ESPR/DPP':r'\b(?:ESPR|DPP)\b','Steuern':r'\b(?:Steuer|Wertschöpfung|Steuern)\w*'}


def as_rows(rows):
    if isinstance(rows,dict): return [rows]
    return rows if isinstance(rows,list) else []


def profile_info(cx,until=None):
    profile=as_rows(latest_domain(cx,'PROFILE',until))
    positions=as_rows(latest_domain(cx,'POSITIONS',until))
    skills=as_rows(latest_domain(cx,'SKILLS',until))
    ed=as_rows(latest_domain(cx,'EDUCATION',until))
    return {'profile':profile[0] if profile else {},'positions':positions,
            'skills':[r.get('Name',r) if isinstance(r,dict) else r for r in skills],
            'education':ed,'skill_count':len(skills),'position_count':len(positions)}


def score_info(cx,until=None):
    rows=scores_history(cx,until)
    grouped=collections.defaultdict(dict)
    notability=[]; normalized=[]; topics=[]
    for r in rows:
        typ=r['score_type']; topic=r['topic'];cat=r['category'];date=r['measured_at']
        if typ=='Notability':
            notability.append(r)
        elif cat=='Topic normalized score':normalized.append(r)
        elif cat in DIMENSIONS:topics.append(r)
    latest={}
    for r in topics:
        key=(r['topic'],r['category'])
        if key not in latest or r['measured_at']>latest[key]['measured_at']:latest[key]=r
    for (topic,cat),r in latest.items():grouped[topic][cat]={'score':r['value'],'date':r['measured_at']}
    latest_norm={}
    for r in normalized:
        key=r['topic']
        if key not in latest_norm or r['measured_at']>latest_norm[key]['measured_at']:latest_norm[key]=r
    def last(cat):
        matches=[r for r in notability if r['category']==cat]
        return max(matches,key=lambda r:r['measured_at']) if matches else None
    ns=last('Aggregated notability score');nt=last('Discrete notability tier')
    return {'dimensions':DIMENSIONS,'topics':[{'name':k,'dimensions':v} for k,v in sorted(grouped.items())],
            'top_knowledge':[{'topic':r['topic'],'score':r['value'],'date':r['measured_at']}
                             for r in sorted(latest_norm.values(),key=lambda r:-r['value'])[:25]],
            'notability':{'score':ns['value'] if ns else None,'date':ns['measured_at'] if ns else None,
                           'tier':nt['value'] if nt else None},
            'history':sorted([r for r in topics+notability+normalized if r['category'] in DIMENSIONS or
                              r['category'] in ['Aggregated notability score','Discrete notability tier']],
                              key=lambda r:(r['measured_at'],r['topic'],r['category'])),
            'point_count':len(rows),'measured_through':max((r['measured_at'] for r in rows),default=None)}


def net_info(cx,until=None):
    con=as_rows(latest_domain(cx,'CONNECTIONS',until))
    invites=as_rows(latest_domain(cx,'INVITATIONS',until))
    # Only de-duplicate exact identical invitation records for directional totals.
    # The raw count remains separately visible for transparency.
    unique_invitation_rows=list({fingerprint(r):r for r in invites if isinstance(r,dict)}.values())
    sent=sum(1 for r in unique_invitation_rows if str(r.get('Direction','')).upper()=='OUTGOING')
    received=sum(1 for r in unique_invitation_rows if str(r.get('Direction','')).upper()=='INCOMING')
    # Uniqueness via profile URLs, no contact names are exported to GitHub.
    unique=set()
    for r in con:
        if not isinstance(r,dict): continue
        k=r.get('URL') or '|'.join(str(r.get(x,'')) for x in ('First Name','Last Name','Company'))
        if k.strip('| '):unique.add(k.lower().rstrip('/'))
    unique_invites={fingerprint(r) for r in invites}
    return {'connections_rows':len(con),'unique_identifiers':len(unique),
            'invitations_rows':len(invites),'invitation_unique_records':len(unique_invites),
            'outgoing':sent,'incoming':received}


def content_info(cx,until=None):
    shares=as_rows(latest_domain(cx,'MEMBER_SHARE_INFO',until))
    comments=as_rows(latest_domain(cx,'ALL_COMMENTS',until))
    media=as_rows(latest_domain(cx,'RICH_MEDIA',until))
    counts=collections.Counter();dated=[]
    # Additional topics from the user's own declared skills make this useful
    # beyond ESG/Compliance. Exact phrase matching, not AI classification.
    skill_rows=as_rows(latest_domain(cx,'SKILLS',until))
    skill_labels=[]
    for item in skill_rows:
        name=str(item.get('Name','')).strip() if isinstance(item,dict) else str(item).strip()
        if 5<=len(name)<=45 and name not in skill_labels:
            skill_labels.append(name)
    skill_labels=skill_labels[:30]
    for r in shares:
        if not isinstance(r,dict):continue
        body=str(r.get('ShareCommentary') or r.get('shareCommentary') or r.get('Media Description') or '')
        hits=[name for name,regex in TERMS.items() if re.search(regex,body,re.I)]
        for name in skill_labels:
            if re.search(r'(?<!\w)'+re.escape(name)+r'(?!\w)',body,re.I):
                hits.append('Kenntnis: '+name)
        counts.update(hits)
        dated.append({'date':str(r.get('Date') or ''),'topics':hits,'preview':body[:130],
                      'url':str(r.get('ShareLink') or '')})
    return {'posts':len(shares),'comments':len(comments),'media':len(media),
            'topics':dict(counts),'recent_posts':dated[:25]}


def ad_info(cx,until=None):
    rows=as_rows(latest_domain(cx,'AD_TARGETING',until))
    if not rows:return {'skill_count':None,'skills':[]}
    row=rows[0]
    raw=row.get('Member Skills','') if isinstance(row,dict) else ''
    skills=sorted(set(x.strip() for x in str(raw).split(';') if x.strip()))
    return {'skill_count':len(skills),'skills':skills,
            'job_seniority':row.get('Job Seniorities',''),
            'experience':row.get('Years of Experience','')}


def overview(cx,until=None,share_safe=False):
    snapshots=snapshot_list(cx)
    if until is not None:snapshots=[x for x in snapshots if x['id']<=int(until)]
    scoring=score_info(cx,until);p=profile_info(cx,until);n=net_info(cx,until)
    a=ad_info(cx,until);c=content_info(cx,until)
    result={'snapshots':snapshots,'scores':scoring,'profile':p,'network':n,'ads':a,'content':c}
    result['analysis']=advise(cx,p,n,c,scoring,until)
    if share_safe:
        coverage={}
        for rec in cx.execute('SELECT domain,payload FROM datasets WHERE snapshot_id IN (SELECT max(snapshot_id) FROM datasets GROUP BY domain)'):
            # Counts only, no payload values, no names or individual records.
            try:
                items=__import__('json').loads(rec['payload'])
                coverage[rec['domain']]=len(items) if isinstance(items,list) else 1
            except (TypeError,ValueError):pass
        # Baseline is intentionally historical; never pass it off as a new API score.
        score_origin=('Lokale historische Score-Daten bis '+str(scoring.get('measured_through'))+
                      ', nicht als neue API-Bewertung bestätigt') if scoring['point_count'] else 'Kein Score-Wert vorhanden'
        retained=[]
        if not scoring['point_count']:
            baseline=ROOT/'reference'/'credibility-baseline.json'
            if baseline.is_file():
                try:
                    historic=json.loads(baseline.read_text(encoding='utf-8')).get('scores')
                    if isinstance(historic,dict) and historic.get('point_count',0)>0:
                        scoring=historic
                        retained=['scores']
                        score_origin=('Historische Score-Basis bis '+str(historic.get('measured_through'))+
                                      '; nicht neu durch die LinkedIn-API bestätigt')
                except (ValueError,OSError):
                    pass
        last_sync=None
        try:
            syncrow=cx.execute('SELECT executed_at,requested,statuses_json FROM sync_runs ORDER BY id DESC LIMIT 1').fetchone()
            if syncrow:
                detail=json.loads(syncrow['statuses_json'])
                statuses=detail.get('domains',detail)
                last_sync={'executed_at':syncrow['executed_at'],
                           'requested_domains':syncrow['requested'],
                           'authorization':detail.get('authorization',{'state':'not_checked'}),
                           'domains_with_data':sum(isinstance(v,dict) and v.get('rows',0)>0 for v in statuses.values()),
                           'status_by_domain':{k:('data' if isinstance(v,dict) and v.get('rows',0)>0 else
                               ('HTTP '+re.search(r'HTTP\s+(\d{3})',str(v.get('message',''))).group(1) if
                                 isinstance(v,dict) and re.search(r'HTTP\s+(\d{3})',str(v.get('message',''))) else
                                'empty/unavailable')) for k,v in statuses.items()}}
        except Exception:
            pass
        # Published to GitHub: only professional score categories, no contact lists,
        # emails, tokens, personal messages, exact profile text or post text.
        return {'generated_at':dt.datetime.now(dt.timezone.utc).isoformat(),
                'source_notice':'LinkedIn export/API classifications; not evidence of feed ranking.',
                'latest_snapshot':snapshots[0]['reference_date'] or snapshots[0]['imported_at'] if snapshots else None,
                'coverage':{'domains':coverage,'domain_count':len(coverage)},
                'scores':scoring,
                'score_data_origin':score_origin,
                'retained_historical_sections':retained,
                'latest_api_sync':last_sync,
                'network':n,'content':{'posts':c['posts'],'comments':c['comments'],
                                      'media':c['media'],'topics':c['topics']},
                'profile':{'skill_count':p['skill_count'],'position_count':p['position_count']},
                'ads':{'skill_count':a['skill_count']},
                'analysis':{'method':result['analysis']['method'],
                            'endorsements':{k:v for k,v in result['analysis']['endorsements'].items() if k!='received_by_skill'},
                            'quality':{k:{a:v for a,v in d.items() if a!='source'} for k,d in result['analysis']['quality'].items()},
                            'recommendations':result['analysis']['recommendations']}}
    return result
