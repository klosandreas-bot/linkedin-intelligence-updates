@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 updater.py --update
    py -3 cli.py serve
) else (
    python updater.py --update
    python cli.py serve
)
pause
