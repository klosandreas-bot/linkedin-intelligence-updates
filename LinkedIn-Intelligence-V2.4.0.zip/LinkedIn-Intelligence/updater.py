"""Signed updates for LinkedIn Intelligence; standard library, offline-friendly.

Only pre-approved program files can be replaced. Local exports, databases, tokens,
reports and configuration are never included in the update allowlist.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
BASE_URL = 'https://raw.githubusercontent.com/klosandreas-bot/linkedin-intelligence-updates/main/'
MANIFEST_URL = BASE_URL + 'latest.json'
SIGNATURE_URL = BASE_URL + 'latest.sig'
PUBLIC_MODULUS = 0x9a899eb73a4079c3d0397c8129d2863917daccaf5645b737ea478d7a71e58c6e78507a8d8068bfbf4e92a80757bc02698d76c788af2ed27c5b1bb526d43c99c341b1236a732d688aed9d3fcd0e88219d6bba975bdbee96b31919b9d9bd838f3d2381fd013c360b97839498babfb7a698c2656e450dc66e674fbdcaa716f35d514ef482e92cd5fe358a4614a8ea35df2849a16f374e7cab2c0a44a26bd14d27719d297657e804d12364001798872aae9d4d43d1ec3f9622f78955c0db489bcd08264f6d99e9bc27fc54fadb48440bb979c8aeb97198796451b2885e754dcb58621ca4fc29b6ad0ffe8c5fe13ffd2dcf146f48143a3846047e66111283febe263d9fbc6b4e821ae2fe0f134d2744706c51ad95f3bbe2ec6ae06419e6d4db711818fe6318d4f540114fb92ae4c6784ee24502b793ad98926e4d651ebca399f5e8865d7ac6239e64d8e3ca41f73262efe09c83d8a2c010b96572ac9c4ec687d380161c7310b67ac31b86c59e4b4740fad04342d69599fcdae235ccd55d6d80c4cf8d
PUBLIC_EXPONENT = 65537
VERSION_PATH = 'version.json'
MAX_MANIFEST = 64 * 1024
MAX_ARCHIVE = 12 * 1024 * 1024
MAX_UNPACKED = 24 * 1024 * 1024
# This is the complete allowed set. Do not add .env, data, reports or user files.
ALLOWLIST = frozenset({
    'advisory.py', 'analytics.py', 'cli.py', 'ingest.py', 'linkedin_api.py',
    'server.py', 'storage.py', 'updater.py', 'static/app.js',
    'static/index.html', 'static/style.css', 'privacy/index.html',
})
BUNDLE_EXTRA = frozenset({
    '.env.example', '.gitignore', 'Start-Dashboard.bat', 'README.md',
    'INSTALLATION_UPDATE.txt', 'version.json', 'data/.gitkeep',
    'reports/.gitkeep', 'tests/test_app.py', 'tests/test_advisory.py',
    'tests/test_updater.py',
})
BUNDLE_FILES = ALLOWLIST | BUNDLE_EXTRA
BUNDLE_PREFIX = 'LinkedIn-Intelligence/'
DER_SHA256 = bytes.fromhex('3031300d060960864801650304020105000420')

class UpdateError(Exception):
    pass


def version_tuple(version):
    if not isinstance(version, str):
        raise UpdateError('Ungueltige Versionsnummer.')
    parts=version.split('.')
    if len(parts)!=3 or any(not p.isdigit() or (len(p)>1 and p[0]=='0') for p in parts):
        raise UpdateError('Ungueltige Versionsnummer.')
    return tuple(map(int,parts))


def local_version(root=ROOT):
    try:
        obj=json.loads((root/VERSION_PATH).read_text(encoding='utf-8'))
        version_tuple(obj['version'])
        return obj['version']
    except (OSError, ValueError, KeyError, TypeError, UpdateError):
        return '2.3.0'


def verify_signature(message, signature_b64):
    """Verify SHA-256 / RSA PKCS#1 v1.5 with embedded public key (no deps)."""
    try:
        sig=base64.b64decode(signature_b64.strip(),validate=True)
        size=(PUBLIC_MODULUS.bit_length()+7)//8
        if len(sig)!=size or int.from_bytes(sig,'big')>=PUBLIC_MODULUS:return False
        decoded=pow(int.from_bytes(sig,'big'), PUBLIC_EXPONENT, PUBLIC_MODULUS).to_bytes(size,'big')
        digest=hashlib.sha256(message).digest()
        expected=b'\x00\x01'+b'\xff'*(size-len(DER_SHA256)-len(digest)-3)+b'\x00'+DER_SHA256+digest
        return hmac.compare_digest(decoded,expected)
    except (ValueError,TypeError):
        return False


def fetch(url, max_bytes):
    if not url.startswith(BASE_URL):
        raise UpdateError('Externe Downloadadresse abgelehnt.')
    req=urllib.request.Request(url,headers={'User-Agent':'LinkedIn-Intelligence-Updater/2.4'})
    with urllib.request.urlopen(req,timeout=6) as r:
        data=r.read(max_bytes+1)
        if len(data)>max_bytes:raise UpdateError('Update-Datei ueberschreitet Groessenlimit.')
        return data


def validate_manifest(obj):
    if not isinstance(obj,dict) or set(obj)!={'version','archive','sha256','files'}:
        raise UpdateError('Unerwartetes Manifestformat.')
    version_tuple(obj['version'])
    if not isinstance(obj['archive'],str) or obj['archive']!='LinkedIn-Intelligence-V'+obj['version']+'.zip':
        raise UpdateError('Ungueltiger Update-Pfad.')
    sha=obj['sha256']
    if not isinstance(sha,str) or len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha):
        raise UpdateError('Ungueltiger SHA-256-Wert.')
    files=obj['files']
    if not isinstance(files,list) or set(files)!=ALLOWLIST or len(files)!=len(ALLOWLIST):
        raise UpdateError('Unerwartete Programmdateien im Manifest.')
    return obj


def validate_archive(data, manifest):
    if hashlib.sha256(data).hexdigest()!=manifest['sha256']:
        raise UpdateError('Pruefsumme stimmt nicht ueberein.')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        members=z.infolist()
        if len(members)!=len(BUNDLE_FILES) or {x.filename for x in members}!={BUNDLE_PREFIX+x for x in BUNDLE_FILES}:
            raise UpdateError('Unerwartete Dateien im Updatepaket.')
        if any(x.is_dir() or x.file_size>MAX_UNPACKED or x.flag_bits&1 or
               (x.external_attr>>16)&0o170000==0o120000 for x in members):
            raise UpdateError('Unzulaessiger Dateityp oder Groesse.')
        if sum(x.file_size for x in members)>MAX_UNPACKED:
            raise UpdateError('Updatepaket zu gross.')
        payload={}
        for name in ALLOWLIST:
            content=z.read(BUNDLE_PREFIX+name)
            if len(content)>MAX_UNPACKED:raise UpdateError('Datei zu gross.')
            payload[name]=content
        return payload


def transaction_path(root):
    return root/'.updater_state'/'transaction.json'


def _save_bytes(path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent,delete=False) as f:
        tmp=Path(f.name)
        f.write(data);f.flush();os.fsync(f.fileno())
    try:os.replace(tmp,path)
    finally:tmp.unlink(missing_ok=True)


def rollback(root=ROOT):
    tx=transaction_path(root)
    if not tx.exists():return False
    info=json.loads(tx.read_text(encoding='utf-8'))
    targets=info['targets']
    if not isinstance(targets,dict) or not set(targets).issubset(ALLOWLIST|{VERSION_PATH}):
        raise UpdateError('Rollback-Daten ungueltig; bitte manuell pruefen.')
    backup=tx.parent/'backup'
    for name, existed in targets.items():
        dest=root/name
        if existed:
            saved=backup/name
            if not saved.is_file():raise UpdateError('Backup fehlt: '+name)
            _save_bytes(dest,saved.read_bytes())
        else:dest.unlink(missing_ok=True)
    tx.unlink();shutil.rmtree(backup,ignore_errors=True)
    return True


def install(payload, version, root=ROOT):
    tx=transaction_path(root)
    state=tx.parent
    if tx.exists():rollback(root)
    if not set(payload)==ALLOWLIST:raise UpdateError('Nicht vollstaendiges Updatepaket.')
    backup=state/'backup'
    if backup.exists():shutil.rmtree(backup)
    targets={}
    for name in sorted(ALLOWLIST|{VERSION_PATH}):
        dest=root/name
        existed=dest.is_file()
        targets[name]=existed
        if existed:
            saved=backup/name
            saved.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(dest,saved)
    _save_bytes(tx,json.dumps({'targets':targets}).encode('utf-8'))
    try:
        for name in sorted(payload):_save_bytes(root/name,payload[name])
        _save_bytes(root/VERSION_PATH,(json.dumps({'version':version})+'\n').encode('utf-8'))
    except BaseException:
        rollback(root)
        raise
    tx.unlink();shutil.rmtree(backup,ignore_errors=True)


def perform_update(root=ROOT, downloader=fetch):
    if rollback(root):print('[Updater] Unterbrochenes Update zurueckgesetzt.')
    if os.environ.get('LINKEDIN_AUTO_UPDATE','1').lower() in ('0','off','false','no'):
        print('[Updater] Automatische Updates deaktiviert.')
        return 'disabled'
    manifest_bytes=downloader(MANIFEST_URL,MAX_MANIFEST)
    signature_bytes=downloader(SIGNATURE_URL,4096)
    if not verify_signature(manifest_bytes,signature_bytes):
        raise UpdateError('Signaturpruefung fehlgeschlagen. Kein Update installiert.')
    manifest=validate_manifest(json.loads(manifest_bytes.decode('utf-8')))
    current=local_version(root)
    if version_tuple(manifest['version'])<=version_tuple(current):
        print('[Updater] Version '+current+' ist aktuell.')
        return 'current'
    print('[Updater] Version '+manifest['version']+' wird geprueft ...')
    blob=downloader(BASE_URL+manifest['archive'],MAX_ARCHIVE)
    payload=validate_archive(blob,manifest)
    install(payload,manifest['version'],root)
    print('[Updater] Erfolgreich aktualisiert auf '+manifest['version']+'.')
    return 'updated'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--update',action='store_true',help='Signierte Updates pruefen und installieren.')
    parser.add_argument('--version',action='store_true',help='Lokale Versionsnummer anzeigen.')
    args=parser.parse_args()
    if args.version:
        print(local_version());return 0
    try:
        perform_update()
    except Exception as exc:
        print('[Updater] Update nicht moeglich: '+str(exc))
        print('[Updater] Lokale Version wird gestartet.')
    return 0

if __name__=='__main__':sys.exit(main())
