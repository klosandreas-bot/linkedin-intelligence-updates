"""Updater security, rollback, offline and authentic update tests (no network)."""
import base64, hashlib, io, json, os, sys, tempfile, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import updater

class UpdaterTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.root=Path(self.t.name)
        (self.root/'data').mkdir();(self.root/'reports').mkdir()
        (self.root/'data'/'linkedin.db').write_bytes(b'PRIVATE_DB')
        (self.root/'reports'/'current.json').write_bytes(b'PRIVATE_REPORT')
        (self.root/'.env').write_bytes(b'LINKEDIN_ACCESS_TOKEN=secret')
        (self.root/'version.json').write_text('{"version":"2.3.0"}',encoding='utf-8')
    def payload(self):
        return {name:('updated-'+name).encode() for name in updater.ALLOWLIST}
    def archive(self,files=None):
        f=io.BytesIO()
        with zipfile.ZipFile(f,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for name,data in (self.payload() if files is None else files).items():z.writestr(updater.BUNDLE_PREFIX+name,data)
            for name in updater.BUNDLE_EXTRA:z.writestr(updater.BUNDLE_PREFIX+name,b'clean')
        return f.getvalue()
    def manifest(self,data):
        return {'version':'2.4.0','archive':'LinkedIn-Intelligence-V2.4.0.zip','sha256':hashlib.sha256(data).hexdigest(),'files':sorted(updater.ALLOWLIST)}
    def test_version(self):
        for x in ['2.4.0','2.3.13','10.12.0']:
            self.assertEqual(len(updater.version_tuple(x)),3)
        for x in ['2.4','2.4.x','2.4.0-dev','02.4.0','../../stuff']:
            with self.assertRaises(updater.UpdateError):updater.version_tuple(x)
    def test_wrong_signatures_rejected(self):
        self.assertFalse(updater.verify_signature(b'a',b'broken'))
    def test_malicious_archives_rejected(self):
        z=self.archive({'../.env':b'evil'})
        with self.assertRaises(updater.UpdateError):updater.validate_archive(z,self.manifest(z))
        z=self.archive(self.payload()|{'.env':b'evil'})
        with self.assertRaises(updater.UpdateError):updater.validate_archive(z,self.manifest(z))
    def test_valid_install_preserves_secrets(self):
        blob=self.archive()
        payload=updater.validate_archive(blob,self.manifest(blob))
        updater.install(payload,'2.4.0',self.root)
        self.assertEqual(updater.local_version(self.root),'2.4.0')
        self.assertEqual((self.root/'data'/'linkedin.db').read_bytes(),b'PRIVATE_DB')
        self.assertEqual((self.root/'reports'/'current.json').read_bytes(),b'PRIVATE_REPORT')
        self.assertEqual((self.root/'.env').read_bytes(),b'LINKEDIN_ACCESS_TOKEN=secret')
    def test_crash_rollback(self):
        (self.root/'cli.py').write_bytes(b'old version')
        original=updater._save_bytes
        counter=[0]
        def crash(path,data):
            if path.name=='server.py':raise RuntimeError('simulated error')
            return original(path,data)
        with patch.object(updater,'_save_bytes',side_effect=crash):
            with self.assertRaises(RuntimeError):updater.install(self.payload(),'2.4.0',self.root)
        self.assertEqual((self.root/'cli.py').read_bytes(),b'old version')
        self.assertEqual(updater.local_version(self.root),'2.3.0')
        self.assertFalse((self.root/'updater.py').exists())
    def test_offline_fallback(self):
        def offline(url,limit):raise OSError('offline')
        with self.assertRaises(OSError):updater.perform_update(self.root,offline)
        self.assertEqual(updater.local_version(self.root),'2.3.0')
    def test_disabled(self):
        with patch.dict(os.environ,{'LINKEDIN_AUTO_UPDATE':'0'}):
            self.assertEqual(updater.perform_update(self.root,lambda u,n:None),'disabled')

if __name__=='__main__':unittest.main()
