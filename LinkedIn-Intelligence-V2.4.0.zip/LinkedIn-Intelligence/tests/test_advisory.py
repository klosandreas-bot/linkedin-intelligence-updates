import json, tempfile, unittest, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import advisory, analytics, storage

class AdvisoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        storage.DB_PATH=Path(self.tmp.name)/'db.sqlite'
        self.cx=storage.db()
    def tearDown(self):
        self.cx.close();self.tmp.cleanup()
    def populate(self,domain,rows,source='api'):
        sid=storage.new_snapshot(self.cx,source,source)
        storage.put_data(self.cx,sid,domain,rows)
        self.cx.commit()
        return sid
    def test_no_data_is_not_false_failure(self):
        a=analytics.overview(self.cx)
        self.assertEqual(a['analysis']['endorsements']['received'],0)
        self.assertTrue(any('importieren' in r['title'].lower() for r in a['analysis']['recommendations']))
        self.assertEqual(a['scores']['point_count'],0)
    def test_in_out_duplicates_and_raw_retained(self):
        older={'Endorsement Date':'2026/01/06 09:16:34 UTC','Endorsement Status':'ACCEPTED',
               'Endorser Public Url':'www.linkedin.com/in/old','Skill Name':'Beratung'}
        new=[{'Endorsement Date':f'2026/10/13 12:34:{x:02} UTC',
              'Endorsement Status':'ACCEPTED','Endorser Public Url':'www.linkedin.com/in/colleague',
              'Skill Name':f'Skill {x}'} for x in range(11)]
        outgoing=[{'Endorsement Date':f'2026/10/13 12:28:{x:02} UTC',
                   'Endorsee Public Url':'www.linkedin.com/in/colleague','Skill Name':f'Other {x}'} for x in range(36)]
        orig=[older,older,*new,*outgoing]
        sid=self.populate('ENDORSEMENTS',orig)
        a=analytics.overview(self.cx)
        e=a['analysis']['endorsements']
        self.assertEqual((e['received'],e['given'],e['exact_duplicates'],e['raw_records']), (12,36,1,49))
        self.assertEqual(len(storage.latest_domain(self.cx,'ENDORSEMENTS')),49)
        self.assertEqual(a['analysis']['quality']['ENDORSEMENTS']['unique_rows'],48)
    def test_network_duplicate_invitations_and_unchanged_raw(self):
        inv={'Direction':'OUTGOING','Sent At':'2026-10-13','Invitee':'Test'}
        self.populate('INVITATIONS',[inv,inv,{'Direction':'INCOMING','Sent At':'2026-10-12'}])
        a=analytics.overview(self.cx)
        self.assertEqual(a['network']['invitations_rows'],3)
        self.assertEqual(a['network']['invitation_unique_records'],2)
        self.assertEqual((a['network']['outgoing'],a['network']['incoming']),(1,1))
    def test_share_safe_no_private_text_and_only_aggregate(self):
        self.populate('ENDORSEMENTS',[{'Endorser Public Url':'www.linkedin.com/in/secret-user',
                                       'Endorser First Name':'SecretName','Skill Name':'Consulting',
                                       'Endorsement Date':'2026/10/13 12:34:20 UTC'}])
        self.populate('INBOX',[{'Body':'VeryPrivateText'}])
        self.populate('CONNECTIONS',[{'URL':'http://linkedin.com/in/personX','First Name':'PrivateContact'}])
        d=analytics.overview(self.cx,share_safe=True)
        serialized=json.dumps(d)
        for term in ['SecretName','secret-user','PrivateContact','VeryPrivateText']:
            self.assertNotIn(term,serialized)
        self.assertIn('analysis',d)
        self.assertEqual(d['analysis']['endorsements']['received'],1)
    def test_provenance_between_api_and_zip(self):
        self.populate('SKILLS',[{'Name':'A'}],source='zip')
        self.populate('SKILLS',[{'Name':'A'},{'Name':'B'}],source='api')
        self.assertEqual(advisory.source_info(self.cx,'SKILLS')['source'],'api')
        self.assertEqual(analytics.overview(self.cx)['profile']['skill_count'],2)

if __name__=='__main__': unittest.main()
