import io,json,os,sys,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import storage,ingest,analytics,linkedin_api

class LinkedInIntelligenceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        storage.DB_PATH=Path(self.temp.name)/'test.sqlite'
        self._old_ingest_root=ingest.ROOT
        ingest.ROOT=Path(self.temp.name)
        self.cx=storage.db()
    def tearDown(self):
        ingest.ROOT=self._old_ingest_root
        self.cx.close();self.temp.cleanup()
    def make_zip(self,items):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            for k,v in items.items():z.writestr(k,v)
        return b.getvalue()
    def test_import_and_scoring_notability(self):
        zipdata=self.make_zip({'Profile.csv':'First Name,Last Name,Headline\nAlex,Example,Compliance\n',
          'Inferred Credibility Scores.csv':
           'ScoreType,Topic,Category,2026-09-24,2026-09-17\n'
           'Knowledge,PPWR,Role and scope,4,3\n'
           'Knowledge,PPWR,Validation and influence,3,2\n'
           'Notability,,Aggregated notability score,,1.06\n',
          'messages.csv':'PrivateMessage,Secret\nHello,password\n'})
        ing=ingest.load_zip(self.cx,zipdata,'test','2026-10-01')
        self.assertEqual(ing['score_points'],5)
        self.assertEqual(analytics.score_info(self.cx)['notability']['score'],1.06)
        self.assertEqual(analytics.score_info(self.cx)['topics'][0]['dimensions']['Role and scope']['score'],4)
        self.assertEqual(analytics.profile_info(self.cx)['profile']['Headline'],'Compliance')
        self.assertEqual(storage.latest_domain(self.cx,'INBOX')[0]['PrivateMessage'],'Hello')
        self.assertTrue((ingest.ROOT/'data'/'archives'/(ing['archive_sha256']+'.zip')).exists())
    def test_missing_score_not_zero(self):
        ing=ingest.load_zip(self.cx,self.make_zip({'Profile.csv':'Headline\nTest\n'}),'test')
        s=analytics.score_info(self.cx)
        self.assertEqual(s['point_count'],0)
        self.assertIsNone(s['notability']['score'])
    def test_reimport_does_not_override(self):
        a=self.make_zip({'Skills.csv':'Name\nPPWR\n'})
        b=self.make_zip({'Skills.csv':'Name\nPPWR\nCBAM\n'})
        ing1=ingest.load_zip(self.cx,a,'first')
        ing2=ingest.load_zip(self.cx,b,'second')
        self.assertEqual(len(storage.get_data(self.cx,ing1['snapshot_id'],'SKILLS')),1)
        self.assertEqual(len(storage.get_data(self.cx,ing2['snapshot_id'],'SKILLS')),2)
        self.assertEqual(len(storage.snapshot_list(self.cx)),2)
    def test_block_zip_bomb_and_path_escape(self):
        b=self.make_zip({'../Profile.csv':'Headline\nbad\n'})
        with self.assertRaises(ValueError):ingest.load_zip(self.cx,b)
    def test_api_page_and_missing(self):
        def mock_call(path,params):
            if params['start']==0:return {'elements':[{'snapshotData':[{'Headline':'OK'}]}],'paging':{'links':[{'rel':'next'}]}}
            raise linkedin_api.APIError(404,'No data found for this memberId')
        with patch.object(linkedin_api,'call',mock_call):
            rows,note=linkedin_api.fetch_domain('PROFILE')
            self.assertEqual(rows,[{'Headline':'OK'}]);self.assertIsNone(note)
    def test_api_inference_scores_when_provided(self):
        result=ingest.load_api(self.cx,{'INFERENCE_TAKEOUT':[{'ScoreType':'Knowledge','Topic':'PPWR','Category':'Role and scope','2026-10-13':'4'}]})
        self.assertEqual(analytics.score_info(self.cx)['point_count'],1)
    def test_github_export_never_contains_contacts(self):
        b=self.make_zip({'Connections.csv':'First Name,Last Name,URL,Company\nSecret,Contact,https://example.com,ACME\n',
                         'Shares_101.csv':'Date,ShareCommentary\n2026-10-01,PPWR example\n'})
        ing=ingest.load_zip(self.cx,b)
        data=analytics.overview(self.cx,share_safe=True)
        text=json.dumps(data)
        self.assertNotIn('Secret',text)
        self.assertIn('PPWR',text)
        self.assertEqual(data['network']['connections_rows'],1)
    def test_all_65_domains_and_unknown_csv_preserved(self):
        self.assertEqual(len(linkedin_api.DEFAULT_DOMAINS),65)
        self.assertIn('INBOX',linkedin_api.DEFAULT_DOMAINS)
        self.assertIn('INFERENCE_TAKEOUT',linkedin_api.DEFAULT_DOMAINS)
        b=self.make_zip({'Some New Export.csv':'Type,Value\nexample,42\n',
                         'Articles/first.html':'<p>Article text</p>',
                         'messages.csv':'Message\nprivate message\n'})
        loaded=ingest.load_zip(self.cx,b,'test')
        self.assertEqual(loaded['source_files'],3)
        self.assertTrue(any(x.startswith('ZIP_CSV_') for x in loaded['domains']))
        with zipfile.ZipFile(ingest.ROOT/'data'/'archives'/(loaded['archive_sha256']+'.zip')) as z:
            self.assertEqual(z.read('Articles/first.html'),b'<p>Article text</p>')
        self.assertEqual(storage.latest_domain(self.cx,'INBOX')[0]['Message'],'private message')
    def test_changelog_metadata_no_messages(self):
        event={'activityId':'abc','processedAt':1,'resourceName':'messages',
               'method':'CREATE','processedActivity':{'body':'private secret'}}
        ing=ingest.load_changelog(self.cx,[event,event])
        self.assertEqual(ing,1)
        row=self.cx.execute('SELECT * FROM change_events').fetchone()
        self.assertNotIn('private secret',str(tuple(row)))
        raw=self.cx.execute('SELECT payload FROM change_event_payloads').fetchone()[0]
        self.assertIn('private secret',raw)

if __name__=='__main__':unittest.main()
