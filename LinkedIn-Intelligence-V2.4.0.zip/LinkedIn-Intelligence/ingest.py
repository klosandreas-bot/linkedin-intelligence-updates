"""Lossless, local-first importer for LinkedIn account export ZIPs and API datasets.

Preserves the *entire original archive* plus parsed CSVs for dashboard analysis.
Never uploads to GitHub or a third party. Keep archives in data/ (gitignored).
"""
from __future__ import annotations
import csv, hashlib, io, json, re, zipfile
from pathlib import Path, PurePosixPath
from storage import new_snapshot, put_data, ROOT

MAX_ZIP_SIZE=250*1024*1024
MAX_UNCOMPRESSED=1024*1024*1024
MAX_FILES=6000
MAX_ONE=150*1024*1024

ALIASES={
 'profile.csv':'PROFILE','positions.csv':'POSITIONS','education.csv':'EDUCATION',
 'skills.csv':'SKILLS','connections.csv':'CONNECTIONS','invitations.csv':'INVITATIONS',
 'ad_targeting.csv':'AD_TARGETING','inferences_about_you.csv':'INFERENCE_TAKEOUT',
 'inferred credibility scores.csv':'CREDIBILITY_SCORES',
 'rich_media.csv':'RICH_MEDIA','registration.csv':'REGISTRATION',
 'searchqueries.csv':'SEARCHES','ads clicked.csv':'ADS_CLICKED',
 'lan ads engagement.csv':'ADS_LAN','company follows.csv':'COMPANY_FOLLOWS',
 'savedjobalerts.csv':'SAVED_JOB_ALERTS','saved_jobs.csv':'SAVED_JOBS',
 'endorsement_received_info.csv':'ENDORSEMENTS','events.csv':'EVENTS',
 'learning.csv':'LEARNING','logins.csv':'LOGIN','phonenumbers.csv':'PHONE_NUMBERS',
 'email addresses.csv':'EMAIL_ADDRESSES','security challenges.csv':'SECURITY_CHALLENGE_PIPE',
 'profile summary.csv':'PROFILE_SUMMARY','messages.csv':'INBOX',
 'instantreposts_':'INSTANT_REPOSTS','shares_':'MEMBER_SHARE_INFO',
 'comments_':'ALL_COMMENTS','reactions_':'ALL_LIKES','votes_':'ALL_VOTES',
 'member_follows_':'MEMBER_FOLLOWING','saved_items_':'ACTOR_SAVE_ITEM',
}


def normalize_domain(filename):
    """Every CSV is parsed: unmatched files are also preserved, not discarded."""
    base=PurePosixPath(filename.replace('\\','/')).name.lower()
    if base in ALIASES:return ALIASES[base]
    for prefix,domain in ALIASES.items():
        if prefix.endswith('_') and base.startswith(prefix) and base.endswith('.csv'):
            return domain
    return 'ZIP_CSV_'+re.sub(r'[^A-Z0-9_]', '_',filename.upper())[:180]


def csv_rows(text):
    text=text.lstrip('\ufeff')
    lines=text.splitlines(keepends=True)
    if lines and lines[0].strip().lower().startswith('notes:'):
        for i, line in enumerate(lines):
            if line.lstrip().startswith('First Name,Last Name,URL'):
                text=''.join(lines[i:]);break
    return [dict(r) for r in csv.DictReader(io.StringIO(text)) if r and any(str(x).strip() for x in r.values() if x is not None)]


def score_rows(rows):
    result=[]
    for row in rows:
        typ=(row.get('ScoreType') or '').strip()
        topic=(row.get('Topic') or '').strip()
        cat=(row.get('Category') or '').strip()
        if not typ or not cat: continue
        for key,value in row.items():
            if not key or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',key): continue
            if value is None or str(value).strip()=='': continue
            try: val=float(str(value).replace(',','.'))
            except ValueError: continue
            result.append((typ,topic,cat,key,val))
    return result


def load_zip(cx, content, label='LinkedIn ZIP', reference_date=''):
    if len(content)>MAX_ZIP_SIZE:raise ValueError('ZIP größer als 250 MB.')
    parsed={}; inventory=[]
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        infos=z.infolist()
        if len(infos)>MAX_FILES or sum(i.file_size for i in infos)>MAX_UNCOMPRESSED:
            raise ValueError('ZIP überschreitet Sicherheitsgrenzen.')
        for info in infos:
            if (info.filename.startswith('/') or '..' in PurePosixPath(info.filename.replace('\\','/')).parts):
                raise ValueError('Unsicherer Pfad im ZIP.')
            if info.is_dir():continue
            if info.file_size>MAX_ONE:raise ValueError('Einzelne Datei im ZIP größer als 150 MB.')
            inventory.append({'name':info.filename,'bytes':info.file_size})
            if not info.filename.lower().endswith('.csv'):continue
            domain=normalize_domain(info.filename)
            text=z.read(info).decode('utf-8-sig',errors='replace')
            parsed.setdefault(domain,[]).extend(csv_rows(text))
    if not inventory:raise ValueError('Leeres ZIP.')
    # Keep immutable original archive (including articles, images, and unmatched files).
    digest=hashlib.sha256(content).hexdigest()
    archive_dir=ROOT/'data'/'archives'
    archive_dir.mkdir(parents=True,exist_ok=True)
    archive=archive_dir/(digest+'.zip')
    if not archive.exists():archive.write_bytes(content)
    sid=new_snapshot(cx,'zip',label,reference_date,note='raw-zip-sha256:'+digest)
    for domain,rows in parsed.items():
        if domain=='CREDIBILITY_SCORES':
            for rec in score_rows(rows):
                cx.execute('INSERT OR REPLACE INTO scores VALUES (?,?,?,?,?,?)',(sid,*rec))
        else:put_data(cx,sid,domain,rows)
    put_data(cx,sid,'ZIP_FILE_INDEX',inventory)
    cx.commit()
    return {'snapshot_id':sid,'domains':{k:len(v) for k,v in parsed.items()},
            'source_files':len(inventory),'archive_sha256':digest,
            'score_points':len(score_rows(parsed.get('CREDIBILITY_SCORES',[])))}


def load_api(cx, domains:dict, label='LinkedIn API', note=''):
    if not domains:raise ValueError('Keine API-Daten verfügbar.')
    sid=new_snapshot(cx,'api',label,note=note)
    for domain,records in domains.items():
        if domain=='CREDIBILITY_SCORES':
            for rec in score_rows(records):
                cx.execute('INSERT OR REPLACE INTO scores VALUES (?,?,?,?,?,?)',(sid,*rec))
        else:
            put_data(cx,sid,domain,records)
            if domain=='INFERENCE_TAKEOUT' and isinstance(records,list):
                points=score_rows([r for r in records if isinstance(r,dict) and 'ScoreType' in r])
                for rec in points:
                    cx.execute('INSERT OR REPLACE INTO scores VALUES (?,?,?,?,?,?)',(sid,*rec))
    cx.commit()
    return {'snapshot_id':sid,'domains':{k:len(v) for k,v in domains.items()}}


def load_changelog(cx, elements):
    changes=0
    for e in elements:
        eid=str(e.get('activityId') or e.get('id') or '')
        if not eid:continue
        when=e.get('capturedAt') or e.get('processedAt') or ''
        desc=(str(e.get('resourceName') or '')+' '+str(e.get('method') or '')).strip()
        cx.execute('INSERT OR IGNORE INTO change_events VALUES (?,?,?,?,?,datetime(\'now\'))',
                   (eid,str(when),str(e.get('resourceName') or ''),str(e.get('method') or ''),desc))
        was_new=cx.execute('SELECT changes()').fetchone()[0]
        # Preserve entire event locally, including comment and message context.
        cx.execute('INSERT OR REPLACE INTO change_event_payloads(event_id,payload) VALUES (?,?)',
                   (eid,json.dumps(e,ensure_ascii=False,separators=(',',':'))))
        if was_new:changes+=1
    cx.commit()
    return changes
