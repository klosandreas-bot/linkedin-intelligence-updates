"""Local, explainable analysis of a member's own portability export.

All recommendations are deterministic and evidence-based, never AI-generated.
Raw datasets are not changed and recommendations never use private message texts.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
import json
from storage import latest_domain, scores_history


def rows(value):
    if isinstance(value, list):
        return value
    return [value] if isinstance(value, dict) else []


def fingerprint(rec):
    """Exact record identity, not a guess about a person's identity."""
    return json.dumps(rec, sort_keys=True, ensure_ascii=False, default=str, separators=(',', ':'))


def exact_duplicates(records):
    keys={fingerprint(x) for x in records}
    return len(records)-len(keys)


def norm_url(url):
    url=str(url or '').strip().lower().removeprefix('https://').removeprefix('http://')
    return url.rstrip('/')


def endorsements(cx, until=None):
    source=rows(latest_domain(cx,'ENDORSEMENTS',until))
    seen=set(); incoming=[]; outgoing=[]; unknown=[]
    for rec in source:
        if not isinstance(rec,dict):continue
        # Identical export rows can occur in different API pages or CSVs.
        identity=fingerprint(rec)
        if identity in seen:continue
        seen.add(identity)
        # Incoming records contain Endorser fields; outgoing contain Endorsee fields.
        if rec.get('Endorser Public Url') or rec.get('Endorser First Name'):
            incoming.append(rec)
        elif rec.get('Endorsee Public Url') or rec.get('Endorsee First Name'):
            outgoing.append(rec)
        else:
            unknown.append(rec)
    received_skills=Counter(str(r.get('Skill Name','')).strip() for r in incoming if r.get('Skill Name'))
    received_dates=sorted((str(r.get('Endorsement Date',''))[:10].replace('/','-') for r in incoming),reverse=True)
    return {'raw_records':len(source),'exact_duplicates':len(source)-len(seen),
            'received':len(incoming),'given':len(outgoing),'unclassified':len(unknown),
            'received_skill_count':len(received_skills),'last_received_date':received_dates[0] if received_dates else None,
            'received_by_skill':dict(received_skills.most_common(30))}


def _iso_age(date):
    try:
        return (datetime.now(timezone.utc).date()-datetime.strptime(date[:10],'%Y-%m-%d').date()).days
    except (TypeError,ValueError,AttributeError):
        return None


def source_info(cx,domain,until=None):
    sql='''SELECT s.source,s.imported_at,s.reference_date FROM datasets d
           JOIN snapshots s ON s.id=d.snapshot_id WHERE d.domain=?'''
    args=[domain]
    if until is not None:
        sql+=' AND s.id<=?';args.append(int(until))
    sql+=' ORDER BY s.id DESC LIMIT 1'
    r=cx.execute(sql,args).fetchone()
    return dict(r) if r else None


def score_changes(cx,until=None):
    """Compare only identical topics/dimensions; do not conflate different score types."""
    data=scores_history(cx,until)
    groups={}
    for r in data:
        if r['category'] not in ('Aggregated notability score','Discrete notability tier',
                                'Role and scope','Tenure and experience','Content and output',
                                'Education and credentials','Validation and influence'):
            continue
        key=(r['score_type'],r['topic'],r['category'])
        groups.setdefault(key,{})[r['measured_at']]=r['value']
    changes=[]
    for (typ,topic,cat),values in groups.items():
        if len(values)<2:continue
        dates=sorted(values)
        previous,current=dates[-2:]
        change=round(float(values[current])-float(values[previous]),3)
        if change:
            changes.append({'type':typ,'topic':topic,'dimension':cat,
                            'previous_date':previous,'previous':values[previous],
                            'current_date':current,'current':values[current],'delta':change})
    changes.sort(key=lambda x:(x['current_date'],abs(x['delta'])),reverse=True)
    return changes[:30]


def advise(cx,profile,network,content,scores,until=None):
    """Only recommendations grounded in available fields. No opaque ranking estimates."""
    insights=[]
    sources={x:source_info(cx,x,until) for x in (
        'PROFILE','SKILLS','POSITIONS','MEMBER_SHARE_INFO','ALL_COMMENTS',
        'CONNECTIONS','INVITATIONS','ENDORSEMENTS','INFERENCE_TAKEOUT')}
    endors=endorsements(cx,until)
    changes=score_changes(cx,until)
    quality={}
    for dom in ('CONNECTIONS','INVITATIONS','ENDORSEMENTS','ALL_LIKES','ADS_CLICKED'):
        records=rows(latest_domain(cx,dom,until))
        quality[dom]={'raw':len(records),'exact_duplicates':exact_duplicates(records),
                      'unique_rows':len(records)-exact_duplicates(records),
                      'source':sources[dom]['source'] if dom in sources and sources[dom] else None}

    def add(priority,group,title,evidence,action,basis):
        insights.append({'priority':priority,'group':group,'title':title,
                         'evidence':evidence,'action':action,'basis':basis})

    data_count=sum(bool(sources[x]) for x in ('PROFILE','SKILLS','MEMBER_SHARE_INFO','ALL_COMMENTS','CONNECTIONS'))
    if not data_count:
        add(1,'Datenbasis','Ersten Datenbestand importieren',
            'Für Profil, Beiträge, Kommentare und Kontakte liegen noch keine auswertbaren Datensätze vor.',
            'Laden Sie zuerst Ihren LinkedIn-Komplettexport als ZIP in „Datenquellen & Abruf“. Die API-Anbindung ist optional.',
            'Dateninventar')
    if network['connections_rows'] and network['unique_identifiers'] and network['connections_rows']>network['unique_identifiers']*1.3:
        add(1,'Datenqualität','Kontaktzahlen nicht als Wachstum interpretieren',
            f"{network['connections_rows']} Kontaktzeilen stehen {network['unique_identifiers']} erkennbaren Kontaktkennungen gegenüber.",
            'Vergleichen Sie eindeutige Kennungen und kontrollieren Sie die API-Seiten. Die Rohzeilen können mehrfach vorkommen.',
            'CONNECTIONS, eindeutige Profilkennungen')
    other_dupes=[(x,v) for x,v in quality.items() if x!='CONNECTIONS' and v['raw']>=6 and v['exact_duplicates']>=2 and v['exact_duplicates']/v['raw']>=.05]
    if other_dupes:
        overview=', '.join(f"{x}: {v['exact_duplicates']}" for x,v in other_dupes)
        add(1,'Datenqualität','Doppelte Datensätze erkannt',
            'Wortgleiche Dubletten in '+overview+'.',
            'Die Auswertung verwendet für Zählungen geeignete eindeutige Datensätze. Die unveränderten Rohdaten bleiben zur Prüfung archiviert.',
            'Exakter Vergleich der JSON-Datensätze')
    if endors['received']:
        add(2,'Profil','Bestätigte Kenntnisse gezielt sichtbar machen',
            f"{endors['received']} verschiedene erhaltene Bestätigungen für {endors['received_skill_count']} Kenntnisse; "
            + (f"jüngster Eintrag vom {endors['last_received_date']}." if endors['last_received_date'] else 'kein Datumswert.'),
            'Ordnen Sie Ihre wichtigsten Kenntnisse nach ihrer Bedeutung für die aktuelle Tätigkeit. Die Zahl der erhaltenen Bestätigungen ist kein garantierter Reichweitenfaktor.',
            'ENDORSEMENTS, ausschließlich eingehende Bestätigungen')
    elif sources.get('SKILLS') and profile['skill_count']:
        add(2,'Profil','Kenntnisse durch fachlichen Nachweis ergänzen',
            f"{profile['skill_count']} Profilkenntnisse sind im Export vorhanden, aber keine erhaltene Bestätigung im verfügbaren ENDORSEMENTS-Bestand.",
            'Halten Sie relevante Kenntnisse aktuell und dokumentieren Sie konkrete Projekte und Ergebnisse. Fehlende Exportdaten belegen keine fehlenden Bestätigungen im Live-Profil.',
            'SKILLS / ENDORSEMENTS')
    if sources.get('PROFILE') and profile['position_count']==0:
        add(2,'Profil','Berufserfahrung im Export prüfen',
            'Für die aktuelle Datenversion sind keine Positionsdatensätze vorhanden.',
            'Prüfen Sie die Angaben im LinkedIn-Profil und ob ein vollständiger ZIP-Export vorliegt. Aus fehlenden Exportdaten lässt sich nicht automatisch auf ein unvollständiges Profil schließen.',
            'POSITIONS')
    if scores['point_count']:
        age=_iso_age(scores['measured_through'])
        if age is not None and age>21:
            add(2,'Bewertungen','Aktualität der internen Scores prüfen',
                f"Neuester verfügbarer Score-Messzeitpunkt {scores['measured_through']} ({age} Tage alt).",
                'Fordern Sie bei Bedarf einen neuen vollständigen LinkedIn-Export an. Fehlende neue Score-Werte bedeuten nicht, dass Ihr Score gefallen ist.',
                'Historische Inferred Credibility Scores aus ZIP')
        if changes:
            pos=sum(x['delta']>0 for x in changes);neg=sum(x['delta']<0 for x in changes)
            add(3,'Bewertungen','Bewertungsänderungen beobachten',
                f"In den jeweils letzten beiden Messpunkten identischer Dimensionen finden sich {pos} Anstiege und {neg} Rückgänge.",
                'Vergleichen Sie nur gleiche Themen und Dimensionen und beachten Sie Messdaten. Aus einer Änderung folgt kein Nachweis einer Wirkung auf den Feed.',
                'Inferred Credibility Scores, identische Themen/Dimensionen')
    else:
        add(2,'Bewertungen','Interne Scores gesondert einlesen',
            'Es liegen keine historischen Credibility-/Notability-Messwerte vor.',
            'Falls Sie diese Werte auswerten möchten, importieren Sie einen Complete-Export mit „Inferred Credibility Scores.csv“. INFERENCE_TAKEOUT enthält diese Scores nicht zwingend.',
            'Scoring-Tabelle / vollständiger LinkedIn-Export')
    if content['posts']:
        ranked=sorted(content['topics'].items(),key=lambda x:x[1],reverse=True)
        if ranked:
            name,number=ranked[0]
            add(3,'Inhalte','Thematische Positionierung überprüfen',
                f"Das häufigste erkannte Stichwort ist {name} in {number} von {content['posts']} Beitragsdatensätzen. Die Stichworterkennung ist unvollständig und Mehrfachzählungen sind möglich.",
                'Prüfen Sie, ob dieser Schwerpunkt zu Ihrer beruflichen Positionierung passt. Fachliche Qualität, Aktualität und relevante Diskussionen sind sinnvoller als eine künstliche Keyword-Quote.',
                'MEMBER_SHARE_INFO, einfache Stichwortzählung')
        else:
            add(3,'Inhalte','Beitragsinhalte manuell einordnen',
                f"{content['posts']} Beitragsdatensätze vorhanden, aber keine Treffer im begrenzten Stichwortkatalog.",
                'Ergänzen Sie bei Bedarf eigene Themenbegriffe. Aus fehlenden Keyword-Treffern folgt keine schlechte Content-Qualität.',
                'MEMBER_SHARE_INFO')
    if content['comments'] and content['posts']:
        add(3,'Aktivität','Beiträge und Diskussionen gemeinsam betrachten',
            f"{content['posts']} Beiträge und {content['comments']} Kommentar-Datensätze stehen im verfügbaren Datenbestand.",
            'Prüfen Sie bei der redaktionellen Planung, welche substanziellen Diskussionen zu Ihren Fachthemen passen. Aus bloßen Stückzahlen lassen sich keine Reichweitenchancen ableiten.',
            'MEMBER_SHARE_INFO / ALL_COMMENTS')
    elif not sources.get('ALL_COMMENTS') and sources.get('MEMBER_SHARE_INFO'):
        add(3,'Datenbasis','Kommentarbestand vervollständigen',
            'Beiträge sind verfügbar, ein Kommentar-Datensatz fehlt im gegenwärtigen Archiv.',
            'Nutzen Sie den vollständigen LinkedIn-Export oder warten Sie auf die Verarbeitung des API-Bereichs ALL_COMMENTS.',
            'Verfügbarkeit der Datenbereiche')
    insights.sort(key=lambda x:x['priority'])
    return {'method':'Regelbasierte Hinweise aus eigenen LinkedIn-Portabilitätsdaten; keine Aussage über Feed-Ranking',
            'endorsements':endors,'score_changes':changes,'quality':quality,
            'source_summary':{k:v for k,v in sources.items() if v},
            'recommendations':insights[:8]}
