# LinkedIn Intelligence V2.7

Lokales Windows-Dashboard zur Auswertung eigener LinkedIn-Daten. Keine Verbindung zu LinkedIn ohne eigene Autorisierung.

1. Python 3.11 oder neuer installieren.
2. Dieses ZIP in einen eigenen Ordner entpacken.
3. `Start-Dashboard.bat` doppelklicken.
4. Eigenen LinkedIn-ZIP-Export importieren oder den eigenen DMA-API-Zugriff einrichten.
5. Unter „Datenquellen & Abruf“ die Datenstände pro Bereich ansehen.

Seit V2.4 werden bei jedem Start signierte Softwareupdates von GitHub geprüft. Lokale SQLite-Daten, Exporte, Token und persönliche Berichte bleiben unverändert. Für die initiale Installation sind keine fremden Entwicklerzugangsdaten erforderlich.

Neu in V2.7: echte Versionsanzeige aus `version.json`, exakte Dublettenbereinigung bei Kennzahlen, Datenstand pro Bereich mit Quelle und letztem erfolgreichen Import, letzte API-Prüfung separat, Zeitanzeige in MEZ/MESZ sowie die Bezeichnung „Bericht für KI Auswertung / GitHub“.

Eine Zeile wird nur dann bei den Kennzahlen zusammengefasst, wenn ihr JSON-Inhalt vollständig identisch ist. Ähnliche Ereignisse werden nicht allein nach Namen oder Datum zusammengelegt. Originaldateien und gespeicherte Snapshots bleiben vollständig erhalten. Für Kontakte wird die Anzahl unterschiedlicher Kennungen getrennt ausgewiesen.

Scoring-Daten sind interne LinkedIn-Modellwerte, keine veröffentlichten Feed-Rankingfaktoren. Dieses Projekt ist unabhängig von LinkedIn.
