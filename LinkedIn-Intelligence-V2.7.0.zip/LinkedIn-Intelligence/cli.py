"""CLI: sync/import/report; entirely standard-library Python."""
from __future__ import annotations
import argparse, json, os, sys, time
from pathlib import Path
from storage import db
from ingest import load_zip,load_api,load_changelog
from analytics import overview
from linkedin_api import fetch_domains,fetch_changes,authorization_status,DEFAULT_DOMAINS

ROOT=Path(__file__).resolve().parent


def read_env():
    env=ROOT/'.env'
    if env.is_file():
        for line in env.read_text(encoding='utf-8').splitlines():
            if '=' in line and not line.lstrip().startswith('#'):
                k,v=line.split('=',1)
                if k.strip() in ('LINKEDIN_ACCESS_TOKEN',):os.environ.setdefault(k.strip(),v.strip().strip('"\''))


def sync(targets=None, changelog=True):
    read_env()
    authorization=authorization_status()
    domains,status=fetch_domains(targets or DEFAULT_DOMAINS)
    outcome={'requested_domains':len(targets or DEFAULT_DOMAINS),'authorization':authorization,'domains':status,'import':None,'changelog':None}
    with db() as cx:
        if domains:
            outcome['import']=load_api(cx,domains,label='LinkedIn API')
        if changelog:
            try:
                existing=cx.execute('SELECT max(CAST(event_time AS INTEGER)) FROM change_events').fetchone()[0]
                # Never request outside 28 day supported period
                lower=int((time.time()-27*86400)*1000)
                events=fetch_changes(max(int(existing or 0),lower))
                outcome['changelog']=load_changelog(cx,events)
            except Exception as e:outcome['changelog_error']=str(e)[:200]
        cx.execute('INSERT INTO sync_runs(executed_at,requested,statuses_json) VALUES(datetime("now"),?,?)',
                   (outcome['requested_domains'],json.dumps({'domains':status,'authorization':authorization},ensure_ascii=False)))
        cx.commit()
    return outcome


def report(path=None,share_safe=True):
    with db() as cx:
        data=overview(cx,share_safe=share_safe)
        present={row['domain'] for row in cx.execute('SELECT DISTINCT domain FROM datasets')}
    if share_safe:
        previous=ROOT/'reports'/'current.json'
        baseline=ROOT/'reference'/'curated-baseline.json'
        old=None
        for source in (previous,baseline):
            if not source.exists():continue
            try:
                candidate=json.loads(source.read_text(encoding='utf-8'))
                if candidate.get('scores',{}).get('point_count',0)>0:
                    old=candidate;break
            except (ValueError,OSError):pass
        retained=list(data.get('retained_historical_sections',[]))
        if old:
            if not data['scores']['point_count']:
                data['scores']=old['scores'];retained.append('scores')
            if 'CONNECTIONS' not in present:
                for key in ('connections_rows','unique_identifiers'):
                    data['network'][key]=old.get('network',{}).get(key,0)
                retained.append('connections')
            if 'INVITATIONS' not in present:
                for key in ('invitations_rows','outgoing','incoming'):
                    data['network'][key]=old.get('network',{}).get(key,0)
                retained.append('invitations')
            if 'MEMBER_SHARE_INFO' not in present:
                data['content']['posts']=old.get('content',{}).get('posts',0)
                data['content']['topics']=old.get('content',{}).get('topics',{})
                retained.append('posts')
            if 'ALL_COMMENTS' not in present:
                data['content']['comments']=old.get('content',{}).get('comments',0)
                retained.append('comments')
            if 'RICH_MEDIA' not in present:
                data['content']['media']=old.get('content',{}).get('media',0)
                retained.append('media')
            if 'SKILLS' not in present:
                data['profile']['skill_count']=old.get('profile',{}).get('skill_count',0)
                retained.append('profile_skills')
            if 'POSITIONS' not in present:
                data['profile']['position_count']=old.get('profile',{}).get('position_count',0)
                retained.append('profile_positions')
            if 'AD_TARGETING' not in present:
                data['ads']['skill_count']=old.get('ads',{}).get('skill_count',None)
                retained.append('ad_targeting')
        data['retained_historical_sections']=retained
        if 'scores' in retained and not data['scores']['point_count']:
            data['score_data_origin']='Historischer Wert, nicht aktuell von API geliefert'
    target=Path(path or ROOT/'reports'/'current.json')
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return str(target)


def main():
    parser=argparse.ArgumentParser(description='LinkedIn Intelligence (offizielle DMA API und CSV ZIPs)')
    sub=parser.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('import');p.add_argument('zipfile');p.add_argument('--date',default='');p.add_argument('--label',default='')
    p=sub.add_parser('sync');p.add_argument('--domains',nargs='*',choices=DEFAULT_DOMAINS);p.add_argument('--no-changelog',action='store_true');p.add_argument('--report-only',action='store_true')
    p=sub.add_parser('report');p.add_argument('--output',default=None);p.add_argument('--full',action='store_true')
    p=sub.add_parser('serve');p.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    if args.cmd=='serve':
        from server import serve
        read_env();serve(args.port)
    elif args.cmd=='import':
        with db() as cx: print(json.dumps(load_zip(cx,Path(args.zipfile).read_bytes(),args.label or Path(args.zipfile).name,args.date),ensure_ascii=False,indent=2))
    elif args.cmd=='sync':
        result=sync(args.domains or None,not args.no_changelog)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        if args.report_only:print('Bericht:',report())
        if not result['import']:sys.exit(2)
    elif args.cmd=='report':print(report(args.output,not args.full))

if __name__=='__main__':main()
