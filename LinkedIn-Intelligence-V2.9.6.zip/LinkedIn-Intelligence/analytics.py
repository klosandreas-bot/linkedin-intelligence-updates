"""Curated analytics, exact-topic scoring comparison, no unsupported causal claims."""
from __future__ import annotations
import collections, datetime as dt, json, re
from pathlib import Path
from storage import ROOT,snapshot_list,latest_domain,scores_history
from advisory import advise, fingerprint, distinct_rows

DIMENSIONS=['Role and scope','Tenure and experience','Content and output','Education and credentials','Validation and influence']
TERMS={'PPWR':r'\bPPWR\b','EUDR':r'\bEUDR\b','CBAM':r'\bCBAM\b',
       'CSRD':r'\bCSRD\b','CSDDD':r'\b(?:CSDDD|CS3D)\b',
       'EmpCo':r'\b(?:EmpCo|Green Claims)\b','FLR':r'\bFLR\b',
       'ESPR/DPP':r'\b(?:ESPR|DPP)\b','Steuern':r'\b(?:Steuer|Wertschöpfung|Steuern)\w*'}


def as_rows(rows):
    if isinstance(rows,dict): return [rows]
    return rows if isinstance(rows,list) else []


def _profile_history(cx,domain,until=None):
    query=('SELECT s.id,s.imported_at,s.source,d.payload FROM datasets d '
           'JOIN snapshots s ON s.id=d.snapshot_id WHERE d.domain=?')
    params=[domain]
    if until is not None:query+=' AND s.id<=?';params.append(int(until))
    query+=' ORDER BY s.id DESC'
    out=[];previous_signature=None
    for r in cx.execute(query,params):
        rows=distinct_rows(as_rows(json.loads(r['payload'])))
        signature=_canonical_record(sorted((_canonical_record(x) for x in rows)))
        if signature!=previous_signature:
            out.append({'snapshot_id':r['id'],'imported_at':r['imported_at'],
                        'source':r['source'],'rows':rows})
            previous_signature=signature
        if len(out)==2:break
    return out


def profile_change_info(cx,until=None):
    """Display concrete changes without suggesting a LinkedIn score cause."""
    domains={d:_profile_history(cx,d,until) for d in ('EDUCATION','POSITIONS','SKILLS')}
    changes=[]
    fields={'EDUCATION':('Start Date','End Date','Degree Name'),
            'POSITIONS':('Started On','Finished On')}
    identity={'EDUCATION':('School Name',), 'POSITIONS':('Company Name','Title')}
    for domain in ('EDUCATION','POSITIONS'):
        timeline=domains[domain]
        if len(timeline)<2:continue
        newer,older=timeline
        old_by_key={tuple(str(r.get(k,'')).strip() for k in identity[domain]):r
                    for r in older['rows'] if isinstance(r,dict)}
        company_counts=collections.Counter(str(r.get('Company Name','')).strip() for r in older['rows'] if isinstance(r,dict))
        current_company_counts=collections.Counter(str(r.get('Company Name','')).strip() for r in newer['rows'] if isinstance(r,dict))
        for row in newer['rows']:
            if not isinstance(row,dict):continue
            key=tuple(str(row.get(k,'')).strip() for k in identity[domain])
            previous=old_by_key.get(key)
            # A corrected job title must not hide an updated start date. Only
            # fall back to company matching when it is unique on BOTH sides.
            company=str(row.get('Company Name','')).strip()
            if previous is None and domain=='POSITIONS' and company and company_counts[company]==1 and current_company_counts[company]==1:
                previous=next((r for r in older['rows'] if isinstance(r,dict) and str(r.get('Company Name','')).strip()==company),None)
            if previous is None:continue
            comparison_fields=fields[domain]+(('Title',) if domain=='POSITIONS' else ())
            for field in comparison_fields:
                before=str(previous.get(field) or '').strip();after=str(row.get(field) or '').strip()
                if before!=after:
                    changes.append({'domain':domain,'item':' / '.join(x for x in key if x)[:180],
                                    'field':field,'before':before,'after':after,
                                    'snapshot_id':newer['snapshot_id'],
                                    'source':newer['source'],'observed_at':newer['imported_at']})
    skill_history=domains['SKILLS']
    skills_added=[]
    if len(skill_history)>1:
        latest,prior=skill_history
        def values(x):return {str(r.get('Name','')).strip() for r in x['rows'] if isinstance(r,dict) and r.get('Name')}
        skills_added=sorted(values(latest)-values(prior))
    return {'changes':changes[:50],'skills_added':skills_added[:50],
            'method':'Vergleicht die jüngsten zwei unterschiedlichen gespeicherten Inhalte je Profilbereich, unabhängig von der Importquelle. Kein Nachweis einer Score-Ursache.'}


def profile_info(cx,until=None):
    profile=distinct_rows(as_rows(latest_domain(cx,'PROFILE',until)))
    positions=distinct_rows(as_rows(latest_domain(cx,'POSITIONS',until)))
    skills=distinct_rows(as_rows(latest_domain(cx,'SKILLS',until)))
    ed=distinct_rows(as_rows(latest_domain(cx,'EDUCATION',until)))
    return {'profile':profile[0] if profile else {},'positions':positions,
            'skills':[r.get('Name',r) if isinstance(r,dict) else r for r in skills],
            'education':ed,'skill_count':len(skills),'position_count':len(positions),
            'changes':profile_change_info(cx,until)}


def score_info(cx,until=None):
    rows=scores_history(cx,until)
    grouped=collections.defaultdict(dict)
    notability=[]; normalized=[]; topics=[]
    for r in rows:
        typ=r['score_type']; topic=r['topic'];cat=r['category'];date=r['measured_at']
        if typ=='Notability':
            notability.append(r)
        elif cat=='Topic normalized score':normalized.append(r)
        elif cat in DIMENSIONS:topics.append(r)
    latest={}
    for r in topics:
        key=(r['topic'],r['category'])
        if key not in latest or r['measured_at']>latest[key]['measured_at']:latest[key]=r
    for (topic,cat),r in latest.items():grouped[topic][cat]={'score':r['value'],'date':r['measured_at']}
    latest_norm={}
    for r in normalized:
        key=r['topic']
        if key not in latest_norm or r['measured_at']>latest_norm[key]['measured_at']:latest_norm[key]=r
    def last(cat):
        matches=[r for r in notability if r['category']==cat]
        return max(matches,key=lambda r:r['measured_at']) if matches else None
    ns=last('Aggregated notability score');nt=last('Discrete notability tier')
    # Each topic retains its exact LinkedIn name; apparent renamings are not merged.
    # Recency is compared to the latest available SCORE measurement, not import time.
    newest=max((r['measured_at'] for r in topics),default=None)
    cutoff=(dt.date.fromisoformat(newest)-dt.timedelta(days=14)).isoformat() if newest else None
    categorized=[]
    for name,dims in grouped.items():
        measured=max((v['date'] for v in dims.values()),default=None)
        categorized.append({'name':name,'dimensions':dims,'measured_at':measured,
                            'older_measurement':bool(cutoff and measured<cutoff),
                            'dimension_count':len(dims)})
    categorized.sort(key=lambda item:(item['measured_at'] or '',item['name']),reverse=True)
    return {'dimensions':DIMENSIONS,'topics':categorized,
            'latest_dimension_measurement':newest,'historical_cutoff':cutoff,
            'topics_recent':sum(not x['older_measurement'] for x in categorized),
            'topics_historical':sum(x['older_measurement'] for x in categorized),
            'top_knowledge':[{'topic':r['topic'],'score':r['value'],'date':r['measured_at']}
                             for r in sorted(latest_norm.values(),key=lambda r:-r['value'])[:25]],
            'notability':{'score':ns['value'] if ns else None,'date':ns['measured_at'] if ns else None,
                           'tier':nt['value'] if nt else None},
            'history':sorted([r for r in topics+notability+normalized if r['category'] in DIMENSIONS or
                              r['category'] in ['Aggregated notability score','Discrete notability tier']],
                              key=lambda r:(r['measured_at'],r['topic'],r['category'])),
            'point_count':len(rows),'measured_through':max((r['measured_at'] for r in rows),default=None)}


def net_info(cx,until=None):
    raw_connections=as_rows(latest_domain(cx,'CONNECTIONS',until))
    con=distinct_rows(raw_connections)
    raw_invites=as_rows(latest_domain(cx,'INVITATIONS',until))
    invites=distinct_rows(raw_invites)
    sent=sum(1 for r in invites if isinstance(r,dict) and str(r.get('Direction','')).upper()=='OUTGOING')
    received=sum(1 for r in invites if isinstance(r,dict) and str(r.get('Direction','')).upper()=='INCOMING')
    # Separate contact identity from exact record equality: two different exports
    # of the same account may contain different additional fields.
    identifiable=set()
    for r in con:
        if not isinstance(r,dict):continue
        key=str(r.get('URL') or r.get('Profile URL') or '').strip().lower().rstrip('/')
        if not key:
            key='|'.join(str(r.get(x,'')).strip().casefold() for x in ('First Name','Last Name','Company'))
        if key.strip('| '):identifiable.add(key)
    return {'connections_rows':len(con),'connections_raw_rows':len(raw_connections),
            'connections_exact_duplicates':len(raw_connections)-len(con),
            'unique_identifiers':len(identifiable),
            'invitations_rows':len(invites),'invitations_raw_rows':len(raw_invites),
            'invitation_exact_duplicates':len(raw_invites)-len(invites),
            'invitation_unique_records':len(invites), 'outgoing':sent,'incoming':received}


def content_info(cx,until=None):
    shares=distinct_rows(as_rows(latest_domain(cx,'MEMBER_SHARE_INFO',until)))
    comments=distinct_rows(as_rows(latest_domain(cx,'ALL_COMMENTS',until)))
    media=distinct_rows(as_rows(latest_domain(cx,'RICH_MEDIA',until)))
    counts=collections.Counter();dated=[]
    # Additional topics from the user's own declared skills make this useful
    # beyond ESG/Compliance. Exact phrase matching, not AI classification.
    skill_rows=distinct_rows(as_rows(latest_domain(cx,'SKILLS',until)))
    skill_labels=[]
    for item in skill_rows:
        name=str(item.get('Name','')).strip() if isinstance(item,dict) else str(item).strip()
        if 5<=len(name)<=45 and name not in skill_labels:
            skill_labels.append(name)
    skill_labels=skill_labels[:30]
    for r in shares:
        if not isinstance(r,dict):continue
        body=str(r.get('ShareCommentary') or r.get('shareCommentary') or r.get('Media Description') or '')
        hits=[name for name,regex in TERMS.items() if re.search(regex,body,re.I)]
        for name in skill_labels:
            if re.search(r'(?<!\w)'+re.escape(name)+r'(?!\w)',body,re.I):
                hits.append('Kenntnis: '+name)
        counts.update(hits)
        dated.append({'date':str(r.get('Date') or ''),'topics':hits,'preview':body[:130],
                      'url':str(r.get('ShareLink') or '')})
    return {'posts':len(shares),'comments':len(comments),'media':len(media),
            'topics':dict(counts),'recent_posts':dated[:25]}


def ad_info(cx,until=None):
    rows=as_rows(latest_domain(cx,'AD_TARGETING',until))
    if not rows:return {'skill_count':None,'skills':[]}
    row=rows[0]
    raw=row.get('Member Skills','') if isinstance(row,dict) else ''
    skills=sorted(set(x.strip() for x in str(raw).split(';') if x.strip()))
    return {'skill_count':len(skills),'skills':skills,
            'job_seniority':row.get('Job Seniorities',''),
            'experience':row.get('Years of Experience','')}


def data_inventory(cx,until=None):
    """Last saved dataset per domain, with explicit source and freshness.

    No payload, names, messages or content leave the local API response. The
    data_status returned to the UI contains only counts and import metadata.
    An unsuccessful API probe must never erase or refresh a previous dataset.
    """
    sql=('SELECT d.domain,d.payload,s.id,s.source,s.label,s.imported_at,s.reference_date, '
         'r.raw_records AS archive_raw,r.effective_records AS archive_unique '
         'FROM datasets d JOIN snapshots s ON s.id=d.snapshot_id '
         'LEFT JOIN api_raw_archives r ON r.snapshot_id=d.snapshot_id AND r.domain=d.domain')
    args=[]
    if until is not None:
        sql+=' WHERE s.id<=?';args=[int(until)]
    sql+=' ORDER BY s.id DESC, d.domain'
    seen=set(); result=[]
    for r in cx.execute(sql,args):
        if r['domain'] in seen:continue
        seen.add(r['domain'])
        try:raw=as_rows(json.loads(r['payload']))
        except (ValueError,TypeError):raw=[]
        distinct=(r['archive_unique'] if r['archive_unique'] is not None else len(distinct_rows(raw)))
        raw_total=(r['archive_raw'] if r['archive_raw'] is not None else len(raw))
        result.append({'domain':r['domain'],'source':r['source'],
                       'label':r['label'],'snapshot_id':r['id'],
                       'imported_at':r['imported_at'],'reference_date':r['reference_date'],
                       'raw_records':raw_total,'effective_records':distinct,
                       'exact_duplicates':raw_total-distinct,
                       'raw_archived':r['archive_raw'] is not None})
    return result


def _canonical_record(item):
    """Strict identity: retained as data provenance, never use for merging unrelated rows."""
    return json.dumps(item,sort_keys=True,ensure_ascii=False,default=str,separators=(',',':'))


def _audit_rows(payload):
    try: items=json.loads(payload)
    except (ValueError,TypeError):items=[]
    if isinstance(items,dict):items=[items]
    if not isinstance(items,list):items=[]
    identities={_canonical_record(item) for item in items}
    fields=sorted({str(key) for item in items if isinstance(item,dict) for key in item if key is not None})
    return {'raw':len(items),'unique':len(identities),'fields':fields,'ids':identities,'items':items}


def source_audit(cx,until=None):
    """Read-only API/ZIP coverage audit. Return metadata, NEVER raw records or identities.

    Does not treat a bigger dataset as authoritative. Existing app selection
    remains unchanged and must not be disguised as successful merging.
    """
    q=('SELECT d.domain,d.payload,s.source,s.id,s.imported_at,s.reference_date '
       'FROM datasets d JOIN snapshots s ON s.id=d.snapshot_id '
       "WHERE s.source IN ('api','zip')")
    args=[]
    if until is not None:q+=' AND s.id<=?';args=[int(until)]
    q+=' ORDER BY s.id DESC'
    candidates=collections.defaultdict(dict)
    for r in cx.execute(q,args):
        if r['source'] not in candidates[r['domain']]:
            item=_audit_rows(r['payload'])
            item.update({'snapshot_id':r['id'],'imported_at':r['imported_at'],
                         'reference_date':r['reference_date']})
            candidates[r['domain']][r['source']]=item
    out=[]
    for domain,by_source in sorted(candidates.items()):
        if domain=='ZIP_FILE_INDEX':continue
        row={'domain':domain}
        for source in ('api','zip'):
            if source in by_source:
                item=by_source[source]
                row[source]={k:item[k] for k in ('raw','unique','snapshot_id','imported_at','reference_date','fields')}
        if 'api' in by_source and 'zip' in by_source:
            a=by_source['api'];z=by_source['zip']
            row['strict_overlap']=len(a['ids']&z['ids'])
            row['api_only']=len(a['ids']-z['ids'])
            row['zip_only']=len(z['ids']-a['ids'])
            row['only_api_fields']=sorted(set(a['fields'])-set(z['fields']))
            row['only_zip_fields']=sorted(set(z['fields'])-set(a['fields']))
            row['status']='same' if a['ids']==z['ids'] else 'different'
        else:row['status']='only_api' if 'api' in by_source else 'only_zip'
        if domain=='ENDORSEMENTS':
            for source in ('api','zip'):
                if source not in by_source:continue
                items=by_source[source]['items']
                unique={_canonical_record(item):item for item in items}
                received=sum('Endorser Public Url' in x or 'Endorser First Name' in x for x in unique.values() if isinstance(x,dict))
                given=sum('Endorsee Public Url' in x or 'Endorsee First Name' in x for x in unique.values() if isinstance(x,dict))
                row[source]['received']=received
                row[source]['given']=given
            if 'api' in row and 'zip' in row and row['api']['received']==row['zip']['received']:
                row['note']='Erhaltene Bestätigungen stimmen zahlenmäßig überein; API kann zusätzlich vergebene Bestätigungen enthalten.'
        if domain=='ALL_COMMENTS' and 'api' in row and 'zip' in row:
            row['note']='Exakte Einträge weichen ab; der ZIP-Export kann zusätzliche Spalten besitzen. Differenzen sind keine gesicherten neuen Kommentare.'
        out.append(row)
    scores=scores_history(cx,until)
    measured=max((r['measured_at'] for r in scores),default=None)
    recent=sum(r['measured_at']==measured for r in scores) if measured else 0
    last_scores=cx.execute('SELECT s.id,s.source,s.imported_at FROM scores sc JOIN snapshots s ON s.id=sc.snapshot_id '+('WHERE s.id<=? ' if until is not None else '')+
         'ORDER BY s.id DESC LIMIT 1',([int(until)] if until is not None else [])).fetchone()
    runs=cx.execute('SELECT executed_at,requested,statuses_json FROM sync_runs ORDER BY id DESC LIMIT 1').fetchone()
    states={}
    if runs:
        try:
            parsed=json.loads(runs['statuses_json']);states=parsed.get('domains',parsed)
        except (TypeError,ValueError):pass
    errors=[{'domain':d,'state':v.get('state','unknown'),'http_status':v.get('http_status'),
             'reason':str(v.get('message',''))[:180]}
            for d,v in sorted(states.items()) if isinstance(v,dict) and v.get('state') in ('error','http_error')]
    return {'domains':out,'summary':{'total':len(out),
             'in_both':sum('api' in x and 'zip' in x for x in out),
             'matching':sum(x['status']=='same' for x in out),
             'different':sum(x['status']=='different' for x in out),
             'api_only':sum(x['status']=='only_api' for x in out),
             'zip_only':sum(x['status']=='only_zip' for x in out)},
            'api_errors':errors,'last_api_run':runs['executed_at'] if runs else None,
            'scores':{'latest_measured_at':measured,'unique_points_on_date':recent,
                       'last_import_source':last_scores['source'] if last_scores else None,
                       'last_imported_at':last_scores['imported_at'] if last_scores else None},
            'method':'Vergleich der letzten gespeicherten Daten je Quelle und Bereich. Strikte Datensatzidentität; keine automatische Zusammenführung, keine Wertweitergabe.'}


def overview(cx,until=None,share_safe=False):
    snapshots=snapshot_list(cx)
    if until is not None:snapshots=[x for x in snapshots if x['id']<=int(until)]
    scoring=score_info(cx,until);p=profile_info(cx,until);n=net_info(cx,until)
    a=ad_info(cx,until);c=content_info(cx,until)
    result={'snapshots':snapshots,'scores':scoring,'profile':p,'network':n,'ads':a,'content':c}
    syncrow=cx.execute('SELECT executed_at,requested,statuses_json FROM sync_runs ORDER BY id DESC LIMIT 1').fetchone()
    if syncrow:
        details=json.loads(syncrow['statuses_json'])
        states=details.get('domains',details)
        result['latest_api_sync']={'executed_at':syncrow['executed_at'],
                                   'requested_domains':syncrow['requested'],
                                   'status_by_domain':{k:{'state':v.get('state','unknown'),
                                     'rows':v.get('rows',0), 'raw_rows':v.get('raw_rows',v.get('rows',0)),
                                     'exact_duplicates':v.get('exact_duplicates',0),
                                     'message':str(v.get('message',''))[:130]} for k,v in states.items() if isinstance(v,dict)}}
    else:result['latest_api_sync']=None
    if not share_safe:result['data_inventory']=data_inventory(cx,until)
    result['analysis']=advise(cx,p,n,c,scoring,until)
    if share_safe:
        coverage={}
        raw_coverage={}
        duplicates_coverage={}
        for rec in cx.execute('SELECT domain,payload FROM datasets WHERE snapshot_id IN (SELECT max(snapshot_id) FROM datasets GROUP BY domain)'):
            # Counts only, no payload values, no names or individual records.
            try:
                items=__import__('json').loads(rec['payload'])
                rows=as_rows(items)
                coverage[rec['domain']]=len(distinct_rows(rows))
                raw_coverage[rec['domain']]=len(rows)
                duplicates_coverage[rec['domain']]=len(rows)-coverage[rec['domain']]
            except (TypeError,ValueError):pass
        # Baseline is intentionally historical; never pass it off as a new API score.
        score_origin=('Lokale historische Score-Daten bis '+str(scoring.get('measured_through'))+
                      ', nicht als neue API-Bewertung bestätigt') if scoring['point_count'] else 'Kein Score-Wert vorhanden'
        retained=[]
        if not scoring['point_count']:
            baseline=ROOT/'reference'/'credibility-baseline.json'
            if baseline.is_file():
                try:
                    historic=json.loads(baseline.read_text(encoding='utf-8')).get('scores')
                    if isinstance(historic,dict) and historic.get('point_count',0)>0:
                        scoring=historic
                        retained=['scores']
                        score_origin=('Historische Score-Basis bis '+str(historic.get('measured_through'))+
                                      '; nicht neu durch die LinkedIn-API bestätigt')
                except (ValueError,OSError):
                    pass
        last_sync=None
        try:
            syncrow=cx.execute('SELECT executed_at,requested,statuses_json FROM sync_runs ORDER BY id DESC LIMIT 1').fetchone()
            if syncrow:
                detail=json.loads(syncrow['statuses_json'])
                statuses=detail.get('domains',detail)
                last_sync={'executed_at':syncrow['executed_at'],
                           'requested_domains':syncrow['requested'],
                           'authorization':detail.get('authorization',{'state':'not_checked'}),
                           'domains_with_data':sum(isinstance(v,dict) and v.get('rows',0)>0 for v in statuses.values()),
                           'status_by_domain':{k:('data' if isinstance(v,dict) and v.get('rows',0)>0 else
                               ('HTTP '+re.search(r'HTTP\s+(\d{3})',str(v.get('message',''))).group(1) if
                                 isinstance(v,dict) and re.search(r'HTTP\s+(\d{3})',str(v.get('message',''))) else
                                'empty/unavailable')) for k,v in statuses.items()}}
        except Exception:
            pass
        # Published to GitHub: only professional score categories, no contact lists,
        # emails, tokens, personal messages, exact profile text or post text.
        return {'generated_at':dt.datetime.now(dt.timezone.utc).isoformat(),
                'source_notice':'LinkedIn export/API classifications; not evidence of feed ranking.',
                'latest_snapshot':snapshots[0]['reference_date'] or snapshots[0]['imported_at'] if snapshots else None,
                'coverage':{'domains':coverage,'raw_domains':raw_coverage,
                            'exact_duplicates_by_domain':duplicates_coverage,'domain_count':len(coverage)},
                'scores':scoring,
                'score_data_origin':score_origin,
                'retained_historical_sections':retained,
                'latest_api_sync':last_sync,
                'network':n,'content':{'posts':c['posts'],'comments':c['comments'],
                                      'media':c['media'],'topics':c['topics']},
                'profile':{'skill_count':p['skill_count'],'position_count':p['position_count']},
                'ads':{'skill_count':a['skill_count']},
                'analysis':{'method':result['analysis']['method'],
                            'endorsements':{k:v for k,v in result['analysis']['endorsements'].items() if k!='received_by_skill'},
                            'quality':{k:{a:v for a,v in d.items() if a!='source'} for k,d in result['analysis']['quality'].items()},
                            'recommendations':result['analysis']['recommendations']}}
    return result


# V2.8: observation log for real LinkedIn post statistics. This deliberately
# does not confuse the member's OWN comments with incoming post discussion.
import urllib.parse
import hashlib
from datetime import datetime, timezone

REACH_NUMBERS = ('impressions','reach','reactions','comments','reposts','saves','clicks',
                 'video_views','substantive_comments','new_participants','own_comments')


def _integer_or_none(val,name,required=False):
    if val is None or val=='':
        if required:raise ValueError(name+' ist erforderlich.')
        return None
    if isinstance(val,bool):raise ValueError(name+' muss eine Zahl sein.')
    if isinstance(val,float) and not val.is_integer():raise ValueError(name+' muss ganzzahlig sein.')
    if not str(val).strip().isdigit():raise ValueError(name+' muss eine nichtnegative Ganzzahl sein.')
    num=int(val)
    if num>1_000_000_000:raise ValueError(name+' ist zu groß.')
    return num


def _observation_time(value):
    if not value:return datetime.now(timezone.utc).isoformat(timespec='seconds')
    if not isinstance(value,str) or len(value)>40:raise ValueError('Ungültiges Messdatum.')
    try:
        raw=value.replace('Z','+00:00')
        d=datetime.fromisoformat(raw)
        if d.tzinfo is None:raise ValueError()
        d=d.astimezone(timezone.utc)
        if d>datetime.now(timezone.utc)+dt.timedelta(minutes=5):raise ValueError()
        return d.isoformat(timespec='seconds')
    except (TypeError,ValueError):raise ValueError('Messdatum muss eine gültige Uhrzeit mit Zeitzone sein.')


def _post_identity(channel,url,title,published):
    if channel not in ('private','company'):raise ValueError('Kanal muss Privatprofil oder Unternehmensseite sein.')
    url=str(url or '').strip()
    if len(url)>1000:raise ValueError('Link zu lang.')
    if url:
        try:
            parsed=urllib.parse.urlsplit(url)
            if parsed.scheme!='https' or (parsed.hostname or '').lower() not in ('linkedin.com','www.linkedin.com'):
                raise ValueError()
            if not parsed.path.startswith(('/posts/','/feed/update/','/pulse/')):
                raise ValueError()
            normalized='linkedin.com'+parsed.path.rstrip('/').lower()
        except ValueError:raise ValueError('Nur gültige https-Links zu LinkedIn-Beiträgen verwenden.')
    else:
        if not title.strip() or not published.strip():
            raise ValueError('Ohne Beitragslink sind Titel und Veröffentlichungsdatum nötig.')
        normalized=title.strip().casefold()+'|'+published.strip()
    return hashlib.sha256((channel+'|'+normalized).encode('utf-8')).hexdigest()[:28],url


def save_post_observation(cx, record, source='manual'):
    if not isinstance(record,dict):raise ValueError('Ungültiger Messstand.')
    channel=str(record.get('channel') or '').strip()
    title=str(record.get('title') or '').strip()[:240]
    published=str(record.get('published_at') or '').strip()[:40]
    post_key,url=_post_identity(channel,record.get('url'),title,published)
    values={key:_integer_or_none(record.get(key),key,key=='impressions') for key in REACH_NUMBERS}
    if values['reach'] is not None and values['reach']>values['impressions']:
        raise ValueError('Erreichte Mitglieder dürfen Impressionen nicht übersteigen.')
    for k in ('substantive_comments','new_participants','own_comments'):
        if values[k] is not None and values['comments'] is not None and values[k]>values['comments']:
            raise ValueError(k+' darf die Kommentarzahl nicht übersteigen.')
    watch=record.get('avg_watch_seconds')
    if watch is not None and watch!='':
        try:
            watch=float(watch)
            if watch<0 or watch>100000:raise ValueError()
        except (ValueError,TypeError):raise ValueError('Ungültige Wiedergabezeit.')
    else:watch=None
    notes=str(record.get('notes') or '').strip()[:500]
    observed_at=_observation_time(record.get('observed_at'))
    fields=['channel','post_key','post_url','title','published_at','observed_at','source',*REACH_NUMBERS,'avg_watch_seconds','notes']
    data=[channel,post_key,url,title,published,observed_at,source]+[values[k] for k in REACH_NUMBERS]+[watch,notes]
    sql='INSERT INTO post_observations ('+','.join(fields)+') VALUES ('+','.join('?' for _ in fields)+')'
    cursor=cx.execute(sql,data);cx.commit()
    return {'id':cursor.lastrowid,'post_key':post_key,'observed_at':observed_at}


def delete_post_observation(cx, obs_id):
    if not isinstance(obs_id,int) or isinstance(obs_id,bool) or obs_id<1:raise ValueError('Ungültiger Messstand.')
    cursor=cx.execute('DELETE FROM post_observations WHERE id=?',(obs_id,));cx.commit()
    return bool(cursor.rowcount)


def _parse_datetime_for_age(value):
    if not value:return None
    try:
        raw=value.replace('Z','+00:00')
        if len(raw)==10:raw+='T00:00:00'
        result=datetime.fromisoformat(raw)
        if result.tzinfo is None:
            try:
                from zoneinfo import ZoneInfo
                result=result.replace(tzinfo=ZoneInfo('Europe/Berlin'))
            except Exception:
                # Native Windows Python may have no IANA timezone database.
                # Europe/Berlin DST: last Sunday in March through last Sunday
                # in October. Transition-hour posts have indeterminate local
                # time and therefore no reliable age.
                import calendar
                def last_sunday(year,month):
                    last=calendar.monthrange(year,month)[1]
                    return last-(datetime(year,month,last).weekday()+1)%7
                year=result.year
                summer_start=datetime(year,3,last_sunday(year,3),2)
                summer_end=datetime(year,10,last_sunday(year,10),3)
                if summer_start<=result<summer_start+dt.timedelta(hours=1) or \
                   summer_end-dt.timedelta(hours=1)<=result<summer_end:
                    return None
                offset=2 if summer_start<=result<summer_end else 1
                result=result.replace(tzinfo=dt.timezone(dt.timedelta(hours=offset)))
        return result
    except ValueError:return None


def _reach_diagnosis(latest,older):
    impressions=latest['impressions'];comments=latest['comments']
    result={'level':'unknown','title':'Noch keine Verlaufsdiagnose',
            'detail':'Ein einzelner Datenstand zeigt nicht, ob LinkedIn die Ausspielung verzögert oder begrenzt hat.'}
    if not older:
        if impressions<100:
            result['detail']='Wenige Impressionen im bisherigen Messstand. Für die Ursachenanalyse ist eine zweite Messung desselben Beitrags nötig.'
        if comments and comments>0:
            result['detail']+=' Kommentare sind vorhanden; deren fachliche Qualität ist aus den Zählwerten nicht ablesbar.'
        return result
    previous=older['impressions'];gain=impressions-previous
    if gain<0:
        return {'level':'warning','title':'Messwerte nicht vergleichbar',
                'detail':'Der neuere Export weist weniger Impressionen als der ältere aus. Mögliche Korrektur durch LinkedIn oder abweichende Messgrundlage.'}
    if gain==0 and comments and comments>0:
        return {'level':'watch','title':'Diskussion bei unveränderter Impressionenzahl',
                'detail':'Seit der letzten Messung keine zusätzlichen Impressionen, obwohl Kommentare vorhanden sind. Ob diese vor oder nach der ersten Messung entstanden, ist nicht gesichert.'}
    if comments is not None and older['comments'] is not None and comments>older['comments']:
        return {'level':'watch','title':'Kommentar- und Reichweitenverlauf gemeinsam betrachten',
                'detail':f"Zwischen den Messungen: {comments-older['comments']} zusätzliche Kommentarereignisse und {gain} zusätzliche Impressionen. Das belegt weder einen positiven noch einen negativen Algorithmuseffekt."}
    if gain==0:
        return {'level':'watch','title':'Ausspielung im Messintervall unverändert',
                'detail':'Seit dem vorherigen Messstand sind keine weiteren Impressionen hinzugekommen. Einzelne Intervalle beweisen keine kontoweite Drosselung.'}
    return {'level':'info','title':'Reichweite hat zugenommen',
            'detail':f'{gain} zusätzliche Impressionen seit der letzten Messung. Ohne geeignete Vergleichsbeiträge lässt sich das Wachstum nicht als gut oder schlecht einstufen.'}


def reach_monitor(cx,limit_posts=100):
    records=[dict(r) for r in cx.execute('SELECT * FROM post_observations ORDER BY observed_at DESC,id DESC LIMIT 2000')]
    by_key=collections.defaultdict(list)
    for r in records:by_key[(r['channel'],r['post_key'])].append(r)
    posts=[]
    for key,history in by_key.items():
        if len(posts)>=limit_posts:break
        latest=history[0];previous=history[1] if len(history)>1 else None
        observed=_parse_datetime_for_age(latest['observed_at'])
        pub=_parse_datetime_for_age(latest['published_at'])
        age_hours=round((observed-pub).total_seconds()/3600,1) if observed and pub else None
        if age_hours is not None and age_hours<0:age_hours=None
        info=_reach_diagnosis(latest,previous)
        try:context=cx.execute('SELECT stage,series,context_note FROM post_editorial_context WHERE channel=? AND post_key=?',key).fetchone()
        except __import__('sqlite3').OperationalError:context=None
        summary={'channel':latest['channel'],'post_key':latest['post_key'],'title':latest['title'],
                 'url':latest['post_url'],'published_at':latest['published_at'],
                 'observed_at':latest['observed_at'],'age_hours':age_hours,
                 'latest':latest,'previous':previous,'diagnosis':info,
                 'history':history[:30],'measurements':len(history),
                 'editorial':dict(context) if context else {'stage':'unknown','series':'','context_note':''}}
        posts.append(summary)
    posts.sort(key=lambda x:(x['latest']['observed_at'],x['latest']['id']),reverse=True)
    # Only an explicit editorial assignment creates a series; topics and
    # similar titles never establish this relationship automatically.
    series=collections.defaultdict(list)
    for post in posts:
        name=post['editorial']['series'].strip()
        if name:
            series[(post['channel'],name.casefold())].append(post)
    grouped=[]
    for (channel,_),items in series.items():
        items.sort(key=lambda p:(p['published_at'],p['post_key']))
        grouped.append({'channel':channel,'name':items[0]['editorial']['series'],
                        'items':[{'title':p['title'],'post_key':p['post_key'],
                                  'stage':p['editorial']['stage'],
                                  'published_at':p['published_at'],
                                  'impressions':p['latest']['impressions'],
                                  'age_hours':p['age_hours'],'url':p['url']}
                                 for p in items]})
    grouped.sort(key=lambda x:(len(x['items']),x['name']),reverse=True)
    return {'posts':posts,'series':grouped,'total_posts':len(by_key),'total_observations':len(records),
            'method':'Persönliche Messstände. Kommentare, fachlicher Gehalt und neue Teilnehmer nur soweit ausdrücklich erfasst. Keine automatische Freundeswertung.',
            'limitations':['Die persönliche DMA-API liefert nicht zuverlässig eingehende Kommentare und Unternehmensseiten-Analysen.',
                           'Persönliche Beziehungen dürfen nicht als Gefälligkeitskommentar klassifiziert werden.',
                           'Interaktionsereignisse sind keine unterschiedlichen Personen und kein bestätigtes Ranking-Signal.']}

# V2.9 company page analytics: separate local imports, no DMA API assumptions.
_COMPANY_STOCK={'total_followers'}
_COMPANY_RATIO={'engagement_rate','click_through_rate'}


def save_company_export(cx,export,payload):
    """Idempotent by SHA; preserve original file locally, newest overlapping import wins."""
    sha=export['sha256']
    already=cx.execute('SELECT id,filename,imported_at FROM company_imports WHERE sha256=?',(sha,)).fetchone()
    if already:return {'duplicate_file':True,'import_id':already['id'],'filename':already['filename'],
                       'imported_at':already['imported_at']}
    archive=ROOT/'data'/'company_exports'/ (sha+Path(export['filename']).suffix.lower())
    archive.parent.mkdir(parents=True,exist_ok=True)
    if not archive.exists():
        import tempfile
        with tempfile.NamedTemporaryFile(dir=archive.parent,prefix='.upload-',delete=False) as tf:
            tmp=Path(tf.name)
            tf.write(payload)
        tmp.replace(archive)
    cx.execute('INSERT INTO company_imports(sha256,filename,imported_at,payload,warnings_json) '
               'VALUES (?,?,datetime("now"),?,?)',
               (sha,export['filename'],json.dumps(export['rows'],ensure_ascii=False,separators=(',',':')),
                json.dumps(export['warnings'],ensure_ascii=False)))
    id=cx.execute('SELECT last_insert_rowid()').fetchone()[0]
    cx.commit()
    return {'duplicate_file':False,'import_id':id,'filename':export['filename'],
            'imported_rows':len(export['rows']),'sheets':export['sheets'],'warnings':export['warnings']}


def company_page_report(cx):
    """No multi-file summation: latest available metric per day/post wins."""
    imports=[dict(r) for r in cx.execute('SELECT id,filename,imported_at,sha256,warnings_json,payload FROM company_imports ORDER BY id ASC')]
    combined={}
    post_lookup={}
    for imp in imports:
        for row in json.loads(imp['payload']):
            kind=row['kind']; day=row['date'];post=row.get('post','')
            if kind=='post':
                import re as _re
                identity=post.casefold().split('?')[0].strip().rstrip('/')
                post_key=(day,identity)
                post_lookup[post_key]={'post':post,'title':row.get('title','') or post}
            for name,val in row['metrics'].items():
                key=(kind,day,post.casefold().split('?')[0].strip().rstrip('/') if kind=='post' else '',name)
                combined[key]=val
    days={};posts={}
    for (kind,day,identity,metric),value in combined.items():
        if kind=='daily':days.setdefault(day,{})[metric]=value
        else:
            label=post_lookup.get((day,identity),{'post':identity,'title':identity})
            item=posts.setdefault((day,identity),{'date':day,'post':label['post'],
                                                  'title':label['title'],'metrics':{}})
            item['metrics'][metric]=value
    timeseries=[{'date':day,**metrics} for day,metrics in sorted(days.items())]
    posts_list=sorted(posts.values(),key=lambda r:(r['date'],r['post']),reverse=True)
    last30=timeseries[-30:]
    snapshot={}
    for metric in sorted({k for d in timeseries for k in d if k!='date'}):
        measured=[d for d in timeseries if metric in d]
        if not measured:continue
        if metric in _COMPANY_STOCK:snapshot[metric]={'value':measured[-1][metric],'date':measured[-1]['date'],'method':'last'}
        elif metric in _COMPANY_RATIO:snapshot[metric]={'value':measured[-1][metric],'date':measured[-1]['date'],'method':'last'}
        else:snapshot[metric]={'value':sum(d[metric] for d in last30 if metric in d),
                               'date':last30[-1]['date'] if last30 else '',
                               'method':'last_30_observed_dates','observed_days':sum(metric in d for d in last30)}
    return {'imports':[{'id':i['id'],'filename':i['filename'],'imported_at':i['imported_at'],
                        'warnings':json.loads(i['warnings_json'])} for i in reversed(imports)],
            'import_count':len(imports),'daily':timeseries[-400:], 'posts':posts_list[:200],
            'post_total':len(posts_list),'summary':snapshot,
            'last_day':timeseries[-1]['date'] if timeseries else None,
            'method':'Überlappende Tage und Beiträge werden je Kennzahl mit dem letzten Exportstand ersetzt, nicht addiert. Monats- und 30-Tage-Summen nur aus erkannten Tageswerten; fehlende Tage werden nicht als Null angenommen.',
            'limitations':['Die Unternehmensseite besitzt hier keinen API-Zugang. Nur explizit importierte LinkedIn-Seitenexporte werden ausgewertet.',
                           'Klicks, Impressionen und Followerwerte dürfen nicht kanalübergreifend mit Profilstatistiken vermischt werden.',
                           'Nicht unterstützte Demografie- oder Zusammenfassungsblätter werden nicht als Tagesdaten geraten.',
                           'Aktualisierte Gesamtmetriken einzelner Beiträge sind kein Verlauf von Tagesimpressionen.']}


# V2.9.3: personal aggregate exports; this is NOT the company page tracker.
def save_personal_aggregate(cx,export):
    old=cx.execute('SELECT id,payload FROM personal_aggregate_imports WHERE sha256=?',
                   (export['sha256'],)).fetchone()
    if old:
        prior=json.loads(old['payload'])
        if len(export['posts'])>len(prior.get('posts',[])) or (export.get('exported_at') and not prior.get('exported_at')):
            safe={k:export[k] for k in ('summary','daily','follower_daily','posts','warnings','sheets','exported_at')}
            cx.execute('UPDATE personal_aggregate_imports SET payload=? WHERE id=?',
                       (json.dumps(safe,ensure_ascii=False,separators=(',',':')),old['id']))
            cx.commit()
            return {'duplicate_file':True,'upgraded_existing':True,'import_id':old['id'],
                    'posts':len(export['posts']),'days':len(export['daily'])}
        return {'duplicate_file':True,'upgraded_existing':False,'import_id':old['id'],
                'posts':len(prior.get('posts',[])),'days':len(export['daily'])}
    safe={k:export[k] for k in ('summary','daily','follower_daily','posts','warnings','sheets','exported_at')}
    cx.execute('INSERT INTO personal_aggregate_imports '
               '(sha256,filename,imported_at,period_start,period_end,payload) '
               'VALUES(?,?,datetime("now"),?,?,?)',
               (export['sha256'],export['filename'],export['period_start'],
                export['period_end'],json.dumps(safe,ensure_ascii=False,separators=(',',':'))))
    rid=cx.execute('SELECT last_insert_rowid()').fetchone()[0]
    cx.commit()
    return {'duplicate_file':False,'import_id':rid,'days':len(export['daily']),
            'posts':len(export['posts']),'warnings':export['warnings']}


def personal_aggregate_report(cx):
    rows=[dict(r) for r in cx.execute('SELECT * FROM personal_aggregate_imports '
                                     'ORDER BY period_end,id')]
    daily={};followers={};post_previews={};files=[]
    for imp in rows:
        data=json.loads(imp['payload'])
        files.append({'id':imp['id'],'filename':imp['filename'],
                      'period_start':imp['period_start'],'period_end':imp['period_end'],
                      'imported_at':imp['imported_at'],'warnings':data.get('warnings',[])})
        for d in data.get('daily',[]):daily[d['date']]={**d,'source_import':imp['id']}
        for d in data.get('follower_daily',[]):followers[d['date']]={**d,'source_import':imp['id']}
        for p in data.get('posts',[]):
            # Do not mix post snapshots from aggregate and SinglePost files.
            post_previews[p['url'].split('?')[0]]={**p,'source_import':imp['id']}
    newest=rows[-1] if rows else None
    summary=json.loads(newest['payload'])['summary'] if newest else {}
    ordered=sorted(daily.values(),key=lambda d:d['date'])
    follower_ordered=sorted(followers.values(),key=lambda d:d['date'])
    return {'import_count':len(rows),'imports':list(reversed(files)),
            'daily':ordered[-400:],'follower_daily':follower_ordered[-400:],
            'latest_summary':{**summary,'period_start':newest['period_start'],
                              'period_end':newest['period_end']} if newest else {},
            'recent_posts':sorted(post_previews.values(),key=lambda p:(p['published_date'],p['url']),reverse=True)[:50],
            'method':'Überlappende Tageswerte aus neueren Berichtszeiträumen ersetzen ältere Werte je Tag. Keine Summierung über Exportdateien und keine Vermischung von Einzelbeitrags- mit Wochenmetriken. Reichweite ist nicht additiv über verschiedene Tage.',
            'limitations':['Importzeitpunkt ist nicht der tatsächliche Messzeitpunkt der einzelnen Beiträge.',
                           'Einzelbeiträge in der Wochenübersicht werden nicht in den Verlauf der Einzelbeitragsmessungen übernommen.',
                           'Video-Kennzahlen werden nur bei ausdrücklich als Video gekennzeichneten Beiträgen gelesen.']}


POST_STAGES=('unknown','preview','live','result','deepdive','evergreen')

def save_post_context(cx,record):
    if not isinstance(record,dict):raise ValueError('Ungültige Beitragskontextdaten.')
    channel=record.get('channel')
    key=record.get('post_key')
    stage=record.get('stage','unknown')
    series=record.get('series','')
    note=record.get('context_note','')
    if channel not in ('private','company') or not isinstance(key,str) or not re.fullmatch(r'[0-9a-f]{28}',key):
        raise ValueError('Ungültige Beitragskennung.')
    if stage not in POST_STAGES:raise ValueError('Unbekannter Beitragszweck.')
    if not isinstance(series,str) or len(series)>120 or not isinstance(note,str) or len(note)>400:
        raise ValueError('Beitragsbeschreibung zu lang.')
    if not cx.execute('SELECT 1 FROM post_observations WHERE channel=? AND post_key=? LIMIT 1',
                      (channel,key)).fetchone():
        raise ValueError('Beitrag ist noch nicht importiert.')
    cx.execute('INSERT INTO post_editorial_context(channel,post_key,stage,series,context_note,updated_at) '
               'VALUES(?,?,?,?,?,datetime("now")) ON CONFLICT(channel,post_key) '
               'DO UPDATE SET stage=excluded.stage,series=excluded.series,'
               'context_note=excluded.context_note,updated_at=excluded.updated_at',
               (channel,key,stage,series.strip(),note.strip()))
    cx.commit()
    return {'channel':channel,'post_key':key,'stage':stage,'series':series.strip(),'context_note':note.strip()}


# V2.9.6: each imported weekly contribution remains a separate source measurement.
def _v296_personal_aggregate_history(cx):
    import urllib.parse
    def post_id(url):
        m=re.search(r'(?<!\d)(\d{15,22})(?!\d)',urllib.parse.unquote(str(url or '')))
        return m.group(1) if m else ''
    rows=cx.execute('SELECT id,imported_at,period_start,period_end,payload '
                    'FROM personal_aggregate_imports ORDER BY id').fetchall()
    history={};imports=[]
    for row in rows:
        data=json.loads(row['payload'])
        stamp=data.get('exported_at') or ''
        imports.append((row['period_end'],stamp,int(row['id'])))
        in_file={}
        for post in data.get('posts',[]):
            ident=post_id(post.get('url'))
            if not ident:continue
            prior=in_file.get(ident)
            if prior is None or (prior.get('reach') is None and post.get('reach') is not None):
                in_file[ident]=post
        for ident,post in in_file.items():
            history.setdefault(ident,[]).append({
                'source_import':int(row['id']),'period_start':row['period_start'],
                'period_end':row['period_end'],'exported_at':stamp,
                'impressions':post.get('impressions'),'reach':post.get('reach'),
                'format':post.get('format'),'published_date':post.get('published_date'),
                'comments':post.get('comments'),'reactions':post.get('reactions'),
                'top_engagement':post.get('top_engagement')})
    latest_id=max(imports)[2] if imports else None
    result={}
    for ident,series in history.items():
        series.sort(key=lambda x:(x['period_end'],x['exported_at'],x['source_import']))
        last=dict(series[-1])
        prev=next((p for p in reversed(series[:-1])
                   if p['period_start']==last['period_start']
                   and p['period_end']==last['period_end']
                   and p['impressions'] is not None),None)
        last['previous_impressions']=prev['impressions'] if prev else None
        last['change_since_previous']=(last['impressions']-prev['impressions']
            if prev and last['impressions'] is not None else None)
        last['not_in_latest_import']=last['source_import']!=latest_id
        last['measurement_count']=len(series)
        last['metric_scope']='selected_export_period'
        result[ident]=last
    return result

# V2.9.5 – selectable local extended content report. Explicitly private by default.
def extended_content_report(cx, until=None, include_text=True):
    """All own share records with provenance, format and observed reach.

    This report is not the share-safe curated report: authorship and original
    commentary can be personal; it is sent only to the loopback application.
    """
    import unicodedata
    sql=('SELECT s.id,s.source,s.imported_at,s.label FROM datasets d '
         'JOIN snapshots s ON s.id=d.snapshot_id WHERE d.domain=?')
    args=['MEMBER_SHARE_INFO']
    if until is not None:sql+=' AND s.id<=?';args.append(int(until))
    latest=cx.execute(sql+' ORDER BY s.id DESC LIMIT 1',args).fetchone()
    # Retain older contributions even when the newest LinkedIn API response
    # omits entries already observed in earlier API or ZIP snapshots.
    all_sql=('SELECT s.id,s.source,d.payload FROM datasets d '
             'JOIN snapshots s ON s.id=d.snapshot_id WHERE d.domain=?')
    if until is not None:all_sql+=' AND s.id<=?'
    all_sql+=' ORDER BY s.id DESC'
    source_rows=[]; seen=set()
    from hashlib import sha256
    def share_fingerprint(row):
        if not isinstance(row,dict):return ''
        url=str(row.get('ShareLink') or row.get('shareLink') or '').split('?')[0].rstrip('/')
        if url:return 'url:'+url
        body=str(row.get('ShareCommentary') or row.get('shareCommentary') or row.get('Media Description') or '')
        date=str(row.get('Date') or row.get('date') or '')
        return 'body:'+sha256((date+'\n'+body).encode('utf-8')).hexdigest()
    for snap in cx.execute(all_sql,args):
        for row in distinct_rows(as_rows(json.loads(snap['payload']))):
            key=share_fingerprint(row)
            if not key or key in seen:continue
            seen.add(key)
            source_rows.append((row,snap))
    records=[]
    for r,snap in source_rows:
        if not isinstance(r,dict):continue
        body=str(r.get('ShareCommentary') or r.get('shareCommentary') or r.get('Media Description') or '')
        url=str(r.get('ShareLink') or r.get('shareLink') or '')
        date=str(r.get('Date') or r.get('date') or '')
        normalized=unicodedata.normalize('NFKC',body)
        has_styled_chars=normalized!=body
        topics=[name for name,pattern in TERMS.items() if re.search(pattern,normalized,re.I)]
        image_hint=any(k.lower() in ' '.join(map(str,r.keys())).lower() for k in ['media','image'])
        records.append({'published_at':date,'url':url,'text':body if include_text else None,
                        'preview':body[:200], 'characters':len(body),
                        'words':len(body.split()),'styled_unicode':has_styled_chars,
                        'topics':topics,'media_hint':image_hint,
                        'source':str(snap['source']),
                        'snapshot_id':int(snap['id']),
                        'historical_only':bool(latest and int(snap['id'])!=int(latest['id']))})
    # Exact newest-vs-previous stored share snapshot comparison. A ZIP/API
    # comparison is labelled as such, and does not establish the chronology
    # of LinkedIn publication or a live API update by itself.
    previous=cx.execute(sql+' AND s.id<? ORDER BY s.id DESC LIMIT 1',args+[int(latest['id'])]).fetchone() if latest else None
    previous_ids=set()
    previous_count=None
    if previous:
        old_rows=distinct_rows(as_rows(latest_domain(cx,'MEMBER_SHARE_INFO',int(previous['id']))))
        previous_count=len(old_rows)
        previous_ids={share_fingerprint(r) for r in old_rows}
        for rec in records:
            rec['new_since_previous_snapshot']=(not rec['historical_only'] and share_fingerprint({'ShareLink':rec['url'],
                                    'ShareCommentary':rec['text'] or rec['preview'],
                                    'Date':rec['published_at']}) not in previous_ids)
    else:
        for rec in records:rec['new_since_previous_snapshot']=None
    # Observations are never treated as an API-provided reach timeline.
    observations=[dict(x) for x in cx.execute('SELECT post_url,post_key,published_at,observed_at,source,impressions,reach,reactions,comments,reposts,saves,clicks,video_views FROM post_observations WHERE channel=? ORDER BY observed_at DESC,id DESC',('private',))]
    by_url={};by_id={}
    def ident(u):
        m=re.search(r'(?<!\d)(\d{15,22})(?!\d)',str(u))
        return m.group(1) if m else ''
    for o in observations:
        key=(o.get('post_url') or '').split('?')[0].rstrip('/')
        if key and key not in by_url:by_url[key]=o
        iid=ident(key) or ident(o.get('post_key'))
        if iid and iid not in by_id:by_id[iid]=o
    for rec in records:
        u=rec['url'].split('?')[0].rstrip('/')
        rec['reach_observation']=by_url.get(u) or by_id.get(ident(u)) if u else None
    records.sort(key=lambda r:(r['published_at'],r['url']),reverse=True)
    # V2.9.6: match official export records by immutable numeric LinkedIn ID.
    aggregate_by_id=_v296_personal_aggregate_history(cx)
    for rec in records:
        rec['aggregate_summary']=aggregate_by_id.get(ident(rec['url']))
    return {'generated_at':dt.datetime.now(dt.timezone.utc).isoformat(),
            'snapshot':{'id':int(latest['id']),'source':str(latest['source']),
                        'imported_at':str(latest['imported_at'])} if latest else None,
            'total':len(records),'posts':records,
            'comparison':{'previous_snapshot_id':int(previous['id']) if previous else None,
                          'previous_source':str(previous['source']) if previous else None,
                          'previous_count':previous_count,
                          'new_count':sum(r['new_since_previous_snapshot'] is True for r in records) if previous else None},
            'summary':{'with_text':sum(bool(r['preview']) for r in records),
                       'from_older_snapshots':sum(r['historical_only'] for r in records),
                       'with_link':sum(bool(r['url']) for r in records),
                       'with_observation':sum(bool(r['reach_observation']) for r in records),
                       'with_aggregate_summary':sum(bool(r['aggregate_summary']) for r in records),
                       'styled_unicode':sum(r['styled_unicode'] for r in records),
                       'short_under_1500':sum(0<r['characters']<1500 for r in records),
                       'long_over_2500':sum(r['characters']>=2500 for r in records)},
            'method':('Vollständiger lokaler Share-Bestand aus neuesten und älteren MEMBER_SHARE_INFO-Snapshots, nach URL dedupliziert; '
                      'Reichweitenmessungen aus SinglePostAnalytics bzw. manuellen Messständen; Wochenexporte getrennt als kumulierte Beitragsübersicht gekennzeichnet. '
                      'Keine Bewertung der LinkedIn-Feed-Klassifikation.'),
            'limitations':['Die DMA-Daten enthalten keine vollständigen Impressionen pro Beitrag.',
                           'AggregateAnalytics-Einzelbeitragswerte können älter sein und sind keine Messzeitreihe; sie werden separat angezeigt.',
                           'Der Quelle-Snapshot kann ein ZIP-Import sein; API-Abrufstatus allein beweist keine Zuordnung einzelner Beiträge.',
                           'Bildhinweis ist keine verlässliche Formatklassifikation.',
                           'Stilmerkmale sind beschreibend; ein Reichweiteneffekt ist daraus nicht kausal ableitbar.']}
