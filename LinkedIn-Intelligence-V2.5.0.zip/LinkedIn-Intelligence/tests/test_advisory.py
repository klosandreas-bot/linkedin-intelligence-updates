import json, tempfile, unittest, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import advisory, analytics, storage

class AdvisoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        storage.DB_PATH=Path(self.tmp.name)/'db.sqlite'
        self.cx=storage.db()
    def tearDown(self):
        self.cx.close();self.tmp.cleanup()
    def populate(self,domain,rows,source='api'):
        sid=storage.new_snapshot(self.cx,source,source)
        storage.put_data(self.cx,sid,domain,rows)
        self.cx.commit()
        return sid
    def test_no_data_is_not_false_failure(self):
        a=analytics.overview(self.cx)
        self.assertEqual(a['analysis']['endorsements']['received'],0)
        self.assertTrue(any('importieren' in r['title'].lower() for r in a['analysis']['recommendations']))
        self.assertEqual(a['scores']['point_count'],0)
    def test_in_out_duplicates_and_raw_retained(self):
        older={'Endorsement Date':'2026/01/06 09:16:34 UTC','Endorsement Status':'ACCEPTED',
               'Endorser Public Url':'www.linkedin.com/in/old','Skill Name':'Beratung'}
        new=[{'Endorsement Date':f'2026/10/13 12:34:{x:02} UTC',
              'Endorsement Status':'ACCEPTED','Endorser Public Url':'www.linkedin.com/in/colleague',
              'Skill Name':f'Skill {x}'} for x in range(11)]
        outgoing=[{'Endorsement Date':f'2026/10/13 12:28:{x:02} UTC',
                   'Endorsee Public Url':'www.linkedin.com/in/colleague','Skill Name':f'Other {x}'} for x in range(36)]
        orig=[older,older,*new,*outgoing]
        sid=self.populate('ENDORSEMENTS',orig)
        a=analytics.overview(self.cx)
        e=a['analysis']['endorsements']
        self.assertEqual((e['received'],e['given'],e['exact_duplicates'],e['raw_records']), (12,36,1,49))
        self.assertEqual(len(storage.latest_domain(self.cx,'ENDORSEMENTS')),49)
        self.assertEqual(a['analysis']['quality']['ENDORSEMENTS']['unique_rows'],48)
    def test_network_duplicate_invitations_and_unchanged_raw(self):
        inv={'Direction':'OUTGOING','Sent At':'2026-10-13','Invitee':'Test'}
        self.populate('INVITATIONS',[inv,inv,{'Direction':'INCOMING','Sent At':'2026-10-12'}])
        a=analytics.overview(self.cx)
        self.assertEqual(a['network']['invitations_rows'],3)
        self.assertEqual(a['network']['invitation_unique_records'],2)
        self.assertEqual((a['network']['outgoing'],a['network']['incoming']),(1,1))
    def test_share_safe_no_private_text_and_only_aggregate(self):
        self.populate('ENDORSEMENTS',[{'Endorser Public Url':'www.linkedin.com/in/secret-user',
                                       'Endorser First Name':'SecretName','Skill Name':'Consulting',
                                       'Endorsement Date':'2026/10/13 12:34:20 UTC'}])
        self.populate('INBOX',[{'Body':'VeryPrivateText'}])
        self.populate('CONNECTIONS',[{'URL':'http://linkedin.com/in/personX','First Name':'PrivateContact'}])
        d=analytics.overview(self.cx,share_safe=True)
        serialized=json.dumps(d)
        for term in ['SecretName','secret-user','PrivateContact','VeryPrivateText']:
            self.assertNotIn(term,serialized)
        self.assertIn('analysis',d)
        self.assertEqual(d['analysis']['endorsements']['received'],1)
    def _score(self, sid, topic, dimension, date, value):
        self.cx.execute('INSERT INTO scores (snapshot_id,score_type,topic,category,measured_at,value) VALUES (?,?,?,?,?,?)',
                        (sid,'Knowledge',topic,dimension,date,value))

    def test_credibility_plan_is_topic_specific_and_preserves_gaps(self):
        sid=storage.new_snapshot(self.cx,'zip','Scores')
        for t,dim,val in [('Regulatory A','Role and scope',4),
                          ('Regulatory A','Validation and influence',1),
                          ('Regulatory A','Content and output',3),
                          ('Regulatory B','Validation and influence',3)]:
            self._score(sid,t,dim,'2026-10-08',val)
        self._score(sid,'Regulatory A','Validation and influence','2026-09-20',2)
        self.cx.commit()
        plan=analytics.overview(self.cx)['analysis']['credibility_plan']
        self.assertEqual(plan['topic_count'],2)
        a=next(x for x in plan['topics'] if x['topic']=='Regulatory A')
        b=next(x for x in plan['topics'] if x['topic']=='Regulatory B')
        self.assertEqual(a['score_coverage'],3)
        self.assertEqual(b['score_coverage'],1)
        one=next(x for x in a['dimensions'] if x['name']=='Validation and influence')
        self.assertTrue(one['relative_lowest'])
        self.assertEqual(one['delta'],-1)
        missing=next(x for x in a['dimensions'] if x['name']=='Education and credentials')
        self.assertIsNone(missing['value'])
        self.assertFalse(missing['relative_lowest'])
        self.assertFalse(next(x for x in b['dimensions'] if x['name']=='Validation and influence')['relative_lowest'])

    def test_endorsements_after_last_measurement_are_observations_not_guarantees(self):
        sid=storage.new_snapshot(self.cx,'zip','Scores')
        self._score(sid,'Skills Alpha','Role and scope','2026-10-08',3)
        self.cx.commit()
        old={'Endorsement Date':'2026/10/01 12:00:00 UTC','Endorser Public Url':'example.org/one','Skill Name':'Alpha'}
        new={'Endorsement Date':'2026/10/13 12:00:00 UTC','Endorser Public Url':'example.org/two','Skill Name':'Alpha'}
        self.populate('ENDORSEMENTS',[old,new,new])
        a=analytics.overview(self.cx)
        e=a['analysis']['credibility_plan']['topics'][0]
        self.assertEqual(e['new_endorsements_after_score'],1)
        self.assertIn('keine Reverse-Engineering-Formel',a['analysis']['credibility_plan']['method'])
        self.assertEqual(a['analysis']['endorsements']['exact_duplicates'],1)

    def test_credibility_snapshot_selection_and_share_safe_without_persons(self):
        sid1=storage.new_snapshot(self.cx,'zip','First')
        self._score(sid1,'Alpha','Role and scope','2026-09-01',2)
        self.cx.commit()
        sid2=storage.new_snapshot(self.cx,'zip','Second')
        self._score(sid2,'Alpha','Role and scope','2026-10-01',3)
        self.cx.commit()
        self.populate('ENDORSEMENTS',[{'Endorser First Name':'PrivatePerson','Skill Name':'Alpha',
                                       'Endorsement Date':'2026/10/14 12:00:00 UTC'}])
        first=analytics.overview(self.cx,sid1)['analysis']['credibility_plan']['topics'][0]
        self.assertEqual(first['last_measured'],'2026-09-01')
        self.assertEqual(first['new_endorsements_after_score'],0)
        latest=analytics.overview(self.cx,share_safe=True)
        self.assertNotIn('PrivatePerson',json.dumps(latest))
        self.assertNotIn('credibility_plan', latest['analysis'])
        self.assertEqual(analytics.overview(self.cx)['analysis']['credibility_plan']['topics'][0]['new_endorsements_after_score'],1)

    def test_provenance_between_api_and_zip(self):
        self.populate('SKILLS',[{'Name':'A'}],source='zip')
        self.populate('SKILLS',[{'Name':'A'},{'Name':'B'}],source='api')
        self.assertEqual(advisory.source_info(self.cx,'SKILLS')['source'],'api')
        self.assertEqual(analytics.overview(self.cx)['profile']['skill_count'],2)

if __name__=='__main__': unittest.main()
