# LinkedIn Intelligence V2.5 – lokale Analyse mit nachvollziehbaren Empfehlungen

Ein privates, lokales Python-Dashboard zur Auswertung der **eigenen** LinkedIn-Datenexporte und – sofern separat autorisiert – der offiziellen Member Data Portability API. LinkedIn ist nicht Herausgeber dieses Werkzeugs.

## Ohne OAuth sofort nutzbar

1. **Python 3.11 oder neuer** auf Windows installieren (Option „Add Python to PATH“).
2. Dieses Paket in einen eigenen Ordner entpacken.
3. `Start-Dashboard.bat` doppelklicken. Die Oberfläche öffnet sich lokal unter `http://127.0.0.1:8765`.
4. Unter **Datenquellen & Abruf** den eigenen LinkedIn-Datenexport als ZIP importieren.
5. Unter **Auswertung & Empfehlungen** die Datenqualität, erhaltene/vergebene Kenntnisbestätigungen, Themen und Score-Änderungen prüfen.

Der vollständige LinkedIn-Datenexport ist für historische Credibility-/Notability-Scores erforderlich, sofern er die Datei `Inferred Credibility Scores.csv` enthält. Basic-Exporte haben meist weniger Datendomänen. Es sind keinerlei Daten eines anderen Nutzers enthalten.

## Was die Analyse kann

- **Erhaltene vs. vergebene Kenntnisbestätigungen** trennen, wortgleiche Dubletten bei der Auswertung ignorieren und zugrunde liegende Fachgebiete lokal anzeigen.
- **Datenqualität** anhand exakter Datensatz-Duplikate und ungefähr eindeutiger Kontaktkennungen beurteilen. Rohdaten bleiben unangetastet; unterschiedliche JSON-Einträge sind nicht automatisch unterschiedliche Personen.
- **Score-Verläufe** nur innerhalb identischer Themen und Dimensionen vergleichen und die jüngsten tatsächlichen Änderungen anzeigen.
- **Themenhäufigkeiten** anhand eines ausdrücklich begrenzten Stichwortkatalogs und eigener profilierter Kenntnisse auswerten. Diese einfache Erkennung ist keine KI-Semantik und beurteilt keine inhaltliche Qualität.
- **Regelbasierte Empfehlungen** mit Datengrundlage statt erfundener Reichweiten-/Algorithmusprognosen anbieten. Fehlende Daten sind keine Nullleistung.
- **Credibility-Maßnahmenplan V2.5:** Alle fünf dokumentierten Bewertungsdimensionen je Fachgebiet darstellen, relativ niedrige Werte nur innerhalb desselben Fachgebiets hervorheben und passende Profil-/Fachmaßnahmen vorschlagen. Als zusätzliche Beobachtung werden erhaltene Bestätigungen nach dem letzten Score-Datum erfasst; deren Einfluss auf die Scores ist nicht belegt.
- **Vorher-Nachher-Protokoll:** Schritte zur zeitlichen Beobachtung echter Score-Daten; keine automatische Erfolgsschätzung.

## Datenschutz und Verteilung

**Die lokale Installation gehört jeder Person selbst.** Datenbank, Originalexporte, Screenshots, Token und Reports sollten nur auf dem eigenen Rechner bleiben. Das Tool archiviert auch private Nachrichten und Sicherheitseinträge, falls sie in einem eigenen ZIP enthalten sind. Diese Rohdaten werden nicht als öffentliche Webseite bereitgestellt, wohl aber lokal gespeichert. Nur wer bewusst die API-Synchronisation startet, kontaktiert LinkedIn.

- Die Datenbank entsteht in `data/linkedin.db`.
- Original-ZIPs liegen in `data/archives/`.
- `.env` enthält gegebenenfalls den persönlichen OAuth-Token und darf niemals verteilt werden.
- Der manuell erzeugte kuratierte Bericht unter `reports/current.json` enthält Kennzahlen und Themen, aber keine private Nachrichten-/Kontakttexte. Trotzdem vor Weitergabe prüfen.
- Das **saubere Kollegenpaket** enthält keines dieser persönlichen Artefakte.

**Wichtig:** Für einen API-Direktabruf braucht jeder Kollege einen eigenen LinkedIn-Zugang zur Member Data Portability API und ein passendes, selbst autorisiertes OAuth-Token. Einfach die Anwendung zu teilen gewährt noch keinen API-Zugang. Ein LinkedIn-Token darf niemals an Kollegen weitergegeben werden. Für die reine ZIP-Auswertung ist **gar kein API-Zugang nötig**.

## Offizielle API optional aktivieren

Die passende LinkedIn-Developer-App und Berechtigung `r_dma_portability_self_serve` müssen vorhanden sein. Die Einstellung `.env.example` nach `.env` kopieren und dort lokal `LINKEDIN_ACCESS_TOKEN=...` eintragen. Dann den API-Schnelltest oder den vollständigen Abruf starten. Nach einer erstmaligen Freigabe können Domains noch für Stunden ohne Daten sein. Einige API-Domains werden von LinkedIn mit `HTTP 400 ... not supported` abgelehnt. Die echte Score-Historie wird durch den Bereich `INFERENCE_TAKEOUT` nicht garantiert.

Die 65 abgefragten Bereiche einschließlich Nachrichten, Sicherheits- und Anzeigeninformationen werden nur auf ausdrücklichen Abruf lokal archiviert. Python-Bibliotheken Dritter werden nicht benötigt.

Offizielle Dokumentation: https://learn.microsoft.com/en-us/linkedin/dma/member-data-portability/shared/member-snapshot-api

## Entwicklung / Prüfung

```powershell
python -m unittest discover -s tests -v
python cli.py serve
python cli.py report
```

Die Anwendung läuft nur auf Loopback (`127.0.0.1`) und nicht als öffentlich erreichbarer Webservice. Die angezeigten LinkedIn-Schätzungen sind **keine nachgewiesenen Faktoren des Feed-Rankings**. Entscheidungen über professionelle Profile und Inhalte bleiben beim Nutzer.

## Automatische, signierte Updates ab V2.4

`Start-Dashboard.bat` prüft bei jedem Start das öffentliche Update-Repository
[linkedin-intelligence-updates](https://github.com/klosandreas-bot/linkedin-intelligence-updates).
Die Verbindung dient ausschließlich dem Abruf öffentlicher Programmdateien. **Es werden keine
LinkedIn-Daten, Token oder Berichte an GitHub hochgeladen.** GitHub kann den üblichen
Downloadzugriff samt IP-Adresse protokollieren.

Der Updater prüft das signierte Versionsmanifest mit einem fest eingebauten öffentlichen
RSA-Schlüssel, vergleicht SHA-256 und akzeptiert ausschließlich fest definierte Programmdateien.
Persönliche Dateien (`data/`, `reports/`, `.env`) sind ausdrücklich ausgeschlossen.
Bei Offline-Betrieb, unverändertem Versionsstand oder fehlgeschlagener Signaturprüfung
startet die lokale Version. Ein unterbrochenes Update wird beim nächsten Start zurückgesetzt.

Automatische Updateprüfung deaktivieren: Vor dem Start die Umgebungsvariable
`LINKEDIN_AUTO_UPDATE=0` setzen. Manuell prüfen: `python updater.py --update`.

**Erstinstallation:** Zum Umstieg von V2.3 auf V2.4 einmalig das V2.4-Bootstrap-Paket installieren.
Das V2.5-Kollegenpaket enthält keine LinkedIn-Daten und keine persönlichen Zugangsdaten.
Neue API-Berechtigungen werden durch Softwareupdates nicht eingerichtet. Jeder Nutzer nutzt
seine eigene private LinkedIn-API-Autorisierung beziehungsweise den ZIP-Import.
