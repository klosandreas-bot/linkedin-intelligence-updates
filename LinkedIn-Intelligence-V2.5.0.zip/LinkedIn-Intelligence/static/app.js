'use strict';
const $=s=>document.querySelector(s);
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>n===null||n===undefined?'–':Number(n).toLocaleString('de-DE',{maximumFractionDigits:2});
const short=s=>String(s||'').slice(0,400);
let dataset=null,tab='overview',chosenTopic=null,chosenAdviceTopic=null,loading=false;
const pages={overview:['Analyse-Cockpit','Datenbasierter Überblick über Dein Profil und dessen Entwicklung'],scores:['Credibility & Notability','Jede Dimension und jeder Messzeitpunkt – ohne vermischte Themenwerte'],profile:['Profil & Änderungen','Strukturierte Profildaten und ihr tatsächlicher Exportstand'],content:['Content & Netzwerk','Themenhäufigkeiten, Beiträge, direkte Kontakte und Einladungen'],advice:['Auswertung & Empfehlungen','Credibility-Maßnahmen, individuelle Fachgebiete und überprüfbare Veränderungen'],sources:['Datenquellen & Abruf','Offizielle LinkedIn-API, ZIP-Importe und Berichtsexport']};
function message(text,error=false){const e=$('#alert');e.textContent=text;e.hidden=false;e.className='alert'+(error?' error':'');setTimeout(()=>e.hidden=true,9000)}
async function request(url,opt={}){const r=await fetch(url,opt);const data=await r.json();if(!r.ok)throw Error(data.error||`HTTP ${r.status}`);return data}
async function reload(){if(loading)return;loading=true;$('#refresh').disabled=true;try{dataset=await request('/api/data'+($('#snapshot').value?'?snapshot='+encodeURIComponent($('#snapshot').value):''));render();syncSelect()}catch(e){message(e.message,true)}finally{loading=false;$('#refresh').disabled=false}}
function syncSelect(){const sel=$('#snapshot'),old=sel.value;sel.replaceChildren(new Option('Neuester verfügbarer Stand',''));
 for(const s of dataset.snapshots){const label=`#${s.id} · ${s.reference_date||s.imported_at.slice(0,10)} · ${s.source}`;sel.add(new Option(label,String(s.id)))}
 if([...sel.options].some(x=>x.value===old))sel.value=old;
}
function stat(label,num,foot=''){return `<div class="stat"><div class="kicker">${escapeHtml(label)}</div><div class="num">${escapeHtml(fmt(num))}</div><div class="foot">${escapeHtml(foot)}</div></div>`}
function panel(title,body,note=''){return `<section class="card"><div class="card-head"><h2>${escapeHtml(title)}</h2>${note?`<small>${escapeHtml(note)}</small>`:''}</div>${body}</section>`}
function bar(name,num,max){const value=Number(num)||0;return `<div class="barrow"><span title="${escapeHtml(name)}">${escapeHtml(name)}</span><div class="barline"><div class="barfill" style="width:${max>0?Math.max(0,Math.min(100,value/max*100)):0}%"></div></div><strong>${escapeHtml(fmt(value))}</strong></div>`}
function empty(s){return `<div class="empty">${escapeHtml(s)}</div>`}
function overview(){const s=dataset.scores,n=dataset.network,p=dataset.profile,c=dataset.content,ads=dataset.ads;
 const scores=s.topics.length,top=s.top_knowledge.slice(0,7),tmax=top.length?top[0].score:4;
 return `<div class="notice"><strong>Methodischer Hinweis</strong> Die internen Scoring-Werte sind modellbasierte LinkedIn-Einschätzungen. Sie belegen keine direkte Wirkung auf die Feed-Reichweite. Nicht vorhandene Messpunkte gelten als fehlend, niemals als Null.</div>
 <div class="stats">${stat('Fachliche Score-Themen',scores,`${fmt(s.point_count)} historische Messpunkte`)}${stat('Notability',s.notability.score===null?'–':s.notability.score,'Skala 0 bis 5 · '+(s.notability.date||'nicht verfügbar'))}${stat('Kontakte – Exportzeilen',n.connections_rows,`${n.unique_identifiers} identifizierbare Datensätze`)}${stat('Werbe-Skill-Kategorien',ads.skill_count,'Separate Werbe-Klassifikation')}</div>
 <div class="grid2">${panel('Fachliche Kompetenzen',scores?`<div class="score-list">${s.topics.map(t=>{const score=Object.values(t.dimensions).reduce((a,v)=>a+v.score,0);return `<button class="go-score" data-topic="${escapeHtml(t.name)}"><span class="right">${fmt(score)}/20</span>${escapeHtml(t.name)}</button>`}).join('')}</div>`:empty('Noch keine Credibility Scores importiert. Bitte Complete-Export mit der entsprechenden CSV-Datei hinzufügen.'),'Exakte Themenkategorien')}
 ${panel('Top-Themen im Wissensmodell',top.length?`<div class="bars">${top.map(t=>bar(t.topic,t.score,4)).join('')}</div>`:empty('Noch keine normalisierten Knowledge Scores vorhanden.'),'Skala 1–4')}</div>
 <div class="grid2">${panel('Datenbestand',`<div class="stats" style="margin:0;grid-template-columns:repeat(2,minmax(0,1fr))">${stat('Eigene Beiträge',c.posts)}${stat('Kommentare',c.comments)}${stat('Profilkenntnisse',p.skill_count)}${stat('Snapshots',dataset.snapshots.length)}</div>`,'Aktuell verfügbar')}
 ${panel('Datenherkunft',dataset.snapshots.length?dataset.snapshots.slice(0,6).map(x=>`<div class="source"><div><b>${escapeHtml(x.label)}</b><br><span>${escapeHtml(x.source)} · ${escapeHtml(x.reference_date||'ohne Stichtag')}</span></div><small>#${x.id}</small></div>`).join(''):empty('Noch keine Daten vorhanden.'),'Letzte Snapshots')}</div>
 ${panel('Ihre nächsten Schritte', ((dataset.analysis?.recommendations||[]).slice(0,3).map(x=>`<div class="advice-mini"><b>${escapeHtml(x.title)}</b><p class="muted tiny">${escapeHtml(x.evidence)}</p></div>`).join('')||empty('Noch keine Handlungshinweise verfügbar.'))+`<button class="btn outline" id="open-advice">Alle Empfehlungen ansehen →</button>`,'Regelbasiert und überprüfbar')}`;
}
function lineChart(history){if(!history.length)return empty('Für diese Dimension liegen noch keine Messwerte vor.');
 const w=690,h=164,l=40,r=18,t=12,b=28,range=w-l-r;
 const unique=history.filter((r,i,a)=>a.findIndex(x=>x.measured_at===r.measured_at)===i).sort((a,b)=>a.measured_at.localeCompare(b.measured_at));
 const min=Math.min(...unique.map(r=>Number(r.value))),max=Math.max(...unique.map(r=>Number(r.value)));
 const ymax=Math.max(4,Math.ceil(max));const ymin=0;
 const points=unique.map((x,i)=>[l+(unique.length===1?.5:i/(unique.length-1))*range,t+(ymax-Number(x.value))/(ymax-ymin)*(h-t-b)]);
 const line=points.map(x=>x.join(',')).join(' ');
 return `<svg class="linechart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" role="img" aria-label="Historischer Verlauf"><line x1="${l}" y1="${h-b}" x2="${w-r}" y2="${h-b}" stroke="#456175"/><line x1="${l}" y1="${t}" x2="${l}" y2="${h-b}" stroke="#456175"/><text x="7" y="${t+7}">${ymax}</text><text x="13" y="${h-b}">0</text><polyline points="${line}" fill="none" stroke="#63e0bf" stroke-width="3" vector-effect="non-scaling-stroke"/>${points.map((p,i)=>`<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="#62d9d9"><title>${escapeHtml(unique[i].measured_at)} · ${fmt(unique[i].value)}</title></circle>`).join('')}<text x="${l}" y="${h-5}">${escapeHtml(unique[0].measured_at)}</text><text text-anchor="end" x="${w-r}" y="${h-5}">${escapeHtml(unique.at(-1).measured_at)}</text></svg>`;
}
function scores(){const s=dataset.scores;if(!s.topics.length)return panel('Score-Historie fehlt',empty('Importiere den vollständigen LinkedIn-Export, der „Inferred Credibility Scores.csv“ enthält. Der API-Datenbereich INFERENCE_TAKEOUT garantiert diese Werte nicht.'));
 if(!chosenTopic||!s.topics.some(t=>t.name===chosenTopic))chosenTopic=s.topics[0].name;
 const topic=s.topics.find(t=>t.name===chosenTopic),dimensions=s.dimensions;
 const dhtml=dimensions.map(x=>{const point=topic.dimensions[x];return `<div class="dim"><strong>${point?fmt(point.score):'–'}</strong><small>${escapeHtml(x)}</small><small>${point?escapeHtml(point.date):'keine Messung'}</small></div>`}).join('');
 const history=s.history.filter(x=>x.topic===chosenTopic);
 const hgroups=dimensions.map(cat=>{const h=history.filter(x=>x.category===cat);return `<h3>${escapeHtml(cat)}</h3>${lineChart(h)}`}).join('');
 const no=s.notability;
 return `<div class="stats">${stat('Fachgebiete',s.topics.length)}${stat('Historische Datenpunkte',s.point_count)}${stat('Notability',no.score,'Letzte Bewertung '+(no.date||'–'))}${stat('Notability Tier',no.tier,'Gesonderte Skala von 1 bis 4')}</div>
 <div class="grid2">${panel('Fachgebiet auswählen',`<div class="score-list">${s.topics.map(x=>`<button class="choose-topic ${chosenTopic===x.name?'selected':''}" data-topic="${escapeHtml(x.name)}">${escapeHtml(x.name)} <span class="right">${fmt(Object.keys(x.dimensions).length)}/5</span></button>`).join('')}</div>`,'Unterschiedliche Fachgebiete niemals vermischen')}
 ${panel('Zuletzt gemessen',`<h3>${escapeHtml(chosenTopic)}</h3><div class="dimgrid">${dhtml}</div><p class="muted tiny">Jede Dimension zeigt ihren eigenen letzten gemessenen Wert. Identische Daten an mehreren Tagen sind möglich.</p>`,'Skala 1–4')}
 </div>${panel('Historische Entwicklung des gewählten Fachgebiets',hgroups,`${history.length} Punkte`)}
 ${panel('Notability – eigenständiges Modell',`<p>Letzter aggregierter Wert <strong>${fmt(no.score)}</strong> / 5 am ${escapeHtml(no.date||'–')}. Tier <strong>${fmt(no.tier)}</strong> / 4.</p>${lineChart(s.history.filter(x=>x.category==='Aggregated notability score'))}<p class="muted tiny">Fehlende Notability-Unterdimensionen werden nicht als schlechte Bewertung interpretiert.</p>`,'Nicht mit Knowledge addieren')}`;
}
function profile(){const p=dataset.profile,prof=p.profile;
 const rows=Object.entries(prof).filter(([k,v])=>typeof v==='string'&&v).filter(([k])=>!/(Birth|Zip|Address|Name)/i.test(k));
 return `<div class="stats">${stat('Berufliche Stationen',p.position_count)}${stat('Explizite Kenntnisse',p.skill_count)}${stat('Ausbildungseinträge',p.education.length)}${stat('Snapshots',dataset.snapshots.length)}</div>
 <div class="grid2">${panel('Exportiertes Profil',rows.map(([k,v])=>`<div class="profile-block"><div class="tiny">${escapeHtml(k)}</div><div class="text-preview">${escapeHtml(v)}</div></div>`).join('')||empty('Keine Profilinformationen.'),'Strukturierte Angaben')}
 ${panel('Erfahrung & Qualifikationen',`<h3>Positionen</h3>${p.positions.map(x=>`<div class="profile-block"><strong>${escapeHtml(x.Title||x.title||'')}</strong><div class="tiny">${escapeHtml(x['Company Name']||'')}</div><div class="text-preview">${escapeHtml(short(x.Description||''))}</div></div>`).join('')||empty('Keine Positionen')}<h3>Explizite Skills</h3><div>${p.skills.map(x=>`<span class="tag">${escapeHtml(x)}</span>`).join('')||empty('Keine Skills')}</div>`,'LinkedIn Profilfelder')}</div>
 ${panel('Stichtage und Änderungen',`<p class="muted">Wähle oben zwei verschiedene Snapshots nacheinander, um die Versionen zu betrachten. Im Cockpit zeigt jeder Snapshot exakt den Stand, der in dem jeweiligen Export oder API-Abruf verfügbar war.</p><div class="notice">Der Import neuer ZIP-Dateien ersetzt alte Snapshots nicht. LinkedIn kann Scores zu einem späteren Messdatum nachliefern, das nicht dem ZIP-Erstellungsdatum entspricht.</div>`,'Keine Datenüberschreibung')}`;
}
function content(){const c=dataset.content,n=dataset.network,ads=dataset.ads;
 const top=Object.entries(c.topics).sort((a,b)=>b[1]-a[1]); const maximum=top.length?top[0][1]:1;
 const items=c.recent_posts.slice(0,20).map(p=>`<div class="source"><div><div class="tiny">${escapeHtml(p.date)}</div><div>${escapeHtml(short(p.preview))}</div><div>${p.topics.map(x=>`<span class="tag">${escapeHtml(x)}</span>`).join('')}</div></div>${p.url.startsWith('https://www.linkedin.com/')?`<a href="${escapeHtml(p.url)}" target="_blank" rel="noopener noreferrer">Beitrag ↗</a>`:''}</div>`).join('');
 return `<div class="stats">${stat('Beiträge im neuesten Vollbestand',c.posts)}${stat('Eigene Kommentare',c.comments)}${stat('Kontaktkennungen (näherungsweise)',n.unique_identifiers,`${fmt(n.connections_rows)} Rohzeilen`)}${stat('Einladungen – ausgehend',n.outgoing,'Eingehend '+n.incoming)}</div>
 <div class="grid2">${panel('Themenhäufigkeit',top.length?`<div class="bars">${top.map(([k,v])=>bar(k,v,maximum)).join('')}</div>`:empty('Im ausgewählten Snapshot sind keine Beitragstexte vorhanden.'),'Mehrfachzuordnung möglich')}
 ${panel('Werbe-Klassifikation',`<div class="metric">${fmt(ads.skill_count)}</div><p class="tiny">Member Skills – getrennt von öffentlich eingetragenen Skills.</p><div class="text-preview">${ads.skills.map(x=>`<span class="tag">${escapeHtml(x)}</span>`).join('')}</div><div class="profile-block"><span class="muted">Experience Targeting:</span> ${escapeHtml(ads.experience||'–')}</div>`,'Kein Credibility Score')}</div>
 ${panel('Beitragsarchiv',items||empty('Kein Shares-Export importiert. Basic-Exporte enthalten diese Datei oft nicht.'),'Aus vorhandener Quelle')}`;
}
function credibilityExplorer(){
 const plan=dataset.analysis?.credibility_plan||{},topics=plan.topics||[];
 if(!topics.length)return panel('Credibility gezielt verbessern',`<p>Für fachgebietsbezogene Handlungsempfehlungen fehlen die historischen Dimensionen aus <strong>Inferred Credibility Scores.csv</strong>.</p>${empty('Importiere einen vollständigen LinkedIn-Datenexport mit dieser CSV-Datei. Der normale API-Abruf liefert die historischen Scores nicht zwingend.')}`,'Keine Werte erfunden');
 if(!chosenAdviceTopic||!topics.some(t=>t.topic===chosenAdviceTopic))chosenAdviceTopic=topics[0].topic;
 const cur=topics.find(t=>t.topic===chosenAdviceTopic);
 const select=`<label for="cred-topic" class="tiny">Fachgebiet auswählen</label><select id="cred-topic" class="cred-select">${topics.map(t=>`<option value="${escapeHtml(t.topic)}" ${t.topic===chosenAdviceTopic?'selected':''}>${escapeHtml(t.topic)}</option>`).join('')}</select>`;
 const base=`<div class="cred-intro"><div><div class="tiny">Letzte Messung</div><strong>${escapeHtml(cur.last_measured||'unbekannt')}</strong></div><div><div class="tiny">Dimensionen mit Wert</div><strong>${fmt(cur.score_coverage)} / 5</strong></div><div><div class="tiny">Neue Bestätigungen insgesamt seit Messdatum</div><strong>${fmt(cur.new_endorsements_after_score)}</strong></div></div>`;
 const dims=cur.dimensions.map(d=>{
   const diff=d.delta===null?'kein Vergleich':`${d.delta>0?'+':''}${fmt(d.delta)} zum ${escapeHtml(d.previous_date)}`;
   const marker=d.relative_lowest?'<span class="cred-relative">Relativ niedriger</span>':'';
   return `<details class="cred-dim" ${d.relative_lowest?'open':''}><summary><span class="cred-dim-label">${escapeHtml(d.name)} ${marker}</span><span class="cred-value">${d.value===null?'–':fmt(d.value)} <small>${d.value===null?'fehlend':'/ 4'}</small></span></summary><div class="cred-dim-body"><p class="muted tiny">${d.date?'Messwert vom '+escapeHtml(d.date):'Kein Messwert – nicht als niedrig interpretieren.'} · ${diff}</p><h3>${escapeHtml(d.heading)}</h3><p>${escapeHtml(d.action)}</p><p class="muted tiny"><strong>Prüfschritt</strong> ${escapeHtml(d.check)}</p><p class="muted tiny">Diese Handlungsempfehlung ist eine plausible Verbesserung der beruflichen Außendarstellung. Eine Erhöhung der internen LinkedIn-Scores ist nicht belegt.</p></div></details>`;
 }).join('');
 const observation=cur.new_endorsements_after_score?`<div class="cred-observation"><strong>Beobachtungsfenster eröffnet</strong><p>Seit dem letzten Messdatum dieses Fachgebiets liegen insgesamt ${fmt(cur.new_endorsements_after_score)} neue, eindeutig eingegangene Kenntnisbestätigungen vor. Sie können sich auch auf andere Themen beziehen. Nach dem nächsten vollständigen Export können Sie die Werte <strong>dieses Fachgebiets</strong> vergleichen. Ein zeitlicher Zusammenhang beweist keine Ursache.</p></div>`:'';
 const checklist=(plan.measurement_protocol||[]).map((x,i)=>`<div class="cred-step"><b>${i+1}</b><span>${escapeHtml(x)}</span></div>`).join('');
 return `${panel('Credibility – fachgebietsbezogener Maßnahmenplan',`<div class="cred-controls">${select}<p class="muted tiny">Die Hervorhebung bezeichnet nur die relativ niedrigsten Werte <em>innerhalb desselben Fachgebiets</em>. Sie ist weder ein LinkedIn-Optimierungsranking noch eine Erfolgsgarantie.</p></div>${base}<p class="muted tiny">${escapeHtml(cur.note)} ${cur.mixed_measurement_dates?'Achtung: Die Dimensionen wurden nicht alle am selben Tag gemessen. Die relative Einordnung ist daher nur eingeschränkt vergleichbar.':''}</p><div class="cred-dims">${dims}</div>${observation}`,'5 originale Bewertungsdimensionen')}${panel('Vorher-Nachher-Test ohne Scheinkausalität',`<div class="cred-steps">${checklist}</div><p class="muted tiny">Alle Messwerte stammen aus Ihrem lokalen Export. Profiländerungen werden weder automatisch vorgenommen noch an LinkedIn gesendet.</p>`,'Für die nächsten Exporte')}`;
}
function advice(){
 const a=dataset.analysis||{}, tips=a.recommendations||[],e=a.endorsements||{},quality=a.quality||{}, changes=a.score_changes||[];
 const tag=p=>p===1?'Datenqualität':p===2?'Profil & Bewertung':'Weiterentwicklung';
 const note=`<div class="notice"><strong>So entstehen diese Hinweise</strong><p>Die Auswertung verwendet feste, nachvollziehbare Regeln und nur vorhandene eigene Exportdaten. Es gibt keine künstliche KI-Bewertung, keinen errechneten LinkedIn-Rankingwert und keine automatischen Profiländerungen. Fehlende Daten werden nicht als schlechte Leistung gewertet.</p></div>`;
 const kpis=`<div class="stats">${stat('Bestätigungen erhalten',e.received??0,`${fmt(e.received_skill_count??0)} Kenntnisse`)}${stat('Bestätigungen vergeben',e.given??0,'Nicht mit erhaltenen vermischen')}${stat('Exakte Duplikate bei Bestätigungen',e.exact_duplicates??0,'Rohdaten unverändert')}${stat('Hinweise',tips.length,'Aus verfügbarem Datenstand')}</div>`;
 const cards=tips.map(t=>`<article class="advice-item"><div class="advice-meta"><span class="advice-label">${escapeHtml(tag(t.priority))}</span><span>${escapeHtml(t.group)}</span></div><h3>${escapeHtml(t.title)}</h3><p class="evidence">${escapeHtml(t.evidence)}</p><p class="action"><strong>Empfehlung</strong> ${escapeHtml(t.action)}</p><div class="basis">Datenbasis: ${escapeHtml(t.basis)}</div></article>`).join('')||empty('Aktuell sind keine Empfehlungen ableitbar. Importieren Sie einen ZIP-Export.');
 const qualityRows=Object.entries(quality).filter(([k,v])=>v.raw).map(([k,v])=>`<tr><td>${escapeHtml(k)}</td><td>${fmt(v.raw)}</td><td>${fmt(v.exact_duplicates)}</td><td>${fmt(v.unique_rows)}</td></tr>`).join('');
 const qm=qualityRows?`<table class="table"><thead><tr><th>Bereich</th><th>Rohzeilen</th><th>Duplikate exakt</th><th>Unterschiedliche Zeilen</th></tr></thead><tbody>${qualityRows}</tbody></table><p class="muted tiny">Unterschiedliche JSON-Zeilen sind nicht automatisch unterschiedliche Personen oder Ereignisse. Beispielsweise können Kontakte trotz anderer Exportfelder mehrfach vorkommen.</p>`:empty('Noch keine prüfbaren Datenbereiche.');
 const sr=changes.slice(0,12).map(r=>`<tr><td>${escapeHtml(r.topic||'Notability')}</td><td>${escapeHtml(r.dimension)}</td><td>${fmt(r.previous)} → ${fmt(r.current)}</td><td class="${r.delta>0?'delta-plus':'delta-minus'}">${r.delta>0?'+':''}${fmt(r.delta)}</td><td>${escapeHtml(r.current_date)}</td></tr>`).join('');
 return `${note}${kpis}${credibilityExplorer()}${panel('Konkrete nächste Schritte',`<div class="advice-grid">${cards}</div>`,'Individuell aus Ihren Datensätzen abgeleitet')}
 <div class="grid2 grid-equal">${panel('Datenqualität prüfen',qm,'Rohdaten bleiben unverändert')}
 ${panel('Kenntnisbestätigungen richtig zählen',`<p>Die API liefert erhaltene und vergebene Bestätigungen gemeinsam. Hier werden sie getrennt und wortgleiche Dubletten nicht mitgezählt.</p><div class="stats" style="grid-template-columns:repeat(2,minmax(0,1fr))">${stat('Eingehend',e.received??0)}${stat('Ausgehend',e.given??0)}</div><p class="muted tiny">Letzte erhaltene Bestätigung: ${escapeHtml(e.last_received_date||'kein Datum')}.</p><div>${Object.entries(e.received_by_skill||{}).map(([name,v])=>`<span class="tag">${escapeHtml(name)} · ${fmt(v)}</span>`).join('')}</div>`,'Nur lokal sichtbare Fachgebiete')}</div>
 ${panel('Messbare Score-Änderungen',sr?`<div class="scroll-table"><table class="table"><thead><tr><th>Thema</th><th>Dimension</th><th>Vorher → jetzt</th><th>Δ</th><th>Datum</th></tr></thead><tbody>${sr}</tbody></table></div>`:empty('Noch keine unterschiedlichen Messwerte in aufeinanderfolgenden Messungen derselben Dimension. Gleiche Werte und fehlende Messungen sind keine Verschlechterung.'),'Nur exakte Themen-/Dimensionsvergleiche')}`;
}
function sources(){const st=dataset.latest_api_sync;
 const statusInfo=st?`<div class="notice" style="margin-bottom:16px"><b>Letzter API-Lauf:</b> ${escapeHtml(st.executed_at)} · ${fmt(st.domains_with_data)} von ${fmt(st.requested_domains)} Bereichen mit Daten.<details><summary>Alle Datenbereiche und Abrufstatus</summary><div class="text-preview">${Object.entries(st.status_by_domain).map(([k,v])=>`<div>${escapeHtml(k)} – ${escapeHtml(v)}</div>`).join('')}</div></details></div>`:'<p class="tiny muted">API-Einzelstatus wird ab dem nächsten Lauf gespeichert.</p>';
 return `${statusInfo}<div class="grid2 grid-equal">${panel('ZIP-Datei lokal importieren',`<div class="upload"><div style="font-size:26px">⇪</div><strong>LinkedIn Basic oder Complete ZIP</strong><p class="muted tiny">Originaldatei auswählen. Keine Übertragung ins Internet; Auswertung ausschließlich auf diesem Rechner.</p><input type="file" id="filezip" accept=".zip,application/zip"/><button class="btn primary" id="import-btn">ZIP importieren</button></div><p class="tiny">Für historische Credibility-Scores ist die Datei „Inferred Credibility Scores.csv“ entscheidend. Alle Originaldateien einschließlich privater Bereiche bleiben ausschließlich lokal archiviert. GitHub erhält nur den kuratierten Bericht.</p>`,'Ohne Kontozugriff')}
 ${panel('Direktabruf über LinkedIn',`<p class="muted">Lädt alle 65 offiziell dokumentierten Snapshot-Datenbereiche einschließlich Inferences, Nachrichten, Anzeigen, Identitäts- und Sicherheitsdaten sowie die vollständigen neuen Changelog-Ereignisse lokal herunter. Version 202312. OAuth-Token in der lokalen .env hinterlegen.</p><div class="buttonline"><button class="btn primary" id="sync-btn">Alle LinkedIn-Daten abrufen</button> <button class="btn outline" id="probe-btn">API-Schnelltest</button></div><div id="sync-diagnostics" class="notice" style="margin-top:14px">Letzten API-Abruf prüfen …</div><div class="notice" style="margin-top:18px">Die API kann 404 zurückgeben, während LinkedIn den ersten Snapshot aufbereitet. Nicht jeder Datenbereich enthält schon sofort Ergebnisse. Die Score-Historie über INFERENCE_TAKEOUT ist noch unbestätigt.</div>`,'Benötigt eigenen OAuth-Token')}</div>
 <div class="grid2 grid-equal">${panel('Bericht für ChatGPT / GitHub',`<p class="muted">Der kuratierte JSON-Bericht enthält detaillierte Fach-Scores und Themenwerte, aber keine Kontaktlisten, privaten Nachrichten oder Tokens.</p><div class="buttonline"><a class="btn outline" href="/api/export" download="linkedin-kuratierter-bericht.json">Bericht herunterladen</a><button id="report-btn" class="btn primary">Bericht lokal speichern</button></div><p class="tiny">Für GitHub: privates Repository, Secret LINKEDIN_ACCESS_TOKEN, GitHub Action aus diesem Paket. ChatGPT kann dann reports/current.json einlesen.</p>`,'Datensparsam')}
 ${panel('Vollständiges lokales Rohdatenarchiv',`<p class="muted tiny">Hier siehst Du alle importierten Datenbereiche, auch private Kategorien. Für jeden Datenbereich lässt sich die vollständige letzte Version als JSON herunterladen. Ausschließlich auf Deinem eigenen Rechner.</p><div id="domain-list">Lade Dateninventar …</div>`,'Rohdaten verlassen den Rechner nicht')}</div>
 <div class="grid2 grid-equal">${panel('Snapshot-Archiv',dataset.snapshots.length?dataset.snapshots.map(s=>`<div class="source"><div><b>${escapeHtml(s.label)}</b><br><span>${escapeHtml(s.source)} · ${escapeHtml(s.imported_at)} · ${escapeHtml(s.reference_date)}</span></div><b>#${s.id}</b></div>`).join(''):empty('Noch keine Daten vorhanden.'),'Neue Daten überschreiben nichts')}</div></div>`;
}
function render(){if(!dataset)return;const [name,desc]=pages[tab];$('#page-title').textContent=name;$('#subtitle').textContent=desc;
 $('#view').innerHTML=({overview,scores,profile,content,advice,sources}[tab])();
 document.querySelectorAll('.choose-topic,.go-score').forEach(b=>b.addEventListener('click',()=>{chosenTopic=b.dataset.topic;tab='scores';setNav();render()}));
 $('#cred-topic')?.addEventListener('change',e=>{chosenAdviceTopic=e.target.value;render()});
 $('#open-advice')?.addEventListener('click',()=>{tab='advice';setNav();render()});
 $('#import-btn')?.addEventListener('click',importZip);
 $('#sync-btn')?.addEventListener('click',()=>doSync(false));
 $('#probe-btn')?.addEventListener('click',()=>doSync(true));

 if(tab==='sources'){renderDomainList();renderDiagnostics();}
 $('#report-btn')?.addEventListener('click',async()=>{try{const r=await request('/api/report',{method:'POST',headers:{'X-Local-App':'1','Content-Type':'application/json'},body:'{}'});message('Bericht lokal gespeichert: '+r.path)}catch(e){message(e.message,true)}});
}
async function renderDomainList(){
 const target=$('#domain-list');if(!target)return;
 try{
  const info=await request('/api/domains');
  if(!target.isConnected)return;
  target.innerHTML=info.domains.length?info.domains.map(d=>`<div class="source"><div><b>${escapeHtml(d.domain)}</b><br><span>Snapshot #${escapeHtml(d.snapshot_id)} · ${fmt(d.json_bytes)} JSON-Bytes</span></div><a class="btn outline" href="/api/raw?domain=${encodeURIComponent(d.domain)}" download="linkedin-${escapeHtml(d.domain.toLowerCase())}.json">JSON ↓</a></div>`).join(''):empty('Noch keine Daten importiert.');
 }catch(e){if(target.isConnected)target.textContent='Dateninventar derzeit nicht lesbar: '+e.message}
}
async function importZip(){const inp=$('#filezip'),file=inp.files[0];if(!file){message('Bitte ZIP-Datei auswählen.',true);return}if(file.size>250*1024*1024){message('Datei zu groß.',true);return}
 try{message('ZIP-Import gestartet …');const result=await request('/api/import',{method:'POST',headers:{'X-Local-App':'1','X-Import-Label':file.name},body:file});message(`Snapshot #${result.snapshot_id} importiert. ${Object.keys(result.domains).length} Bereiche, ${result.score_points} Score-Messpunkte.`);$('#snapshot').value='';await reload()}catch(e){message(e.message,true)}}
async function renderDiagnostics(){
 const target=$('#sync-diagnostics'); if(!target)return;
 try{
  const data=await request('/api/diagnostics'); if(!target.isConnected)return;
  const last=data.last_sync,source=data.inventory_by_source||{}, api=source.api||{},zip=source.zip||{};
  if(!last){target.innerHTML=`<strong>Noch kein protokollierter API-Abruf.</strong><p>Die vorhandenen Daten stammen aus ZIP-Dateien oder aus dem mitgelieferten Archiv. Starte einen API-Schnelltest.</p>`;return}
  const statuses=last.domains||{},summary=last.summary||{},auth=last.authorization||{};
  const state=auth.state==='active'?`Aktiv${auth.regulated_at_ms?' seit '+new Date(auth.regulated_at_ms).toLocaleString('de-DE'):''}`:
    `Nicht bestätigt (${auth.state||'unbekannt'}${auth.http_status?', HTTP '+auth.http_status:''})`;
  const priority=['PROFILE','SKILLS','POSITIONS','MEMBER_SHARE_INFO','ALL_COMMENTS','ALL_LIKES','INFERENCE_TAKEOUT','INBOX'];
  const ordered=[...new Set([...priority,...Object.keys(statuses)])].filter(x=>statuses[x]);
  let rows=ordered.map(key=>{const x=statuses[key],n=x.rows||0;const stat=x.state==='ready'?'DATEN GELADEN':x.state==='not_yet_available_or_empty'?'LEER / IN VERARBEITUNG':x.state==='http_error'?'HTTP-FEHLER':x.state==='empty_response'?'LEER':'FEHLER';
   return `<div class="source"><div><b>${escapeHtml(key)}</b><br><span>${escapeHtml(stat)} · ${fmt(n)} per API · ${fmt(zip[key]||0)} aus ZIP</span><br><small>${escapeHtml(short(x.message||''))}</small></div></div>`}).join('');
  target.innerHTML=`<b>Letzter API-Lauf: ${escapeHtml(last.executed_at)} UTC</b><p>Autorisierung: ${escapeHtml(state)}<br>Von ${fmt(last.requested)} abgefragten Bereichen: ${fmt(summary.ready||0)} mit Daten, ${fmt(summary.not_yet_available_or_empty||0)} leer/noch in Verarbeitung, ${fmt(summary.errors||0)} Fehler.</p><p><strong>Quelle beachten:</strong> ZIP-Bestände sind keine API-Erfolge. Der erste Snapshot kann bei LinkedIn zeitversetzt erscheinen.</p><details><summary>Einzelstatus aller abgefragten Bereiche anzeigen (${fmt(ordered.length)})</summary>${rows}</details>`;
 }catch(e){if(target.isConnected)target.textContent='API-Diagnose konnte nicht gelesen werden: '+e.message}
}
async function doSync(quick=false){
 const btn=quick?$('#probe-btn'):$('#sync-btn');if(btn)btn.disabled=true;
 try{
  message(quick?'API-Schnelltest der vier wichtigsten Bereiche gestartet …':'Vollständiger API-Abruf gestartet …');
  const payload={changelog:!quick};
  if(quick)payload.domains=['PROFILE','MEMBER_SHARE_INFO','ALL_COMMENTS','INFERENCE_TAKEOUT'];
  const x=await request('/api/sync',{method:'POST',headers:{'X-Local-App':'1','Content-Type':'application/json'},body:JSON.stringify(payload)});
  const values=Object.values(x.domains),ok=values.filter(y=>y.rows>0).length;
  const failures=values.filter(y=>y.state==='http_error'||y.state==='error').length;
  if(!ok)message(`API lieferte für keinen der ${values.length} angefragten Bereiche Daten. ${failures} Fehler. Details unter API-Diagnose.`,true);
  else message(`API hat für ${ok} von ${values.length} Bereichen Daten geliefert. ${failures} Fehler. Details unter API-Diagnose.`);
  await reload(); if(tab==='sources')await renderDiagnostics();
 }catch(e){message(e.message,true)}finally{if(btn)btn.disabled=false}
}
function setNav(){document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab))}
document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>{tab=b.dataset.tab;setNav();render()}));
$('#refresh').addEventListener('click',reload);$('#snapshot').addEventListener('change',reload);reload();
