"""Local, explainable analysis of a member's own portability export.

All recommendations are deterministic and evidence-based, never AI-generated.
Raw datasets are not changed and recommendations never use private message texts.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
import json
from storage import latest_domain, scores_history


def rows(value):
    if isinstance(value, list):
        return value
    return [value] if isinstance(value, dict) else []


def fingerprint(rec):
    """Exact record identity, not a guess about a person's identity."""
    return json.dumps(rec, sort_keys=True, ensure_ascii=False, default=str, separators=(',', ':'))


def distinct_rows(records):
    """Remove only byte-content-equivalent JSON records, retaining order.

    Never merge merely similar events or rows sharing a name, date or URL.
    """
    seen=set(); out=[]
    for record in records:
        key=fingerprint(record)
        if key in seen:continue
        seen.add(key);out.append(record)
    return out


def exact_duplicates(records):
    keys={fingerprint(x) for x in records}
    return len(records)-len(keys)


def norm_url(url):
    url=str(url or '').strip().lower().removeprefix('https://').removeprefix('http://')
    return url.rstrip('/')


def endorsements(cx, until=None):
    source=rows(latest_domain(cx,'ENDORSEMENTS',until))
    seen=set(); incoming=[]; outgoing=[]; unknown=[]
    for rec in source:
        if not isinstance(rec,dict):continue
        # Identical export rows can occur in different API pages or CSVs.
        identity=fingerprint(rec)
        if identity in seen:continue
        seen.add(identity)
        # Incoming records contain Endorser fields; outgoing contain Endorsee fields.
        if rec.get('Endorser Public Url') or rec.get('Endorser First Name'):
            incoming.append(rec)
        elif rec.get('Endorsee Public Url') or rec.get('Endorsee First Name'):
            outgoing.append(rec)
        else:
            unknown.append(rec)
    received_skills=Counter(str(r.get('Skill Name','')).strip() for r in incoming if r.get('Skill Name'))
    received_dates=sorted((str(r.get('Endorsement Date',''))[:10].replace('/','-') for r in incoming),reverse=True)
    return {'raw_records':len(source),'exact_duplicates':len(source)-len(seen),
            'received':len(incoming),'given':len(outgoing),'unclassified':len(unknown),
            'received_skill_count':len(received_skills),'last_received_date':received_dates[0] if received_dates else None,
            'received_by_skill':dict(received_skills.most_common(30))}


def _iso_age(date):
    try:
        return (datetime.now(timezone.utc).date()-datetime.strptime(date[:10],'%Y-%m-%d').date()).days
    except (TypeError,ValueError,AttributeError):
        return None


def source_info(cx,domain,until=None):
    sql='''SELECT s.source,s.imported_at,s.reference_date FROM datasets d
           JOIN snapshots s ON s.id=d.snapshot_id WHERE d.domain=?'''
    args=[domain]
    if until is not None:
        sql+=' AND s.id<=?';args.append(int(until))
    sql+=' ORDER BY s.id DESC LIMIT 1'
    r=cx.execute(sql,args).fetchone()
    return dict(r) if r else None


def score_changes(cx,until=None):
    """Compare only identical topics/dimensions; do not conflate different score types."""
    data=scores_history(cx,until)
    groups={}
    for r in data:
        if r['category'] not in ('Aggregated notability score','Discrete notability tier',
                                'Role and scope','Tenure and experience','Content and output',
                                'Education and credentials','Validation and influence'):
            continue
        key=(r['score_type'],r['topic'],r['category'])
        groups.setdefault(key,{})[r['measured_at']]=r['value']
    changes=[]
    for (typ,topic,cat),values in groups.items():
        if len(values)<2:continue
        dates=sorted(values)
        previous,current=dates[-2:]
        change=round(float(values[current])-float(values[previous]),3)
        if change:
            changes.append({'type':typ,'topic':topic,'dimension':cat,
                            'previous_date':previous,'previous':values[previous],
                            'current_date':current,'current':values[current],'delta':change})
    changes.sort(key=lambda x:(x['current_date'],abs(x['delta'])),reverse=True)
    return changes[:30]



# Decision aid for profile quality. The exported categories are not a published
# causal score formula, and incomplete exports cannot prove incomplete profiles.
DIMENSION_GUIDANCE = {
    'Role and scope': {'heading':'Verantwortung und Aufgaben',
        'safe':'Ein niedriger Wert allein rechtfertigt keine neue Berufsstation oder mehr Schlagwörter.'},
    'Tenure and experience': {'heading':'Berufserfahrung und Zeiträume',
        'safe':'Mehr Berufsjahre lassen sich nicht durch Profileinträge erzeugen.'},
    'Content and output': {'heading':'Eigene fachliche Inhalte',
        'safe':'Zusätzliche Beiträge ohne fachlichen Anlass sind nicht empfehlenswert.'},
    'Education and credentials': {'heading':'Qualifikationen und Nachweise',
        'safe':'Alte Seminare, einzelne Veranstaltungen oder irrelevante Zertifikate nicht massenhaft eintragen. Lehrtätigkeit ist nicht automatisch ein Bildungsabschluss.'},
    'Validation and influence': {'heading':'Fachliche Anerkennung',
        'safe':'Keine Gefälligkeitsbestätigungen einholen oder künstliche Interaktionen erzeugen.'},
}


def _nonempty(record, *keys):
    return isinstance(record,dict) and any(str(record.get(k) or '').strip() for k in keys)


def _dataset_presence(cx,domain,until=None):
    source=source_info(cx,domain,until)
    raw=distinct_rows(rows(latest_domain(cx,domain,until)))
    # Missing domain is unknown; an explicit, empty snapshot is a known absence
    # *in that export*, not necessarily in LinkedIn's live profile.
    return {'available':source is not None,'count':len(raw),'source':source['source'] if source else None,'rows':raw}


def profile_evidence(cx,profile,content,endors,until=None):
    """Aggregate only observable export fields, with a clear provenance boundary."""
    names=('PROFILE','POSITIONS','EDUCATION','CERTIFICATIONS','COURSES',
           'PUBLICATIONS','PROJECTS','RECOMMENDATIONS','MEMBER_SHARE_INFO',
           'SKILLS','ENDORSEMENTS')
    inventory={d:_dataset_presence(cx,d,until) for d in names}
    positions=inventory['POSITIONS']['rows']
    start_fields=('Started On','Start Date','Start Date (YYYY-MM-DD)','Start Date (MM/YYYY)','startDate')
    title_fields=('Title','Job Title','Position Title','title')
    missing_dates=sum(isinstance(r,dict) and any(k in r for k in start_fields)
                      and not _nonempty(r,*start_fields) for r in positions)
    missing_title=sum(isinstance(r,dict) and any(k in r for k in title_fields)
                      and not _nonempty(r,*title_fields) for r in positions)
    profile_rows=inventory['PROFILE']['rows']
    no_headline=bool(profile_rows and isinstance(profile_rows[0],dict)
                     and any(k in profile_rows[0] for k in ('Headline','headline'))
                     and not _nonempty(profile_rows[0],'Headline','headline'))
    no_summary=bool(profile_rows and not _nonempty(profile_rows[0],'Summary','summary'))
    # An empty optional description is not an error and never triggers "add content".
    descriptive_roles=sum(_nonempty(r,'Description','description') for r in positions)
    return {
        'domains':{d:{'available':v['available'],'count':v['count'],'source':v['source']} for d,v in inventory.items()},
        'positions_missing_title':missing_title,
        'positions_missing_start_date':missing_dates,
        'positions_with_description':descriptive_roles,
        'profile_without_headline':no_headline,
        'profile_without_summary':no_summary,
        'received_endorsements':endors['received'],
        'content_posts':content['posts'],
    }


def _dimension_decision(dim,evidence):
    """Decide independently of the LinkedIn score; missing source != missing skill."""
    domains=evidence['domains']
    def present(*names): return any(domains[n]['available'] for n in names)
    def recorded(*names):return sum(domains[n]['count'] for n in names)
    status='beobachten';priority='niedrig'
    if dim=='Role and scope':
        if evidence['positions_missing_title']:
            return {'status':'prüfen','priority':'mittel','heading':'Unvollständige Positionsbezeichnung prüfen',
                'action':f"Bei {evidence['positions_missing_title']} exportierten Berufsstation(en) fehlt die Positionsbezeichnung. Prüfen Sie die Anzeige im Live-Profil und ergänzen Sie gegebenenfalls nur die korrekte Bezeichnung.",
                'check':'Betrifft fehlende Positionsbezeichnungen im Export, keine Score-Prognose.',
                'basis':'POSITIONS – Titel leer'}
        if evidence['profile_without_headline']:
            return {'status':'prüfen','priority':'mittel','heading':'Profilüberschrift kontrollieren',
                'action':'Im Export fehlt die Profilüberschrift. Prüfen Sie zunächst, ob sie auf LinkedIn tatsächlich leer ist. Falls ja, formulieren Sie eine zutreffende und verständliche berufliche Positionierung.',
                'check':'Nur bei bestätigter Lücke im Live-Profil ändern.',
                'basis':'PROFILE – Headline leer'}
        if recorded('POSITIONS','PROFILE'):
            return {'status':'kein_handlungsbedarf','priority':'niedrig','heading':'Kein konkreter Änderungsbedarf erkennbar',
                'action':'Berufliche Stationen und Profilpositionierung sind im Export grundsätzlich vorhanden. Weitere Aufgaben oder Schlüsselwörter sollten Sie nicht allein wegen dieses Score-Werts ergänzen.',
                'check':'Nur bei einer tatsächlich veralteten oder unzutreffenden Darstellung handeln.',
                'basis':'PROFILE/POSITIONS – vorhandene Exportfelder'}
        basis='PROFILE/POSITIONS – keine Datenquelle'
    elif dim=='Tenure and experience':
        if evidence['positions_missing_start_date']:
            return {'status':'prüfen','priority':'mittel','heading':'Fehlende Zeitangabe prüfen',
                'action':f"Bei {evidence['positions_missing_start_date']} exportierten Berufsstation(en) fehlt ein erkennbarer Beginn. Prüfen Sie das Live-Profil und korrigieren Sie nur tatsächliche Datumsfehler.",
                'check':'Keine erfundenen Zeiträume oder rückwirkenden Tätigkeiten ergänzen.',
                'basis':'POSITIONS – Startdatum fehlt'}
        if present('POSITIONS') and recorded('POSITIONS'):
            return {'status':'kein_handlungsbedarf','priority':'niedrig','heading':'Erfahrung bereits dokumentiert',
                'action':'Die exportierten Berufsstationen enthalten erkennbare Zeitangaben. Zusätzliche alte Stationen nur aufnehmen, wenn sie für das berufliche Profil tatsächlich relevant und korrekt sind.',
                'check':'Ohne nachgewiesene Lücke keine Profiländerung.',
                'basis':'POSITIONS – Datumsfelder'}
        basis='POSITIONS – keine geeigneten Zeitdaten'
    elif dim=='Content and output':
        if present('MEMBER_SHARE_INFO') and recorded('MEMBER_SHARE_INFO'):
            return {'status':'kein_handlungsbedarf','priority':'niedrig','heading':'Beiträge bereits nachgewiesen',
                'action':'Es liegen eigene Beitragsdatensätze vor. Die Themenzuordnung zum gewählten Score-Fachgebiet ist damit noch nicht bewiesen. Veröffentlichen Sie weitere Inhalte nur, wenn sie fachlich sinnvoll sind.',
                'check':'Inhaltliche Relevanz und Wirkung vorhandener Beiträge vor einer zusätzlichen Veröffentlichungsserie prüfen.',
                'basis':'MEMBER_SHARE_INFO – eigene Beiträge, fachgebietsübergreifend'}
        basis='MEMBER_SHARE_INFO – keine belastbare Beitragsbeobachtung'
    elif dim=='Education and credentials':
        if present('EDUCATION','CERTIFICATIONS','COURSES'):
            cnt=recorded('EDUCATION','CERTIFICATIONS','COURSES')
            if cnt:
                return {'status':'kein_handlungsbedarf','priority':'niedrig','heading':'Vorhandene Nachweise genügen als Ausgangspunkt',
                    'action':f"Im Export sind {cnt} Einträge in den Bereichen Ausbildung, Zertifikate oder Kurse vorhanden. Ob sie zum gewählten Fachgebiet gehören, ist nicht automatisch feststellbar. Alte Seminare nicht einzeln nachtragen, nur um den Wert zu beeinflussen.",
                    'check':'Lediglich eine wichtige, wirklich erworbene und relevante Qualifikation bei Bedarf prüfen; kein Sammeln von Zertifikaten.',
                    'basis':'EDUCATION/CERTIFICATIONS/COURSES – vorhandene Einträge'}
            return {'status':'beobachten','priority':'niedrig','heading':'Keine Score-getriebene Ergänzung empfehlen',
                'action':'Der Export enthält hier keine Ausbildung oder Zertifizierung. Das beweist nicht, dass im Live-Profil relevante Qualifikationen fehlen. Prüfen Sie eine konkrete, wesentliche Qualifikation nur bei tatsächlichem Anlass.',
                'check':'Keine alten Einzelveranstaltungen oder nicht erworbenen Abschlüsse ergänzen.',
                'basis':'Ausbildungs-/Zertifikatsbereiche – im Export leer'}
        basis='EDUCATION/CERTIFICATIONS/COURSES – nicht im Export enthalten'
    else: # Validation and influence
        if evidence['received_endorsements']:
            return {'status':'beobachten','priority':'niedrig','heading':'Anerkennung ist bereits sichtbar',
                'action':f"Es liegen {evidence['received_endorsements']} unterschiedliche erhaltene Kenntnisbestätigungen vor. Der Export beweist nicht, dass diese zum ausgewählten Fachgebiet gehören oder den Score verändern. Beobachten statt weitere Bestätigungen zu organisieren.",
                'check':'Beim nächsten vollständigen Export denselben Score-Wert prüfen; keine Gefälligkeitsbestätigungen.',
                'basis':'ENDORSEMENTS – erhaltene, exakt deduplizierte Einträge'}
        if present('ENDORSEMENTS','RECOMMENDATIONS'):
            return {'status':'beobachten','priority':'niedrig','heading':'Keine künstliche Bestätigungsaktion',
                'action':'In den verfügbaren Exportdaten ist keine eingegangene Kenntnisbestätigung erkennbar. Dies ist keine Aufforderung, Kollegen um Gefälligkeitsbestätigungen zu bitten.',
                'check':'Reale Anerkennung im Live-Profil prüfen, wenn fachlich sinnvoll.',
                'basis':'ENDORSEMENTS/RECOMMENDATIONS – Exportlage'}
        basis='ENDORSEMENTS/RECOMMENDATIONS – nicht im Export enthalten'
    return {'status':'datenlage_unvollstaendig','priority':'niedrig','heading':'Keine belastbare Empfehlung möglich',
            'action':'Der relevante Datenbereich fehlt oder ist nicht aussagekräftig genug. Daraus darf keine Lücke im Live-Profil abgeleitet werden. Vorläufig nichts ergänzen.',
            'check':'Bei Bedarf vollständigen Export einlesen oder die vorhandenen Angaben manuell prüfen.',
            'basis':basis}


def _endorsement_observations(cx,until=None):
    raw=rows(latest_domain(cx,'ENDORSEMENTS',until))
    seen=set(); out=[]
    for rec in raw:
        if not isinstance(rec,dict) or not (rec.get('Endorser Public Url') or rec.get('Endorser First Name')):continue
        key=fingerprint(rec)
        if key in seen:continue
        seen.add(key)
        day=str(rec.get('Endorsement Date') or '')[:10].replace('/','-')
        try:datetime.strptime(day,'%Y-%m-%d')
        except ValueError:continue
        out.append({'date':day,'skill':str(rec.get('Skill Name') or '')})
    return out


def credibility_plan(cx, scores, profile, content, endors, until=None):
    """Conservative, profile-aware decisions and temporal comparison only."""
    history=scores_history(cx,until)
    topics={}
    for point in history:
        if point.get('score_type')!='Knowledge' or point.get('category') not in DIMENSION_GUIDANCE:continue
        topic=str(point.get('topic') or '').strip();day=str(point.get('measured_at') or '')
        if not topic or not day:continue
        try:value=float(point['value'])
        except (ValueError,TypeError):continue
        topics.setdefault(topic,{}).setdefault(point['category'],{})[day]=value
    evidence=profile_evidence(cx,profile,content,endors,until)
    receipts=_endorsement_observations(cx,until)
    entries=[]
    for topic,dims in sorted(topics.items()):
        values=[];latest_dates=[];rendered=[]
        for dim,guide in DIMENSION_GUIDANCE.items():
            dates=sorted(dims.get(dim,{}))
            if dates:
                date=dates[-1];value=dims[dim][date];latest_dates.append(date);values.append(value)
                prevdate=dates[-2] if len(dates)>1 else None
                previous=dims[dim][prevdate] if prevdate else None
                delta=round(value-previous,3) if previous is not None else None
            else:value=date=prevdate=previous=delta=None
            decision=_dimension_decision(dim,evidence)
            if value is None:
                decision={'status':'datenlage_unvollstaendig','priority':'niedrig','heading':'Kein Score-Messwert vorhanden',
                          'action':'Für diese Dimension liegt kein Messwert vor. Fehlende Messwerte sind keine niedrigen Scores.',
                          'check':'Neuen vollständigen Export abwarten.',
                          'basis':'Inferred Credibility Scores – Messwert fehlt'}
            rendered.append({'name':dim,'value':value,'date':date,'previous':previous,
                'previous_date':prevdate,'delta':delta,**decision,'safe_note':guide['safe']})
        most_recent=max(latest_dates,default=None)
        lowest=min(values) if values else None;highest=max(values) if values else None
        for x in rendered:
            x['relative_lowest']=(x['value'] is not None and lowest is not None and highest is not None
                                  and highest-lowest>=1 and x['value']==lowest)
        new_receipts=sum(1 for r in receipts if most_recent and r['date']>most_recent)
        # Observation windows are global; do not attribute unrelated skills to a topic.
        comparisons=[]
        for d in rendered:
            if d['delta'] is None:continue
            arrivals=sum(1 for r in receipts if d['previous_date']<r['date']<=d['date'])
            comparisons.append({'dimension':d['name'],'before':d['previous'],
                'after':d['value'],'delta':d['delta'],
                'from_date':d['previous_date'],'to_date':d['date'],
                'received_endorsements_in_window':arrivals,
                'caution':'Zeitliche Überschneidung; weder fachliche Zuordnung noch Ursache nachgewiesen.'})
        genuine=[d for d in rendered if d['status']=='prüfen']
        entries.append({'topic':topic,'last_measured':most_recent,'score_coverage':len(values),
            'mixed_measurement_dates':len(set(latest_dates))>1,
            'lowest_dimensions':[d['name'] for d in rendered if d['relative_lowest']],
            'dimensions':rendered,
            'suggested_focus':[d['name'] for d in genuine],
            'needs_action':bool(genuine),
            'new_endorsements_after_score':new_receipts,
            'comparisons':comparisons,
            'note':('Konkrete Prüfpunkte beruhen auf vorhandenen Profilfeldern, niemals allein auf einem niedrigen Score.'
                    if genuine else 'Kein konkret belegter Handlungsbedarf. Niedrige Werte allein sind kein Grund für zusätzliche Profileinträge.')})
    entries.sort(key=lambda x:(-x['score_coverage'],x['topic'].casefold()))
    return {
        'method':'Die fünf Dimensionen stammen aus Inferred Credibility Scores.csv. Maßnahmen basieren ausschließlich auf prüfbaren Profilfeldern; keine Reverse-Engineering-Formel; weder Kausalität noch ein LinkedIn-Rankingeffekt werden behauptet.',
        'topic_count':len(entries),'topics':entries,
        'received_endorsements_count':len(receipts),
        'profile_evidence':{k:v for k,v in evidence.items() if k!='domains'},
        'source_coverage':evidence['domains'],
        'measurement_protocol':[
            'Ausgangslage: identisches Score-Thema und identische Dimension mit Datum festhalten.',
            'Maßnahme: Nur eine reale, fachlich sinnvolle Profiländerung mit Datum dokumentieren. Keine Pflicht zur Änderung.',
            'Nachmessung: Bei späterem Complete-Export denselben Dimensionswert und das neue Messdatum vergleichen.',
            'Einordnung: Eine zeitliche Überschneidung beweist keine Ursache. Auch LinkedIns Modell kann sich verändern.'
        ],
    }

def advise(cx,profile,network,content,scores,until=None):
    """Only recommendations grounded in available fields. No opaque ranking estimates."""
    insights=[]
    sources={x:source_info(cx,x,until) for x in (
        'PROFILE','SKILLS','POSITIONS','MEMBER_SHARE_INFO','ALL_COMMENTS',
        'CONNECTIONS','INVITATIONS','ENDORSEMENTS','INFERENCE_TAKEOUT')}
    endors=endorsements(cx,until)
    changes=score_changes(cx,until)
    plan=credibility_plan(cx,scores,profile,content,endors,until)
    quality={}
    for dom in ('CONNECTIONS','INVITATIONS','ENDORSEMENTS','ALL_LIKES','ADS_CLICKED'):
        records=rows(latest_domain(cx,dom,until))
        deduplicated=distinct_rows(records)
        quality[dom]={'raw':len(records),'exact_duplicates':len(records)-len(deduplicated),
                      'unique_rows':len(deduplicated),
                      'source':sources[dom]['source'] if dom in sources and sources[dom] else None}

    def add(priority,group,title,evidence,action,basis):
        insights.append({'priority':priority,'group':group,'title':title,
                         'evidence':evidence,'action':action,'basis':basis})

    data_count=sum(bool(sources[x]) for x in ('PROFILE','SKILLS','MEMBER_SHARE_INFO','ALL_COMMENTS','CONNECTIONS'))
    if not data_count:
        add(1,'Datenbasis','Ersten Datenbestand importieren',
            'Für Profil, Beiträge, Kommentare und Kontakte liegen noch keine auswertbaren Datensätze vor.',
            'Laden Sie zuerst Ihren LinkedIn-Komplettexport als ZIP in „Datenquellen & Abruf“. Die API-Anbindung ist optional.',
            'Dateninventar')
    if network['connections_rows'] and network['unique_identifiers'] and network['connections_rows']>network['unique_identifiers']*1.3:
        add(1,'Datenqualität','Kontaktzahlen nicht als Wachstum interpretieren',
            f"{network['connections_rows']} Kontaktzeilen stehen {network['unique_identifiers']} erkennbaren Kontaktkennungen gegenüber.",
            'Vergleichen Sie eindeutige Kennungen und kontrollieren Sie die API-Seiten. Die Rohzeilen können mehrfach vorkommen.',
            'CONNECTIONS, eindeutige Profilkennungen')
    other_dupes=[(x,v) for x,v in quality.items() if x!='CONNECTIONS' and v['raw']>=6 and v['exact_duplicates']>=2 and v['exact_duplicates']/v['raw']>=.05]
    if other_dupes:
        overview=', '.join(f"{x}: {v['exact_duplicates']}" for x,v in other_dupes)
        add(1,'Datenqualität','Doppelte Datensätze erkannt',
            'Wortgleiche Dubletten in '+overview+'.',
            'Bei Zählungen werden nur wortgleiche JSON-Datensätze einmal berücksichtigt. Ähnliche, aber unterschiedliche Ereignisse bleiben erhalten; Rohdaten werden nicht verändert.',
            'Exakter Vergleich der JSON-Datensätze')
    if endors['received']:
        add(2,'Profil','Bestätigte Kenntnisse gezielt sichtbar machen',
            f"{endors['received']} verschiedene erhaltene Bestätigungen für {endors['received_skill_count']} Kenntnisse; "
            + (f"jüngster Eintrag vom {endors['last_received_date']}." if endors['last_received_date'] else 'kein Datumswert.'),
            'Ordnen Sie Ihre wichtigsten Kenntnisse nach ihrer Bedeutung für die aktuelle Tätigkeit. Die Zahl der erhaltenen Bestätigungen ist kein garantierter Reichweitenfaktor.',
            'ENDORSEMENTS, ausschließlich eingehende Bestätigungen')
    elif sources.get('SKILLS') and profile['skill_count']:
        add(2,'Profil','Kenntnisse durch fachlichen Nachweis ergänzen',
            f"{profile['skill_count']} Profilkenntnisse sind im Export vorhanden, aber keine erhaltene Bestätigung im verfügbaren ENDORSEMENTS-Bestand.",
            'Halten Sie relevante Kenntnisse aktuell und dokumentieren Sie konkrete Projekte und Ergebnisse. Fehlende Exportdaten belegen keine fehlenden Bestätigungen im Live-Profil.',
            'SKILLS / ENDORSEMENTS')
    if sources.get('PROFILE') and profile['position_count']==0:
        add(2,'Profil','Berufserfahrung im Export prüfen',
            'Für die aktuelle Datenversion sind keine Positionsdatensätze vorhanden.',
            'Prüfen Sie die Angaben im LinkedIn-Profil und ob ein vollständiger ZIP-Export vorliegt. Aus fehlenden Exportdaten lässt sich nicht automatisch auf ein unvollständiges Profil schließen.',
            'POSITIONS')
    if scores['point_count']:
        age=_iso_age(scores['measured_through'])
        if age is not None and age>21:
            add(2,'Bewertungen','Aktualität der internen Scores prüfen',
                f"Neuester verfügbarer Score-Messzeitpunkt {scores['measured_through']} ({age} Tage alt).",
                'Fordern Sie bei Bedarf einen neuen vollständigen LinkedIn-Export an. Fehlende neue Score-Werte bedeuten nicht, dass Ihr Score gefallen ist.',
                'Historische Inferred Credibility Scores aus ZIP')
        if changes:
            pos=sum(x['delta']>0 for x in changes);neg=sum(x['delta']<0 for x in changes)
            add(3,'Bewertungen','Bewertungsänderungen beobachten',
                f"In den jeweils letzten beiden Messpunkten identischer Dimensionen finden sich {pos} Anstiege und {neg} Rückgänge.",
                'Vergleichen Sie nur gleiche Themen und Dimensionen und beachten Sie Messdaten. Aus einer Änderung folgt kein Nachweis einer Wirkung auf den Feed.',
                'Inferred Credibility Scores, identische Themen/Dimensionen')
    else:
        add(2,'Bewertungen','Interne Scores gesondert einlesen',
            'Es liegen keine historischen Credibility-/Notability-Messwerte vor.',
            'Falls Sie diese Werte auswerten möchten, importieren Sie einen Complete-Export mit „Inferred Credibility Scores.csv“. INFERENCE_TAKEOUT enthält diese Scores nicht zwingend.',
            'Scoring-Tabelle / vollständiger LinkedIn-Export')
    if content['posts']:
        ranked=sorted(content['topics'].items(),key=lambda x:x[1],reverse=True)
        if ranked:
            name,number=ranked[0]
            add(3,'Inhalte','Thematische Positionierung überprüfen',
                f"Das häufigste erkannte Stichwort ist {name} in {number} von {content['posts']} Beitragsdatensätzen. Die Stichworterkennung ist unvollständig; exakt doppelte Beitragsdatensätze wurden vor der Zählung ausgeschlossen.",
                'Prüfen Sie, ob dieser Schwerpunkt zu Ihrer beruflichen Positionierung passt. Fachliche Qualität, Aktualität und relevante Diskussionen sind sinnvoller als eine künstliche Keyword-Quote.',
                'MEMBER_SHARE_INFO, einfache Stichwortzählung')
        else:
            add(3,'Inhalte','Beitragsinhalte manuell einordnen',
                f"{content['posts']} Beitragsdatensätze vorhanden, aber keine Treffer im begrenzten Stichwortkatalog.",
                'Ergänzen Sie bei Bedarf eigene Themenbegriffe. Aus fehlenden Keyword-Treffern folgt keine schlechte Content-Qualität.',
                'MEMBER_SHARE_INFO')
    if content['comments'] and content['posts']:
        add(3,'Aktivität','Eigene Kommentare von eingehender Diskussion unterscheiden',
            f"{content['posts']} eigene Beiträge und {content['comments']} eigene Kommentar-Datensätze im Datenbestand.",
            'ALL_COMMENTS enthält vor allem selbst verfasste Kommentare, nicht verlässlich alle Kommentare anderer unter eigenen Beiträgen. Für belastbare Ausspielungsvergleiche den lokalen Reichweitenmonitor mit zeitlich getrennten Beitragsstatistiken verwenden. Kommentare von Bekannten sind nicht pauschal minderwertig.',
            'MEMBER_SHARE_INFO / ALL_COMMENTS, keine eingehende Kommentarstatistik')
    elif not sources.get('ALL_COMMENTS') and sources.get('MEMBER_SHARE_INFO'):
        add(3,'Datenbasis','Kommentarbestand vervollständigen',
            'Beiträge sind verfügbar, ein Kommentar-Datensatz fehlt im gegenwärtigen Archiv.',
            'Nutzen Sie den vollständigen LinkedIn-Export oder warten Sie auf die Verarbeitung des API-Bereichs ALL_COMMENTS.',
            'Verfügbarkeit der Datenbereiche')
    insights.sort(key=lambda x:x['priority'])
    return {'method':'Regelbasierte Hinweise aus eigenen LinkedIn-Portabilitätsdaten; keine Aussage über Feed-Ranking',
            'endorsements':endors,'score_changes':changes,'credibility_plan':plan,'quality':quality,
            'source_summary':{k:v for k,v in sources.items() if v},
            'recommendations':insights[:8]}
