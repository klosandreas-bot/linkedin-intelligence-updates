"""Official LinkedIn DMA member portability client. No scraping, no password login."""
from __future__ import annotations
import json, os, time, urllib.error, urllib.parse, urllib.request, hashlib

BASE='https://api.linkedin.com/rest/'
VERSION='202312' # LinkedIn explicitly restricts DMA endpoints to this version.
# Complete official snapshot-domain list, 2026-04-15 documentation.
# https://learn.microsoft.com/en-us/linkedin/dma/member-data-portability/shared/snapshot-domain
# Do not silently exclude messages, identity, security, or ads: this is the owner's LOCAL archive.
DEFAULT_DOMAINS = ['ADS_CLICKED', 'MEMBER_FOLLOWING', 'LOGIN', 'RICH_MEDIA', 'SEARCHES', 'INFERENCE_TAKEOUT', 'ALL_COMMENTS', 'CONTACTS', 'EVENTS', 'RECEIPTS', 'AD_TARGETING', 'REGISTRATION', 'REVIEWS', 'ARTICLES', 'PATENTS', 'GROUPS', 'COMPANY_FOLLOWS', 'INVITATIONS', 'PHONE_NUMBERS', 'CONNECTIONS', 'EMAIL_ADDRESSES', 'JOB_POSTINGS', 'JOB_APPLICATIONS', 'JOB_SEEKER_PREFERENCES', 'LEARNING', 'INBOX', 'SAVED_JOBS', 'SAVED_JOB_ALERTS', 'PROFILE', 'SKILLS', 'POSITIONS', 'EDUCATION', 'TEST_SCORES', 'CAUSES_YOU_CARE_ABOUT', 'PUBLICATIONS', 'PROJECTS', 'ORGANIZATIONS', 'LANGUAGES', 'HONORS', 'COURSES', 'CERTIFICATIONS', 'RECOMMENDATIONS', 'ENDORSEMENTS', 'MEMBER_SHARE_INFO', 'SECURITY_CHALLENGE_PIPE', 'TRUSTED_GRAPH', 'MARKETPLACE_ENGAGEMENTS', 'MARKETPLACE_PROVIDERS', 'MARKETPLACE_OPPORTUNITIES', 'ACTOR_SAVE_ITEM', 'JOB_APPLICANT_SAVED_ANSWERS', 'TALENT_QUESTION_SAVED_RESPONSE', 'PROFILE_SUMMARY', 'ALL_LIKES', 'ALL_VOTES', 'RECEIPTS_LBP', 'EASYAPPLY_BLOCKING', 'LEARNING_COACH_AI_TAKEOUT', 'LEARNING_COACH_INBOX', 'LEARNING_ROLEPLAY_INBOX', 'VOLUNTEERING_EXPERIENCES', 'ACCOUNT_HISTORY', 'INSTANT_REPOSTS', 'IDENTITY_CREDENTIALS_AND_ASSETS', 'ADS_LAN']


def token():
    val=os.environ.get('LINKEDIN_ACCESS_TOKEN','').strip()
    if not val: raise RuntimeError('LINKEDIN_ACCESS_TOKEN fehlt. Lokal in .env bzw. bei GitHub als Repository Secret hinterlegen.')
    return val


def call(path, params=None, method='GET', body=None):
    url=BASE+path
    if params:url+='?'+urllib.parse.urlencode(params)
    headers={'Authorization':'Bearer '+token(), 'Linkedin-Version':VERSION,
             'X-Restli-Protocol-Version':'2.0.0','Accept':'application/json',
             'Content-Type':'application/json'}
    data=json.dumps(body).encode() if body is not None else None
    req=urllib.request.Request(url,headers=headers,data=data,method=method)
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req,timeout=40) as r:
                raw=r.read(25*1024*1024+1)
                if len(raw)>25*1024*1024:raise RuntimeError('API-Antwort zu groß')
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            text=e.read(4000).decode('utf-8',errors='replace')
            if e.code in (429,502,503,504) and attempt<2:
                time.sleep(2**attempt*2);continue
            raise APIError(e.code, text[:400]) from None
        except urllib.error.URLError as e:
            raise RuntimeError(f'Netzwerkfehler: {e.reason}') from None


class APIError(Exception):
    def __init__(self,status,message):
        self.status=status; self.message=message
        super().__init__(f'HTTP {status}: {message}')


def authorization_status():
    """Check whether the member actually authorized this developer application.

    Only retain non-sensitive status/timestamps, never member URNs or raw responses.
    """
    try:
        data=call('memberAuthorizations',{'q':'memberAndApplication'})
        elements=data.get('elements',[])
        valid=[e for e in elements if isinstance(e,dict) and 'DMA' in e.get('memberComplianceScopes',[])]
        return {'state':'active' if valid else 'not_confirmed',
                'regulated_at_ms':min((e['regulatedAt'] for e in valid if isinstance(e.get('regulatedAt'),int)),default=None)}
    except APIError as exc:
        return {'state':'http_error','http_status':exc.status,
                'note':('Zugriff verweigert' if exc.status in (401,403) else 'API-Fehler bei Autorisierungsprüfung')}
    except Exception:
        return {'state':'network_error','note':'Autorisierungsprüfung nicht erreichbar'}


def fetch_domain(domain,max_pages=500):
    """Follow LinkedIn's snapshot pages (start=0,1,...), until its terminal 404.

    Crucially, a 404 on the first page does NOT mean the API returned records.
    Only known 'No data found' responses are reported as empty or pending;
    e.g. 'No virtual resource found' is a configuration error instead.
    """
    rows=[]
    seen_pages={}
    for page in range(max_pages):
        try:
            data=call('memberSnapshotData',{'q':'criteria','domain':domain,'start':page})
        except APIError as exc:
            msg=exc.message.lower()
            if exc.status==404 and ('no data found' in msg or 'data not found' in msg):
                return rows, ('not_yet_available_or_empty' if page==0 else None)
            raise
        elements=data.get('elements',[])
        if isinstance(elements,dict):elements=[elements]
        if not isinstance(elements,list):
            raise RuntimeError(f'{domain}: Unerwartetes Antwortformat (elements)')
        page_items=[]
        for el in elements:
            if isinstance(el,dict):
                chunk=el.get('snapshotData',[])
                if isinstance(chunk,list):page_items.extend(chunk)
                elif chunk is not None:page_items.append(chunk)
        if not page_items:
            return rows, ('empty_response' if not rows else None)
        page_digest=hashlib.sha256(json.dumps(page_items,sort_keys=True,ensure_ascii=False,default=str,separators=(',',':')).encode('utf-8')).hexdigest()
        if page_digest in seen_pages:
            raise RuntimeError(f'{domain}: API-Seite {page} ist identisch mit Seite {seen_pages[page_digest]}; Abruf nicht gespeichert (Pagination prüfen)')
        seen_pages[page_digest]=page
        rows.extend(page_items)
    raise RuntimeError(f'{domain}: mehr als {max_pages} Seiten; Schutzlimit erreicht')


def fetch_domains(domains=None):
    domains=domains if domains is not None else DEFAULT_DOMAINS
    data={};statuses={}
    for domain in domains:
        started=time.monotonic()
        try:
            rows,note=fetch_domain(domain)
            state=('ready' if rows else ('not_yet_available_or_empty' if note=='not_yet_available_or_empty' else 'empty_response'))
            from advisory import distinct_rows
            effective=len(distinct_rows(rows))
            statuses[domain]={'state':state,'rows':effective,'raw_rows':len(rows),'exact_duplicates':len(rows)-effective,
                              'message':(f'{effective} eindeutige Datensätze ({len(rows)-effective} exakte Kopien)' if rows else ('LinkedIn meldet: No data found (leer oder noch in Verarbeitung)' if state=='not_yet_available_or_empty' else 'Leere API-Antwort')),
                              'elapsed_seconds':round(time.monotonic()-started,2)}
            if rows:data[domain]=rows
        except APIError as exc:
            statuses[domain]={'state':'http_error','rows':0,'http_status':exc.status,
                              'message':('HTTP '+str(exc.status)+': '+exc.message[:160]),
                              'elapsed_seconds':round(time.monotonic()-started,2)}
        except Exception as exc:
            statuses[domain]={'state':'error','rows':0,'message':str(exc)[:160],
                              'elapsed_seconds':round(time.monotonic()-started,2)}
    return data,statuses


def fetch_changes(start_ms=None, max_pages=40):
    """Conservative changelog fetching. Deduplicate repeated inclusive timestamp events."""
    unique={}
    cursor=start_ms
    for _ in range(max_pages):
        args={'q':'memberAndApplication','count':50}
        if cursor: args['startTime']=int(cursor)
        data=call('memberChangeLogs',args)
        items=data.get('elements',[])
        if not items:break
        for x in items:
            if isinstance(x,dict): unique[str(x.get('activityId') or x.get('id'))]=x
        times=[int(x['processedAt']) for x in items if x.get('processedAt')]
        if not times:break
        m=max(times)
        if not cursor or m>cursor:cursor=m
        else:break # avoid endless polling of repeated boundary event
        if len(items)<50: break
    return list(unique.values())
