"""V2.8: offline, data-quality and privacy tests."""
from __future__ import annotations
import io, json, sqlite3, unittest, zipfile
from analytics import reach_monitor,save_post_observation,delete_post_observation,_post_identity
from ingest import parse_linkedin_post_analytics_xlsx


def tables():
    cx=sqlite3.connect(':memory:')
    cx.row_factory=sqlite3.Row
    cx.executescript('''CREATE TABLE post_observations (
       id INTEGER PRIMARY KEY AUTOINCREMENT,channel TEXT,post_key TEXT,post_url TEXT,
       title TEXT,published_at TEXT,observed_at TEXT,source TEXT,impressions INTEGER,
       reach INTEGER,reactions INTEGER,comments INTEGER,reposts INTEGER,saves INTEGER,
       clicks INTEGER,video_views INTEGER,substantive_comments INTEGER,
       new_participants INTEGER,own_comments INTEGER,avg_watch_seconds REAL,notes TEXT);''')
    return cx


class ReachTest(unittest.TestCase):
    def setUp(self):self.cx=tables()
    def tearDown(self):self.cx.close()

    def sample(self,**kw):
        obj={'channel':'company','title':'CBAM: Lieferkette','published_at':'2026-10-15T08:00:00',
             'impressions':107,'comments':5,'reactions':7}
        obj.update(kw)
        return obj

    def test_manual_comments_not_automatically_classified(self):
        save_post_observation(self.cx,self.sample())
        post=reach_monitor(self.cx)['posts'][0]
        self.assertEqual(post['latest']['comments'],5)
        self.assertIsNone(post['latest']['substantive_comments'])
        self.assertIsNone(post['latest']['new_participants'])
        self.assertIn('Ein einzelner Datenstand',post['diagnosis']['detail'] if post['latest']['impressions']>=100 else 'Ein einzelner Datenstand')

    def test_discussion_stalled_reach_only_with_two_observations(self):
        save_post_observation(self.cx,self.sample(observed_at='2026-10-15T10:00:00+02:00',comments=2))
        save_post_observation(self.cx,self.sample(observed_at='2026-10-15T14:00:00+02:00',comments=5,substantive_comments=3,new_participants=2))
        post=reach_monitor(self.cx)['posts'][0]
        self.assertEqual(post['latest']['substantive_comments'],3)
        self.assertEqual(post['latest']['new_participants'],2)
        self.assertEqual(post['diagnosis']['level'],'watch')
        self.assertIn('keine zusätzlichen Impressionen',post['diagnosis']['detail'])

    def test_actual_growth_no_penalty_invented(self):
        save_post_observation(self.cx,self.sample(impressions=107,observed_at='2026-10-15T10:00:00+02:00'))
        save_post_observation(self.cx,self.sample(impressions=208,observed_at='2026-10-15T20:00:00+02:00'))
        self.assertIn('101 zusätzliche Impressionen',reach_monitor(self.cx)['posts'][0]['diagnosis']['detail'])

    def test_optional_fields_not_assumed_zero(self):
        save_post_observation(self.cx,self.sample(comments=None,reactions=None))
        post=reach_monitor(self.cx)['posts'][0]
        self.assertIsNone(post['latest']['comments'])
        self.assertIsNone(post['latest']['reactions'])

    def test_reject_fake_metadata(self):
        bad=[{'substantive_comments':6},{'new_participants':6},{'impressions':-1},
             {'url':'https://malware.invalid/posts/abc'},
             {'url':'javascript:alert(1)'}]
        for case in bad:
            with self.subTest(case=case),self.assertRaises(ValueError):
                save_post_observation(self.cx,self.sample(**case))

    def test_same_post_across_host_aliases_and_delete(self):
        r1=save_post_observation(self.cx,self.sample(url='https://www.linkedin.com/posts/something',impressions=2))
        r2=save_post_observation(self.cx,self.sample(url='https://linkedin.com/posts/something?trackingid=123',impressions=8))
        self.assertEqual(r1['post_key'],r2['post_key'])
        self.assertEqual(reach_monitor(self.cx)['total_posts'],1)
        self.assertTrue(delete_post_observation(self.cx,r1['id']))
        self.assertEqual(reach_monitor(self.cx)['posts'][0]['measurements'],1)

    def test_no_old_data_modified(self):
        save_post_observation(self.cx,self.sample())
        self.assertEqual(self.cx.execute('select count(*) from post_observations').fetchone()[0],1)

    def test_xlsx_minimal_file_no_external_libs(self):
        workbook='''<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Beitragsanalysen" sheetId="1" r:id="rId1"/></sheets></workbook>'''
        rel='''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml"/></Relationships>'''
        rows=[('URL des Beitrags','https://www.linkedin.com/posts/example'),('Veröffentlicht am','16.10.2026'),('Uhrzeit für die Veröffentlichung des Beitrags','07:30'),('Impressions','37'),('Erreichte Mitglieder','27'),('Kommentare','0'),('Gespeicherte Beiträge','1')]
        s='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
        for i,(a,b) in enumerate(rows,1):
            s+=f'<row r="{i}"><c r="A{i}" t="inlineStr"><is><t>{a}</t></is></c><c r="B{i}" t="inlineStr"><is><t>{b}</t></is></c></row>'
        s+='</sheetData></worksheet>'
        dest=io.BytesIO()
        with zipfile.ZipFile(dest,'w') as z:
            z.writestr('xl/workbook.xml',workbook)
            z.writestr('xl/_rels/workbook.xml.rels',rel)
            z.writestr('xl/worksheets/sheet1.xml',s)
        item=parse_linkedin_post_analytics_xlsx(dest.getvalue())
        self.assertEqual(item['impressions'],37)
        self.assertEqual(item['saves'],1)
        self.assertEqual(item['comments'],0)
        self.assertIsNone(item['reactions'])
        self.assertIsNone(item.get('substantive_comments'))




class DistributionSmokeTest(unittest.TestCase):
    def test_importable_and_version(self):
        import advisory, updater, server
        self.assertEqual(updater.local_version(), "2.9.0")
