'use strict';
const $=s=>document.querySelector(s);
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>n===null||n===undefined?'–':Number(n).toLocaleString('de-DE',{maximumFractionDigits:2});
const short=s=>String(s||'').slice(0,400);
const GERMAN_TZ='Europe/Berlin';
const localeDate = (value, dateOnly=false) => {
 if(!value)return '–';
 let v=String(value).trim();
 if(/^\d{4}-\d{2}-\d{2}$/.test(v)){
   const [yy,mm,dd]=v.split('-');return `${dd}.${mm}.${yy}`;
 }
 if(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(?::\d{2})? UTC$/.test(v))v=v.replace(' UTC','Z').replace(' ','T');
 else if(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(?::\d{2})?$/.test(v))v=v.replace(' ','T')+'Z';
 else if(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?$/.test(v))v+='Z';
 const d=new Date(v);
 if(Number.isNaN(d.getTime()))return String(value);
 return new Intl.DateTimeFormat('de-DE',{timeZone:GERMAN_TZ,
   day:'2-digit',month:'2-digit',year:'numeric',
   ...(dateOnly?{}:{hour:'2-digit',minute:'2-digit',timeZoneName:'short'})}).format(d);
};
const niceLabel=s=>String(s||'').replace(/LinkedIn API (\d{4}-\d{2}-\d{2} \d{2}:\d{2} UTC)/,(_,date)=>'LinkedIn API · '+localeDate(date));
const sourceName=s=>s==='api'?'LinkedIn API':s==='zip'?'LinkedIn ZIP':String(s||'unbekannt');
async function renderVersion(){try{const v=await request('/api/version');const node=$('#app-version');if(node)node.textContent='V'+String(v.version||'–')}catch(e){const node=$('#app-version');if(node)node.textContent='Version unbekannt'}}
let reachData=null,reachLoading=false,companyData=null,companyLoading=false,personalAggregateData=null,personalAggregateLoading=false;
let extendedData=null,extendedFilter='',extendedLoading=false;
let dataset=null,tab='overview',chosenTopic=null,chosenAdviceTopic=null,loading=false;
const pages={overview:['Analyse-Cockpit','Datenbasierter Überblick über Dein Profil und dessen Entwicklung'],scores:['Credibility & Notability','Jede Dimension und jeder Messzeitpunkt – ohne vermischte Themenwerte'],profile:['Profil & Änderungen','Strukturierte Profildaten und ihr tatsächlicher Exportstand'],content:['Content & Netzwerk','Themenhäufigkeiten, Beiträge, direkte Kontakte und Einladungen'],extended:['Extended Report','Alle eigenen Beiträge mit vollständigem Text, Quellen und verfügbaren Messständen'],reach:['Reichweite & Diskussion','Wirkliche Messstände statt Vermutungen über den LinkedIn-Algorithmus'],company:['Unternehmensseite','Exporte, Follower, Besucher und Content getrennt vom Privatprofil'],advice:['Auswertung & Empfehlungen','Profilabgleich, Score-Beobachtung und Maßnahmen nur bei tatsächlichen Lücken'],sources:['Datenquellen & Abruf','Offizielle LinkedIn-API, ZIP-Importe und Berichtsexport']};
function message(text,error=false){const e=$('#alert');e.textContent=text;e.hidden=false;e.className='alert'+(error?' error':'');setTimeout(()=>e.hidden=true,9000)}
async function request(url,opt={}){const r=await fetch(url,opt);const data=await r.json();if(!r.ok)throw Error(data.error||`HTTP ${r.status}`);return data}
async function reload(){if(loading)return;extendedData=null;loading=true;$('#refresh').disabled=true;try{dataset=await request('/api/data'+($('#snapshot').value?'?snapshot='+encodeURIComponent($('#snapshot').value):''));render();syncSelect()}catch(e){message(e.message,true)}finally{loading=false;$('#refresh').disabled=false}}
function syncSelect(){const sel=$('#snapshot'),old=sel.value;sel.replaceChildren(new Option('Neuester verfügbarer Stand',''));
 for(const s of dataset.snapshots){const label=`#${s.id} · ${s.reference_date?localeDate(s.reference_date,true):localeDate(s.imported_at,true)} · ${s.source}`;sel.add(new Option(label,String(s.id)))}
 if([...sel.options].some(x=>x.value===old))sel.value=old;
}
function stat(label,num,foot=''){return `<div class="stat"><div class="kicker">${escapeHtml(label)}</div><div class="num">${escapeHtml(fmt(num))}</div><div class="foot">${escapeHtml(foot)}</div></div>`}
function panel(title,body,note=''){return `<section class="card"><div class="card-head"><h2>${escapeHtml(title)}</h2>${note?`<small>${escapeHtml(note)}</small>`:''}</div>${body}</section>`}
function bar(name,num,max){const value=Number(num)||0;return `<div class="barrow"><span title="${escapeHtml(name)}">${escapeHtml(name)}</span><div class="barline"><div class="barfill" style="width:${max>0?Math.max(0,Math.min(100,value/max*100)):0}%"></div></div><strong>${escapeHtml(fmt(value))}</strong></div>`}
function empty(s){return `<div class="empty">${escapeHtml(s)}</div>`}
function overview(){const s=dataset.scores,n=dataset.network,p=dataset.profile,c=dataset.content,ads=dataset.ads;
 const scores=s.topics.length,top=s.top_knowledge.slice(0,7),tmax=top.length?top[0].score:4;
 return `<div class="notice"><strong>Methodischer Hinweis</strong> Die internen Scoring-Werte sind modellbasierte LinkedIn-Einschätzungen. Sie belegen keine direkte Wirkung auf die Feed-Reichweite. Nicht vorhandene Messpunkte gelten als fehlend, niemals als Null.</div>
 <div class="stats">${stat('Fachliche Score-Themen',scores,`${fmt(s.point_count)} historische Messpunkte`)}${stat('Notability',s.notability.score===null?'–':s.notability.score,'Skala 0 bis 5 · '+(s.notability.date||'nicht verfügbar'))}${stat('Kontakte – bereinigt',n.connections_rows,`${fmt(n.connections_exact_duplicates||0)} exakte Dubletten entfernt · ${fmt(n.unique_identifiers)} Kennungen`)}${stat('Werbe-Skill-Kategorien',ads.skill_count,'Separate Werbe-Klassifikation')}</div>
 <div class="grid2">${panel('Fachliche Kompetenzen',scores?`<div class="score-list">${s.topics.map(t=>{const score=Object.values(t.dimensions).reduce((a,v)=>a+v.score,0);return `<button class="go-score" data-topic="${escapeHtml(t.name)}"><span class="right">${fmt(score)}/20</span>${escapeHtml(t.name)}</button>`}).join('')}</div>`:empty('Noch keine Credibility Scores importiert. Bitte Complete-Export mit der entsprechenden CSV-Datei hinzufügen.'),'Exakte Themenkategorien')}
 ${panel('Top-Themen im Wissensmodell',top.length?`<div class="bars">${top.map(t=>bar(t.topic,t.score,4)).join('')}</div>`:empty('Noch keine normalisierten Knowledge Scores vorhanden.'),'Skala 1–4')}</div>
 <div class="grid2">${panel('Datenbestand',`<div class="stats" style="margin:0;grid-template-columns:repeat(2,minmax(0,1fr))">${stat('Eigene Beiträge',c.posts)}${stat('Kommentare',c.comments)}${stat('Profilkenntnisse',p.skill_count)}${stat('Snapshots',dataset.snapshots.length)}</div>`,'Aktuell verfügbar')}
 ${panel('Datenherkunft',dataset.snapshots.length?dataset.snapshots.slice(0,6).map(x=>`<div class="source"><div><b>${escapeHtml(niceLabel(x.label))}</b><br><span>${escapeHtml(x.source)} · ${escapeHtml(x.reference_date?localeDate(x.reference_date,true):localeDate(x.imported_at))}</span></div><small>#${x.id}</small></div>`).join(''):empty('Noch keine Daten vorhanden.'),'Letzte Snapshots')}</div>
 ${panel('Ihre nächsten Schritte', ((dataset.analysis?.recommendations||[]).slice(0,3).map(x=>`<div class="advice-mini"><b>${escapeHtml(x.title)}</b><p class="muted tiny">${escapeHtml(x.evidence)}</p></div>`).join('')||empty('Noch keine Handlungshinweise verfügbar.'))+`<button class="btn outline" id="open-advice">Alle Empfehlungen ansehen →</button>`,'Regelbasiert und überprüfbar')}`;
}
function lineChart(history){if(!history.length)return empty('Für diese Dimension liegen noch keine Messwerte vor.');
 const w=690,h=164,l=40,r=18,t=12,b=28,range=w-l-r;
 const unique=history.filter((r,i,a)=>a.findIndex(x=>x.measured_at===r.measured_at)===i).sort((a,b)=>a.measured_at.localeCompare(b.measured_at));
 const min=Math.min(...unique.map(r=>Number(r.value))),max=Math.max(...unique.map(r=>Number(r.value)));
 const ymax=Math.max(4,Math.ceil(max));const ymin=0;
 const points=unique.map((x,i)=>[l+(unique.length===1?.5:i/(unique.length-1))*range,t+(ymax-Number(x.value))/(ymax-ymin)*(h-t-b)]);
 const line=points.map(x=>x.join(',')).join(' ');
 return `<svg class="linechart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" role="img" aria-label="Historischer Verlauf"><line x1="${l}" y1="${h-b}" x2="${w-r}" y2="${h-b}" stroke="#456175"/><line x1="${l}" y1="${t}" x2="${l}" y2="${h-b}" stroke="#456175"/><text x="7" y="${t+7}">${ymax}</text><text x="13" y="${h-b}">0</text><polyline points="${line}" fill="none" stroke="#63e0bf" stroke-width="3" vector-effect="non-scaling-stroke"/>${points.map((p,i)=>`<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="#62d9d9"><title>${escapeHtml(unique[i].measured_at)} · ${fmt(unique[i].value)}</title></circle>`).join('')}<text x="${l}" y="${h-5}">${escapeHtml(unique[0].measured_at)}</text><text text-anchor="end" x="${w-r}" y="${h-5}">${escapeHtml(unique.at(-1).measured_at)}</text></svg>`;
}
function scores(){const s=dataset.scores;if(!s.topics.length)return panel('Score-Historie fehlt',empty('Importiere den vollständigen LinkedIn-Export, der „Inferred Credibility Scores.csv“ enthält. Der API-Datenbereich INFERENCE_TAKEOUT garantiert diese Werte nicht.'));
 if(!chosenTopic||!s.topics.some(t=>t.name===chosenTopic))chosenTopic=s.topics[0].name;
 const topic=s.topics.find(t=>t.name===chosenTopic),dimensions=s.dimensions;
 const dhtml=dimensions.map(x=>{const point=topic.dimensions[x];return `<div class="dim"><strong>${point?fmt(point.score):'–'}</strong><small>${escapeHtml(x)}</small><small>${point?escapeHtml(point.date):'keine Messung'}</small></div>`}).join('');
 const history=s.history.filter(x=>x.topic===chosenTopic);
 const hgroups=dimensions.map(cat=>{const h=history.filter(x=>x.category===cat);return `<h3>${escapeHtml(cat)}</h3>${lineChart(h)}`}).join('');
 const no=s.notability;
 return `<div class="stats">${stat('Fachgebiete',s.topics.length)}${stat('Historische Datenpunkte',s.point_count)}${stat('Notability',no.score,'Letzte Bewertung '+(no.date||'–'))}${stat('Notability Tier',no.tier,'Gesonderte Skala von 1 bis 4')}</div>
 <div class="notice"><strong>Messdatum statt Importdatum</strong> Neueste Dimensionsmessung ${escapeHtml(s.latest_dimension_measurement||'–')}. ${fmt(s.topics_recent)} Themen innerhalb der letzten 14 Tage vor diesem Datum und ${fmt(s.topics_historical)} ältere Themen. Unterschiedliche Themenbezeichnungen bleiben getrennt; Namensähnlichkeit beweist keine Umbenennung.</div>
 <div class="grid2">${panel('Fachgebiet auswählen',`<div class="score-list">${s.topics.map(x=>`<button class="choose-topic ${chosenTopic===x.name?'selected':''}" data-topic="${escapeHtml(x.name)}">${escapeHtml(x.name)} <span class="right">${escapeHtml(x.measured_at||'–')} · ${fmt(Object.keys(x.dimensions).length)}/5 ${x.older_measurement?'· älter':''}</span></button>`).join('')}</div>`,'Nach jüngster Dimensionsmessung sortiert')}
 ${panel('Zuletzt gemessen',`<h3>${escapeHtml(chosenTopic)}</h3><p class="tiny muted">Letzte Dimensionsmessung dieses Fachgebiets ${escapeHtml(topic.measured_at||'–')}${topic.older_measurement?' · historischer Messstand':''}.</p><div class="dimgrid">${dhtml}</div><p class="muted tiny">Jede Dimension zeigt ihren eigenen letzten gemessenen Wert. Identische Daten an mehreren Tagen sind möglich.</p>`,'Skala 1–4')}
 </div>${panel('Historische Entwicklung des gewählten Fachgebiets',hgroups,`${history.length} Punkte`)}
 ${panel('Notability – eigenständiges Modell',`<p>Letzter aggregierter Wert <strong>${fmt(no.score)}</strong> / 5 am ${escapeHtml(no.date||'–')}. Tier <strong>${fmt(no.tier)}</strong> / 4.</p>${lineChart(s.history.filter(x=>x.category==='Aggregated notability score'))}<p class="muted tiny">Fehlende Notability-Unterdimensionen werden nicht als schlechte Bewertung interpretiert.</p>`,'Nicht mit Knowledge addieren')}`;
}
function profile(){const p=dataset.profile,prof=p.profile,changes=p.changes||{changes:[],skills_added:[]};
 const rows=Object.entries(prof).filter(([k,v])=>typeof v==='string'&&v).filter(([k])=>!/(Birth|Zip|Address|Name)/i.test(k));
 return `<div class="stats">${stat('Berufliche Stationen',p.position_count)}${stat('Explizite Kenntnisse',p.skill_count)}${stat('Ausbildungseinträge',p.education.length)}${stat('Snapshots',dataset.snapshots.length)}</div>
 <div class="grid2">${panel('Exportiertes Profil',rows.map(([k,v])=>`<div class="profile-block"><div class="tiny">${escapeHtml(k)}</div><div class="text-preview">${escapeHtml(v)}</div></div>`).join('')||empty('Keine Profilinformationen.'),'Strukturierte Angaben')}
 ${panel('Erfahrung & Qualifikationen',`<h3>Positionen</h3>${p.positions.map(x=>`<div class="profile-block"><strong>${escapeHtml(x.Title||x.title||'')}</strong><div class="tiny">${escapeHtml(x['Company Name']||'')}</div><div class="text-preview">${escapeHtml(short(x.Description||''))}</div></div>`).join('')||empty('Keine Positionen')}<h3>Explizite Skills</h3><div>${p.skills.map(x=>`<span class="tag">${escapeHtml(x)}</span>`).join('')||empty('Keine Skills')}</div>`,'LinkedIn Profilfelder')}</div>
 ${panel('Nachweisbare Profiländerungen',`<p class="muted tiny">Abgleich der letzten zwei unterschiedlichen gespeicherten Stände je Bereich. Änderungen können aus API oder ZIP stammen; Importzeitpunkt und Änderungszeitpunkt auf LinkedIn können abweichen.</p>${changes.changes.length?changes.changes.map(x=>`<div class="profile-block"><strong>${escapeHtml(x.item||x.domain)}</strong><div class="muted tiny">${escapeHtml(x.field)} · Snapshot #${fmt(x.snapshot_id)} · ${escapeHtml(x.source)}</div><div class="tiny">${escapeHtml(x.before||'(zuvor leer)')} → <strong>${escapeHtml(x.after||'(jetzt leer)')}</strong></div></div>`).join(''):empty('Keine geänderten Ausbildungs- oder Beschäftigungszeiträume in den jeweils letzten zwei unterschiedlichen Datenständen nachweisbar.')}${changes.skills_added.length?`<p class="muted tiny">Neue Profilkenntnisse im Vergleich zum vorherigen abweichenden Stand</p><div>${changes.skills_added.map(x=>`<span class="tag">${escapeHtml(x)}</span>`).join('')}</div>`:''}<div class="notice">Profiländerungen und spätere Credibility-Scores können zeitlich zusammenfallen. Daraus folgt noch keine nachgewiesene Kausalität.</div>`,'Nur vorhandene Datenstände verglichen')}`;
}
function content(){const c=dataset.content,n=dataset.network,ads=dataset.ads;
 const top=Object.entries(c.topics).sort((a,b)=>b[1]-a[1]); const maximum=top.length?top[0][1]:1;
 const items=c.recent_posts.slice(0,20).map(p=>`<div class="source"><div><div class="tiny">${escapeHtml(p.date)}</div><div>${escapeHtml(short(p.preview))}</div><div>${p.topics.map(x=>`<span class="tag">${escapeHtml(x)}</span>`).join('')}</div></div>${p.url.startsWith('https://www.linkedin.com/')?`<a href="${escapeHtml(p.url)}" target="_blank" rel="noopener noreferrer">Beitrag ↗</a>`:''}</div>`).join('');
 return `<div class="stats">${stat('Beiträge im neuesten Vollbestand',c.posts)}${stat('Eigene Kommentare',c.comments)}${stat('Kontaktkennungen (näherungsweise)',n.unique_identifiers,`${fmt(n.connections_raw_rows)} Rohzeilen (davon ${fmt(n.connections_exact_duplicates)} exakt doppelt)`)}${stat('Einladungen – ausgehend',n.outgoing,'Eingehend '+n.incoming)}</div>
 <div class="grid2">${panel('Themenhäufigkeit',top.length?`<div class="bars">${top.map(([k,v])=>bar(k,v,maximum)).join('')}</div>`:empty('Im ausgewählten Snapshot sind keine Beitragstexte vorhanden.'),'Mehrfachzuordnung möglich')}
 ${panel('Werbe-Klassifikation',`<div class="metric">${fmt(ads.skill_count)}</div><p class="tiny">Member Skills – getrennt von öffentlich eingetragenen Skills.</p><div class="text-preview">${ads.skills.map(x=>`<span class="tag">${escapeHtml(x)}</span>`).join('')}</div><div class="profile-block"><span class="muted">Experience Targeting:</span> ${escapeHtml(ads.experience||'–')}</div>`,'Kein Credibility Score')}</div>
 ${panel('Beitragsarchiv',items||empty('Kein Shares-Export importiert. Basic-Exporte enthalten diese Datei oft nicht.'),'Aus vorhandener Quelle')}`;
}
function extended(){
 if(!extendedData)return panel('Extended Report',`<p>Alle gespeicherten eigenen Beiträge mit Datum, Textlänge, Themen, Link und – soweit separat erfasst – Reichweitenmessung.</p><p class="muted tiny">Nicht der datensparsame KI-Bericht. Hier können vollständige eigene Beiträge enthalten sein. Export nur bewusst und lokal.</p><button class="btn primary" id="extended-load">Vollständigen Bericht laden</button>`,'Privat · nur lokal');
 const posts=extendedData.posts||[];
 const needle=extendedFilter.toLocaleLowerCase('de-DE');
 const matching=posts.filter(p=>(p.preview+' '+(p.text||'')+' '+p.topics.join(' ')).toLocaleLowerCase('de-DE').includes(needle));
 const rows=matching.map(p=>{
  const obs=p.reach_observation; const ag=p.aggregate_summary;
  return `<tr><td>${escapeHtml(localeDate(p.published_at,true))}<div class="tiny muted">${escapeHtml(p.source)} · #${escapeHtml(p.snapshot_id)}${p.new_since_previous_snapshot===true?' · <b>NEU gegenüber Vorbestand</b>':''}</div></td><td><details><summary>${escapeHtml(short(p.preview)||'(kein Text)')}</summary><div class="text-preview" style="white-space:pre-wrap;max-height:340px;overflow:auto">${escapeHtml(p.text||'Text nicht vorhanden')}</div></details>${p.url.startsWith('https://www.linkedin.com/')?`<a href="${escapeHtml(p.url)}" target="_blank" rel="noopener noreferrer">Originalbeitrag ↗</a>`:''}</td><td>${escapeHtml(ag?.format||'nicht erfasst')}</td><td>${fmt(p.characters)}<div class="tiny muted">${p.styled_unicode?'Unicode-Stilzeichen':'Klartext'}</div></td><td>${p.topics.map(x=>`<span class="tag">${escapeHtml(x)}</span>`).join('')||'–'}</td><td>${obs?`<strong>${fmt(obs.impressions)}</strong><div class="tiny muted">Einzelmessung: ${escapeHtml(localeDate(obs.observed_at))}</div>`:ag?.impressions!==null&&ag?.impressions!==undefined?`<strong>${fmt(ag.impressions)}</strong><div class="tiny muted">Wochenexport #${fmt(ag.source_import)} · keine Zeitreihe</div>`:'–'}</td></tr>`;
 }).join('');
 return `<div class="notice"><b>${fmt(posts.length)} eigene Beiträge im ausgewählten Datenstand</b> · ${fmt(extendedData.summary.with_observation)} mit getrennt erfassten Reichweitenwerten. ${extendedData.comparison?.previous_snapshot_id?'Seit Snapshot #'+fmt(extendedData.comparison.previous_snapshot_id)+' ('+escapeHtml(extendedData.comparison.previous_source)+'): '+fmt(extendedData.comparison.new_count)+' neue Beitragsdatensätze.':'Kein älterer Beitrags-Snapshot für einen direkten Vergleich.'} Ohne einzelne LinkedIn-Impressions lässt sich aus Textlänge allein kein Reichweiteneffekt errechnen.</div>
 <div class="stats">${stat('Beiträge',extendedData.total)}${stat('Kürzer als 1.500 Zeichen',extendedData.summary.short_under_1500)}${stat('Mind. 2.500 Zeichen',extendedData.summary.long_over_2500)}${stat('Mit Einzelmessungen',extendedData.summary.with_observation)}${stat('Mit Wochenübersicht',extendedData.summary.with_aggregate_summary)}</div>
 ${panel('Vollständige Beitragsliste',`<label for="extended-filter">Beiträge durchsuchen</label><input id="extended-filter" value="${escapeHtml(extendedFilter)}" placeholder="z. B. EUDR, Fragebogen, PPWR"/><div class="buttonline"><a class="btn outline" href="/api/extended-report?full=1&download=1${$('#snapshot')?.value?'&snapshot='+encodeURIComponent($('#snapshot').value):''}" download="linkedin-extended-report.json">Extended Report (vollständig) als JSON ↓</a><button class="btn outline" id="extended-reload">Daten erneut laden</button></div><p class="muted tiny">${escapeHtml(extendedData.method)}</p><div class="scroll-table"><table class="table"><thead><tr><th>Datum / Quelle</th><th>Beitragstext</th><th>Format*</th><th>Länge</th><th>Schlagworte</th><th>Impressionen*</th></tr></thead><tbody>${rows||'<tr><td colspan="6">Keine Treffer.</td></tr>'}</tbody></table></div><p class="tiny muted">* Quellen getrennt: Einzelmessung oder kumulierter Stand aus Wochenexport. Nicht aus der Portabilitäts-API abgeleitet.</p>`,'Lokale Tabelle · keine Datenübertragung')}`;
}
async function loadExtended(){
 if(extendedLoading)return;extendedLoading=true;
 try{const snap=$('#snapshot')?.value||'';extendedData=await request('/api/extended-report?full=1'+(snap?'&snapshot='+encodeURIComponent(snap):''));if(tab==='extended')render()}
 catch(e){message('Extended Report: '+e.message,true)}finally{extendedLoading=false}
}
function credibilityExplorer(){
 const plan=dataset.analysis?.credibility_plan||{},topics=plan.topics||[];
 if(!topics.length)return panel('Credibility fundiert einordnen',`<p>Für die fachgebietsbezogene Einordnung fehlen historische Dimensionen aus <strong>Inferred Credibility Scores.csv</strong>.</p>${empty('Importiere einen vollständigen LinkedIn-Datenexport mit dieser CSV. Die API liefert diese Scores nicht zwingend.')}`,'Keine Werte erfunden');
 if(!chosenAdviceTopic||!topics.some(t=>t.topic===chosenAdviceTopic))chosenAdviceTopic=topics[0].topic;
 const cur=topics.find(t=>t.topic===chosenAdviceTopic);
 const select=`<label for="cred-topic" class="tiny">Fachgebiet auswählen</label><select id="cred-topic" class="cred-select">${topics.map(t=>`<option value="${escapeHtml(t.topic)}" ${t.topic===chosenAdviceTopic?'selected':''}>${escapeHtml(t.topic)}</option>`).join('')}</select>`;
 const base=`<div class="cred-intro"><div><div class="tiny">Letzte Score-Messung</div><strong>${escapeHtml(cur.last_measured||'unbekannt')}</strong></div><div><div class="tiny">Dimensionen vorhanden</div><strong>${fmt(cur.score_coverage)} / 5</strong></div><div><div class="tiny">Nach der Messung erhaltene Bestätigungen</div><strong>${fmt(cur.new_endorsements_after_score)}</strong><span class="tiny">Nicht automatisch diesem Fachgebiet zugeordnet</span></div></div>`;
 const statusName={prüfen:'Konkrete Angabe prüfen',beobachten:'Beobachten',kein_handlungsbedarf:'Kein belegter Handlungsbedarf',datenlage_unvollstaendig:'Datenlage unvollständig'};
 const dims=cur.dimensions.map(d=>{
   const diff=d.delta===null?'kein Vergleich':`${d.delta>0?'+':''}${fmt(d.delta)} zum ${escapeHtml(d.previous_date)}`;
   const marker=`<span class="cred-status cred-status-${d.status==='prüfen'?'review':d.status==='kein_handlungsbedarf'?'fine':d.status==='beobachten'?'watch':'unknown'}">${escapeHtml(statusName[d.status]||'Beobachten')}</span>`;
   const relative=d.relative_lowest?'<span class="cred-relative soft">Relativ niedriger Messwert</span>':'';
   const observation=d.delta!==null?`<p class="muted tiny">Beobachtete Score-Änderung ${d.delta>0?'+':''}${fmt(d.delta)}. Daraus lässt sich kein Ursache-Wirkungs-Zusammenhang ableiten.</p>`:'';
   return `<details class="cred-dim" ${d.status==='prüfen'?'open':''}><summary><span class="cred-dim-label">${escapeHtml(d.name)} ${marker}${relative}</span><span class="cred-value">${d.value===null?'–':fmt(d.value)} <small>${d.value===null?'fehlend':'/ 4'}</small></span></summary><div class="cred-dim-body"><p class="muted tiny">${d.date?'Messwert vom '+escapeHtml(d.date):'Kein Messwert – nicht als niedrig interpretieren.'} · ${diff}</p><h3>${escapeHtml(d.heading)}</h3><p>${escapeHtml(d.action)}</p><p class="muted tiny"><strong>Datengrundlage</strong> ${escapeHtml(d.basis)}</p><p class="muted tiny"><strong>Prüfschritt</strong> ${escapeHtml(d.check)}</p><p class="muted tiny">${escapeHtml(d.safe_note)}</p>${observation}</div></details>`;
 }).join('');
 const observation=cur.new_endorsements_after_score?`<div class="cred-observation"><strong>Beobachtung – noch keine neue Messung</strong><p>Seit dem letzten verfügbaren Score-Messdatum sind ${fmt(cur.new_endorsements_after_score)} erhaltene Kenntnisbestätigungen im Export datiert. Es ist nicht belegt, dass sie zu diesem Fachgebiet gehören. Sobald eine neuere Score-Messung erscheint, kann derselbe Dimensionswert erneut verglichen werden.</p></div>`:'';
 const comparisons=(cur.comparisons||[]).filter(c=>c.delta!==0).slice(-5).reverse().map(c=>`<tr><td>${escapeHtml(c.dimension)}</td><td>${escapeHtml(c.from_date)} – ${escapeHtml(c.to_date)}</td><td>${fmt(c.before)} → ${fmt(c.after)}</td><td>${c.delta>0?'+':''}${fmt(c.delta)}</td><td>${fmt(c.received_endorsements_in_window)}</td></tr>`).join('');
 const comparePanel=comparisons?`<div class="scroll-table"><table class="table"><thead><tr><th>Dimension</th><th>Messzeitraum</th><th>Wert</th><th>Δ</th><th>Bestätigungen im Zeitraum*</th></tr></thead><tbody>${comparisons}</tbody></table></div><p class="muted tiny">*Erhaltene Bestätigungen aller Fachgebiete. Weder fachliche Zuordnung noch Wirkung sind nachgewiesen.</p>`:`<p class="muted tiny">Für dieses Fachgebiet sind zwischen den letzten beiden Messungen keine Score-Änderungen nachgewiesen. Das ist kein Misserfolg.</p>`;
 const checklist=(plan.measurement_protocol||[]).map((x,i)=>`<div class="cred-step"><b>${i+1}</b><span>${escapeHtml(x)}</span></div>`).join('');
 const conclusion=`<div class="cred-verdict ${cur.needs_action?'review':''}"><strong>${cur.needs_action?'Einzelne Profilfelder sollten überprüft werden':'Kein konkret belegter Handlungsbedarf'}</strong><p>${escapeHtml(cur.note)}</p></div>`;
 return `${panel('Credibility – mit Profilabgleich statt Score-Jagd',`<div class="cred-controls">${select}<p class="muted tiny">Niedrige Messwerte sind keine automatisch erkannten Profillücken. Die Hinweise vergleichen vorhandene Exportfelder und kennzeichnen fehlende Daten ausdrücklich.</p></div>${base}${conclusion}<p class="muted tiny">${cur.mixed_measurement_dates?'Achtung: Die Dimensionen haben teilweise verschiedene Messdaten. Relative Werte daher nur eingeschränkt vergleichbar.':''}</p><div class="cred-dims">${dims}</div>${observation}`,'Bewerten, nicht künstlich optimieren')}${panel('Zeitliche Beobachtungen',comparePanel,'Gleiche Dimension, echte Messdaten')}${panel('Kontrollierter Vorher-Nachher-Vergleich',`<div class="cred-steps">${checklist}</div><p class="muted tiny">Die Auswertung ändert keine Profildaten und kennt keine geheime LinkedIn-Score-Formel.</p>`,'Keine Scheinkausalität')}`;
}
function advice(){
 const a=dataset.analysis||{}, tips=a.recommendations||[],e=a.endorsements||{},quality=a.quality||{}, changes=a.score_changes||[];
 const tag=p=>p===1?'Datenqualität':p===2?'Profil & Bewertung':'Weiterentwicklung';
 const note=`<div class="notice"><strong>So entstehen diese Hinweise</strong><p>Die Auswertung verwendet feste, nachvollziehbare Regeln und nur vorhandene eigene Exportdaten. Es gibt keine künstliche KI-Bewertung, keinen errechneten LinkedIn-Rankingwert und keine automatischen Profiländerungen. Fehlende Daten werden nicht als schlechte Leistung gewertet.</p></div>`;
 const kpis=`<div class="stats">${stat('Bestätigungen erhalten',e.received??0,`${fmt(e.received_skill_count??0)} Kenntnisse`)}${stat('Bestätigungen vergeben',e.given??0,'Nicht mit erhaltenen vermischen')}${stat('Exakte Duplikate bei Bestätigungen',e.exact_duplicates??0,'Rohdaten unverändert')}${stat('Hinweise',tips.length,'Aus verfügbarem Datenstand')}</div>`;
 const cards=tips.map(t=>`<article class="advice-item"><div class="advice-meta"><span class="advice-label">${escapeHtml(tag(t.priority))}</span><span>${escapeHtml(t.group)}</span></div><h3>${escapeHtml(t.title)}</h3><p class="evidence">${escapeHtml(t.evidence)}</p><p class="action"><strong>Empfehlung</strong> ${escapeHtml(t.action)}</p><div class="basis">Datenbasis: ${escapeHtml(t.basis)}</div></article>`).join('')||empty('Aktuell sind keine Empfehlungen ableitbar. Importieren Sie einen ZIP-Export.');
 const qualityRows=Object.entries(quality).filter(([k,v])=>v.raw).map(([k,v])=>`<tr><td>${escapeHtml(k)}</td><td>${fmt(v.raw)}</td><td>${fmt(v.exact_duplicates)}</td><td>${fmt(v.unique_rows)}</td></tr>`).join('');
 const qm=qualityRows?`<table class="table"><thead><tr><th>Bereich</th><th>Rohzeilen</th><th>Duplikate exakt</th><th>Unterschiedliche Zeilen</th></tr></thead><tbody>${qualityRows}</tbody></table><p class="muted tiny">Unterschiedliche JSON-Zeilen sind nicht automatisch unterschiedliche Personen oder Ereignisse. Beispielsweise können Kontakte trotz anderer Exportfelder mehrfach vorkommen.</p>`:empty('Noch keine prüfbaren Datenbereiche.');
 const sr=changes.slice(0,12).map(r=>`<tr><td>${escapeHtml(r.topic||'Notability')}</td><td>${escapeHtml(r.dimension)}</td><td>${fmt(r.previous)} → ${fmt(r.current)}</td><td class="${r.delta>0?'delta-plus':'delta-minus'}">${r.delta>0?'+':''}${fmt(r.delta)}</td><td>${escapeHtml(r.current_date)}</td></tr>`).join('');
 return `${note}${kpis}${credibilityExplorer()}${panel('Konkrete nächste Schritte',`<div class="advice-grid">${cards}</div>`,'Individuell aus Ihren Datensätzen abgeleitet')}
 <div class="grid2 grid-equal">${panel('Datenqualität prüfen',qm,'Rohdaten bleiben unverändert')}
 ${panel('Kenntnisbestätigungen richtig zählen',`<p>Die API liefert erhaltene und vergebene Bestätigungen gemeinsam. Hier werden sie getrennt und wortgleiche Dubletten nicht mitgezählt.</p><div class="stats" style="grid-template-columns:repeat(2,minmax(0,1fr))">${stat('Eingehend',e.received??0)}${stat('Ausgehend',e.given??0)}</div><p class="muted tiny">Letzte erhaltene Bestätigung: ${escapeHtml(e.last_received_date||'kein Datum')}.</p><div>${Object.entries(e.received_by_skill||{}).map(([name,v])=>`<span class="tag">${escapeHtml(name)} · ${fmt(v)}</span>`).join('')}</div>`,'Nur lokal sichtbare Fachgebiete')}</div>
 ${panel('Messbare Score-Änderungen',sr?`<div class="scroll-table"><table class="table"><thead><tr><th>Thema</th><th>Dimension</th><th>Vorher → jetzt</th><th>Δ</th><th>Datum</th></tr></thead><tbody>${sr}</tbody></table></div>`:empty('Noch keine unterschiedlichen Messwerte in aufeinanderfolgenden Messungen derselben Dimension. Gleiche Werte und fehlende Messungen sind keine Verschlechterung.'),'Nur exakte Themen-/Dimensionsvergleiche')}`;
}
function sources(){const st=dataset.latest_api_sync;
 const statusInfo=st?`<div class="notice" style="margin-bottom:16px"><b>Letzter API-Lauf:</b> ${escapeHtml(localeDate(st.executed_at))} · ${fmt(Object.values(st.status_by_domain||{}).filter(v=>v.state==='ready').length)} von ${fmt(st.requested_domains)} Bereichen mit Daten.<details><summary>Alle Datenbereiche und Abrufstatus</summary><div class="text-preview">${Object.entries(st.status_by_domain||{}).map(([k,v])=>`<div>${escapeHtml(k)} – ${escapeHtml(v.state)} · ${fmt(v.rows)} eindeutig${v.exact_duplicates?' / '+fmt(v.exact_duplicates)+' Kopien':''}</div>`).join('')}</div></details></div>`:'<p class="tiny muted">Noch kein protokollierter API-Lauf.</p>';
 return `${statusInfo}<div class="grid2 grid-equal">${panel('ZIP-Datei lokal importieren',`<div class="upload"><div style="font-size:26px">⇪</div><strong>LinkedIn Basic oder Complete ZIP</strong><p class="muted tiny">Originaldatei auswählen. Keine Übertragung ins Internet; Auswertung ausschließlich auf diesem Rechner.</p><input type="file" id="filezip" accept=".zip,application/zip"/><button class="btn primary" id="import-btn">ZIP importieren</button></div><p class="tiny">Für historische Credibility-Scores ist die Datei „Inferred Credibility Scores.csv“ entscheidend. Alle Originaldateien einschließlich privater Bereiche bleiben ausschließlich lokal archiviert. Der ZIP-Import überträgt nichts an GitHub.</p>`,'Ohne Kontozugriff')}
 ${panel('Direktabruf über LinkedIn',`<p class="muted">Lädt alle 65 offiziell dokumentierten Snapshot-Datenbereiche einschließlich Inferences, Nachrichten, Anzeigen, Identitäts- und Sicherheitsdaten sowie die vollständigen neuen Changelog-Ereignisse lokal herunter. Version 202312. OAuth-Token in der lokalen .env hinterlegen.</p><div class="buttonline"><button class="btn primary" id="sync-btn">Alle LinkedIn-Daten abrufen</button> <button class="btn outline" id="probe-btn">API-Schnelltest</button> <button class="btn outline" id="retry-errors-btn">Nur API-Fehler erneut prüfen</button></div><div id="sync-diagnostics" class="notice" style="margin-top:14px">Letzten API-Abruf prüfen …</div><div class="notice" style="margin-top:18px">Die API kann 404 zurückgeben, während LinkedIn den ersten Snapshot aufbereitet. Nicht jeder Datenbereich enthält schon sofort Ergebnisse. Die Score-Historie über INFERENCE_TAKEOUT ist noch unbestätigt.</div>`,'Benötigt eigenen OAuth-Token')}</div>
 <div>${panel('Bericht für KI Auswertung / GitHub',`<p class="muted">Der kuratierte JSON-Bericht enthält detaillierte Fach-Scores und Themenwerte, aber keine Kontaktlisten, privaten Nachrichten oder Tokens. Der Extended Report enthält hingegen die eigenen vollständigen Beitragstexte und muss vor externer Weitergabe geprüft werden.</p><label for="report-type" class="field-label">Berichtstyp auswählen</label><select id="report-type"><option value="curated">Kuratierter Bericht (datensparsam)</option><option value="extended">Extended Report – alle eigenen Beiträge</option></select><div class="buttonline"><a class="btn outline" id="report-download" href="/api/export" download="linkedin-kuratierter-bericht.json">Bericht herunterladen</a><button id="report-btn" class="btn primary">Bericht lokal speichern</button></div><p class="tiny">Für GitHub: privates Repository, Secret LINKEDIN_ACCESS_TOKEN, GitHub Action aus diesem Paket. Der Bericht kann zur KI-Auswertung verwendet werden. Vor dem Teilen Inhalt und Datenschutz prüfen.</p>`,'Datensparsam')}
</div>

 ${panel('API-/ZIP-Quellenabgleich',`<div id="source-audit">Vergleich wird berechnet …</div><p class="muted tiny">Schreibgeschützt. Die Tabelle vergleicht die letzten lokal vorhandenen Daten je Quelle, einschließlich Überschneidungen und Feldstrukturen. Sie ändert keine bestehenden Fachanalysen und führt keine Daten automatisch zusammen.</p>`,'Neu · Quellengüte vor Datenmenge')}
 ${panel('Datenstand je Bereich – letzter erfolgreicher Import',`<p class="muted tiny">Hier siehst Du alle importierten Datenbereiche, auch private Kategorien. Für jeden Datenbereich werden Quelle, letzter gespeicherter Stand, bereinigte Anzahl und der letzte API-Prüfstatus gezeigt. Die originale JSON-Datei bleibt lokal abrufbar. Ausschließlich auf Deinem eigenen Rechner.</p><div id="domain-list">Lade Dateninventar …</div>`,'Rohdaten verlassen den Rechner nicht')}
 ${panel('Lokaler Speicher & Dubletten',`<div id="storage-health">Speichernutzung wird ermittelt …</div><p class="muted tiny">Neue API-Daten werden nur einmal für die Auswertung gespeichert; das ungekürzte Original liegt komprimiert und lokal vor. Alte Bestände werden nicht ohne Deine Zustimmung verändert.</p>`,'Keine automatische Löschung')}<div class="grid2 grid-equal">${panel('Snapshot-Archiv',dataset.snapshots.length?dataset.snapshots.map(s=>`<div class="source"><div><b>${escapeHtml(niceLabel(s.label))}</b><br><span>${escapeHtml(s.source)} · ${escapeHtml(localeDate(s.imported_at))} · ${escapeHtml(s.reference_date?localeDate(s.reference_date,true):'ohne Stichtag')}</span></div><b>#${s.id}</b></div>`).join(''):empty('Noch keine Daten vorhanden.'),'Neue Daten überschreiben nichts')}</div></div>`;
}

// V2.8: Member Data Portability does not provide authoritative inbound
// discussion metrics. Record actual post analytics and user-confirmed context.
function reach(){
 return `<div class="notice"><strong>Was hier gemessen wird</strong> Der persönliche LinkedIn-ZIP-/API-Export dokumentiert überwiegend Ihre <em>eigenen</em> Kommentare, nicht zuverlässig Kommentare anderer unter Ihren Beiträgen. Unternehmensseitenwerte können separat eingetragen werden. <strong>Persönliche Bekanntschaft ist kein Indiz für künstliche Kommentare.</strong> Der Monitor wertet nur erfasste Beobachtungen aus, keine vermuteten Algorithmus-Strafen.</div>
 <div class="grid2 grid-equal">
 ${panel('LinkedIn-Einzelbeitrag als Excel importieren',`<p class="muted tiny">Die von LinkedIn exportierte Datei <b>SinglePostAnalytics_…xlsx</b> wird lokal eingelesen. Der Importzeitpunkt ist der neue Messzeitpunkt; die Excel-Datei selbst enthält nicht zwingend eine Erstellungszeit.</p>
 <label class="field-label" for="reach-xlsx-channel">Kanal</label><select id="reach-xlsx-channel"><option value="private">Privatprofil</option><option value="company">Unternehmensseite</option></select>
 <label class="field-label" for="reach-xlsx-observed">Messzeitpunkt (optional, sonst Importzeitpunkt)</label><input id="reach-xlsx-observed" type="datetime-local"/>
 <label class="field-label" for="reach-xlsx-title">Titel (optional)</label><input id="reach-xlsx-title" maxlength="240" placeholder="z. B. PPWR – Video zum EPR" />
 <label class="field-label" for="reach-xlsx-file">Excel-Datei auswählen</label><input id="reach-xlsx-file" type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" />
 <button class="btn primary" id="reach-import">Excel-Messstand importieren</button>`, 'Aus LinkedIn heruntergeladene Datei')}
 ${panel('Messstand manuell erfassen',`<p class="muted tiny">Für Unternehmensseiten, ältere Screenshots oder Werte ohne Excel-Export. Unbekannte Zahlen leer lassen – nicht 0 eintragen.</p>
 <form id="reach-form" class="reach-form">
  <div class="reach-fields"><label>Kanal<select name="channel"><option value="private">Privatprofil</option><option value="company">Unternehmensseite</option></select></label>
  <label>Veröffentlicht am (lokale Zeit)<input name="published_at" type="datetime-local"/></label></div>
  <label>Messzeitpunkt (optional, sonst jetzt)<input name="observed_local" type="datetime-local"/></label>
  <label>Beitragstitel<input name="title" maxlength="240" placeholder="CBAM – 50-Tonnen-Grenze"/></label>
  <label>Beitragslink (optional bei Titel + Datum)<input name="url" type="url" placeholder="https://www.linkedin.com/posts/…"/></label>
  <div class="reach-fields reach-numbers"><label>Impressionen *<input name="impressions" type="number" min="0" required/></label><label>Erreichte Personen<input name="reach" type="number" min="0"/></label>
  <label>Reaktionen<input name="reactions" type="number" min="0"/></label><label>Kommentare<input name="comments" type="number" min="0"/></label>
  <label>Reposts<input name="reposts" type="number" min="0"/></label><label>Gespeichert<input name="saves" type="number" min="0"/></label>
  <label>Klicks<input name="clicks" type="number" min="0"/></label><label>Videoaufrufe<input name="video_views" type="number" min="0"/></label>
  <label>Fachlich substanzielle Kommentare (manuell geprüft)<input name="substantive_comments" type="number" min="0"/></label>
  <label>Neue/seltene Diskussionsteilnehmer (manuell geprüft)<input name="new_participants" type="number" min="0"/></label>
  <label>Eigene Kommentare (falls bekannt)<input name="own_comments" type="number" min="0"/></label></div>
  <label>Beobachtungsnotiz (optional, keine Namen nötig)<textarea name="notes" rows="2" maxlength="500" placeholder="z. B. fachliche Rückfrage eines Herstellers zu CBAM"></textarea></label>
  <button class="btn primary" type="submit">Messstand lokal speichern</button>
 </form>`, 'Alle Angaben freiwillig außer Impressionen und Beitragskennung')}
 </div>
 ${panel('Privatprofil · Wochenexporte',`<p class="muted tiny">Neue Funktion: <b>AggregateAnalytics_…xlsx</b> einlesen. Überlappende Tage werden ersetzt, nicht addiert. Einzelbeitragszahlen aus dem Wochenexport werden bewusst nicht als zusätzliche Einzelmessungen übernommen.</p><label class="field-label" for="personal-week-file">LinkedIn-Wochenexport (XLSX)</label><input id="personal-week-file" type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"/><button class="btn primary" id="personal-week-import">Wochenstatistik importieren</button><div id="personal-week-result" class="muted tiny"></div><div id="personal-week-board">Noch keine Wochenstatistiken geladen.</div>`,'Separat von Unternehmensseitenwerten')}
 ${panel('Verlauf und Diskussionsqualität',`<div id="reach-list" class="reach-list">Messstände werden geladen …</div>`,'Erstverteilung ≠ Resonanz ≠ spätere Ausspielung')}
 <p class="muted tiny">Methodik: Soziale Interaktionen sind Ereignisse, nicht eindeutig verschiedene Menschen. Kommentare von Freunden sind weder automatisch wertvoller noch automatisch minderwertig. Externe Kommentare oder berufliche Relevanz lassen sich nur mit gesondert erhobenen Angaben einordnen. Angaben werden ausschließlich in Ihrer lokalen Datenbank gespeichert und nicht in den kuratierten Bericht übertragen.</p>`;
}
async function loadReach(){
 const target=$('#reach-list');if(!target||reachLoading)return;
 reachLoading=true;
 try{reachData=await request('/api/reach');if(target.isConnected){target.innerHTML=reachCards(reachData);wireReachDelete(target);wireReachContext(target)}}
 catch(e){if(target.isConnected)target.textContent=e.message;message(e.message,true)}
 finally{reachLoading=false}
}
function reachCards(data){
 if(!data?.posts?.length)return empty('Noch keine Einzelbeitrags-Messstände. Importieren Sie einen LinkedIn-Excel-Report oder erfassen Sie einen Messstand der Unternehmensseite.');
 const series=(data.series||[]).filter(group=>group.items.length>1);
 const seriesHtml=series.length?`<section class="card"><div class="card-head"><h2>Zusammenhängende Berichterstattung</h2><small>Manuell gekennzeichnet</small></div>
 ${series.map(group=>`<div class="series-group"><h3>${escapeHtml(group.name)} <span class="muted tiny">· ${escapeHtml(group.channel==='private'?'Privatprofil':'Unternehmensseite')}</span></h3>
 <div class="scroll-table"><table class="table"><thead><tr><th>Phase</th><th>Datum</th><th>Impressionen</th><th>Messalter</th><th>Beitrag</th></tr></thead><tbody>${group.items.map(item=>`<tr><td>${escapeHtml(({preview:'Vorschau',live:'Live',result:'Ergebnisbericht',deepdive:'Vertiefung',evergreen:'Grundlagen'}[item.stage]||'Unbekannt'))}</td><td>${escapeHtml(localeDate(item.published_at))}</td><td>${fmt(item.impressions)}</td><td>${item.age_hours!==null?escapeHtml(fmt(item.age_hours)+' Std.'):'–'}</td><td>${item.url?`<a href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer">Öffnen ↗</a>`:escapeHtml(item.title)}</td></tr>`).join('')}</tbody></table></div>
 </div>`).join('')}<p class="muted tiny">Unterschiedliche Messalter. Impressionen sind keine unterschiedlichen Personen; aus dem Vergleich folgt kein Algorithmus-Bonus.</p></section>`:'';
 return `<div class="reach-overview">${stat('Beobachtete Beiträge',data.total_posts)}${stat('Messstände',data.total_observations)}${stat('Mit Verlauf',data.posts.filter(p=>p.measurements>1).length)}</div>${seriesHtml}`+
 data.posts.map(p=>{const m=p.latest,old=p.previous,gain=old?m.impressions-old.impressions:null;
 const description=(m.substantive_comments!==null?`${fmt(m.substantive_comments)} fachlich geprüfte Kommentare. `:'Fachliche Kommentarqualität nicht erhoben. ')+
 (m.new_participants!==null?`${fmt(m.new_participants)} neue/seltene Beteiligte.`:'Neue Teilnehmer nicht erfasst.');
 return `<article class="reach-post"><div class="reach-post-header"><div><span class="reach-source">${p.channel==='company'?'Unternehmensseite':'Privatprofil'}</span><h3>${escapeHtml(m.title||'Beitrag ohne Titel')}</h3><p class="muted tiny">${escapeHtml(localeDate(m.observed_at))} · Messung ${fmt(p.measurements)} · ${p.age_hours!==null?'nach etwa '+fmt(p.age_hours)+' Stunden':'Alter nicht bestimmbar'}</p></div>${p.url?`<a href="${escapeHtml(p.url)}" target="_blank" rel="noopener noreferrer">Auf LinkedIn ansehen ↗</a>`:''}</div>
 <div class="reach-metrics">${stat('Impressionen',m.impressions,old?`seit letzter Messung ${gain>=0?'+':''}${fmt(gain)}`:'erster Stand')}${stat('Reaktionen',m.reactions)}${stat('Kommentare',m.comments)}${stat('Speicherungen',m.saves)}${stat('Erreichte Mitglieder',m.reach)}${stat('Klicks',m.clicks)}</div>
 <div class="reach-diagnosis reach-${escapeHtml(p.diagnosis.level)}"><strong>${escapeHtml(p.diagnosis.title)}</strong><p>${escapeHtml(p.diagnosis.detail)}</p><p class="muted tiny">${escapeHtml(description)}</p>${m.notes?`<p class="muted tiny">Anmerkung: ${escapeHtml(m.notes)}</p>`:''}</div>
 <div class="editorial-context"><div class="muted tiny"><strong>Redaktioneller Zweck</strong> · optional, manuell zuordnen. Eine gemeinsame Reihe ist keine A/B-Auswertung.</div>
 <div class="reach-fields"><label>Art des Beitrags<select class="reach-stage" data-key="${escapeHtml(p.post_key)}"><option value="unknown">Unbekannt / nicht festgelegt</option><option value="preview" ${p.editorial?.stage==='preview'?'selected':''}>Vorschau</option><option value="live" ${p.editorial?.stage==='live'?'selected':''}>Live-Beobachtung</option><option value="result" ${p.editorial?.stage==='result'?'selected':''}>Ergebnisbericht</option><option value="deepdive" ${p.editorial?.stage==='deepdive'?'selected':''}>Fachliche Vertiefung</option><option value="evergreen" ${p.editorial?.stage==='evergreen'?'selected':''}>Grundlagenbeitrag</option></select></label><label>Berichterstattungsfolge<input class="reach-series" data-key="${escapeHtml(p.post_key)}" maxlength="120" value="${escapeHtml(p.editorial?.series||'')}" placeholder="z. B. PPWR-Abstimmung 20.10.2026"/></label></div>
 <label class="field-label">Einordnung (optional)<input class="reach-context-note" data-key="${escapeHtml(p.post_key)}" maxlength="400" value="${escapeHtml(p.editorial?.context_note||'')}" placeholder="z. B. Vorab-Szenarien vor der Abstimmung"/></label>
 <button class="btn outline reach-context-save" data-key="${escapeHtml(p.post_key)}" data-channel="${escapeHtml(p.channel)}">Einordnung speichern</button></div>
 <details><summary>Messverlauf (${fmt(p.measurements)} Einträge)</summary><div class="scroll-table"><table class="table reach-table"><thead><tr><th>Erfasst am</th><th>Impressionen</th><th>Reaktionen</th><th>Kommentare</th><th>Quelle</th><th></th></tr></thead><tbody>${p.history.map(h=>`<tr><td>${escapeHtml(localeDate(h.observed_at))}</td><td>${fmt(h.impressions)}</td><td>${fmt(h.reactions)}</td><td>${fmt(h.comments)}</td><td>${escapeHtml(h.source==='linkedin_xlsx'?'LinkedIn-Excel':'manuell')}</td><td><button class="reach-delete" data-id="${h.id}" title="Einzelnen Messstand löschen">Löschen</button></td></tr>`).join('')}</tbody></table></div></details>
 </article>`}).join('');
}
function wireReachDelete(target){target.querySelectorAll('.reach-delete').forEach(button=>button.addEventListener('click',async()=>{
 if(!window.confirm('Diesen lokalen Messstand unwiderruflich löschen?'))return;
 try{await request('/api/reach/delete',{method:'POST',headers:{'X-Local-App':'1','Content-Type':'application/json'},body:JSON.stringify({id:Number(button.dataset.id)})});message('Messstand gelöscht.');await loadReach()}
 catch(e){message(e.message,true)}
 }));}
function wireReachContext(target){
 target.querySelectorAll('.reach-context-save').forEach(button=>button.addEventListener('click',async()=>{
  const card=button.closest('.reach-post');
  const body={channel:button.dataset.channel,post_key:button.dataset.key,
   stage:card.querySelector('.reach-stage').value,series:card.querySelector('.reach-series').value,
   context_note:card.querySelector('.reach-context-note').value};
  button.disabled=true;
  try{await request('/api/reach/context',{method:'POST',headers:{'X-Local-App':'1','Content-Type':'application/json'},body:JSON.stringify(body)});
      message('Redaktionelle Einordnung lokal gespeichert.');await loadReach()}
  catch(e){message(e.message,true)}finally{button.disabled=false}
 }));
}
function personalWeekCards(data){
 if(!data.import_count)return empty('Noch kein persönlicher AggregateAnalytics-Wochenexport importiert.');
 const days=data.daily||[],last=days.slice(-21),max=Math.max(1,...last.map(d=>Number(d.impressions)||0));
 const end=data.latest_summary||{};
 const preview=(data.recent_posts||[]).slice(0,8);
 const bars=last.map(d=>`<div class="company-bar"><span class="company-bar-value">${escapeHtml(fmt(d.impressions))}</span><div class="company-bar-core" style="height:${Math.max(4,Math.round((d.impressions||0)/max*100))}%" title="${escapeHtml(d.date+' · '+fmt(d.impressions)+' Impressionen')}"></div><span class="company-bar-day">${escapeHtml(d.date.slice(5))}</span></div>`).join('');
 return `<div class="stats">${stat('Dateiimporte',data.import_count)}${stat('Unterschiedliche Tage',days.length)}${stat('Follower (letzter Export)',end.total_followers)}${stat('Impressionen (letzter Export)',end.impressions)}</div>
 <p class="muted tiny">Letzter Berichtszeitraum: ${escapeHtml(localeDate(end.period_start,true))} bis ${escapeHtml(localeDate(end.period_end,true))}. Impressionen der verschiedenen Tage sind summierbar, erreichte Mitglieder über mehrere Tage <b>nicht</b>.</p>
 <div class="company-series"><h3>Impressionen nach Kalendertag</h3><div class="company-bars">${bars}</div></div>
 <details><summary>Followerentwicklung und jüngste Beiträge</summary><div class="scroll-table"><table class="table"><thead><tr><th>Datum</th><th>Neue Follower</th></tr></thead><tbody>${(data.follower_daily||[]).slice(-21).map(d=>`<tr><td>${escapeHtml(localeDate(d.date,true))}</td><td>${fmt(d.new_followers)}</td></tr>`).join('')}</tbody></table></div>
 <h3>Jüngste Beiträge · Aus allen importierten Wochenexporten</h3><div class="scroll-table"><table class="table"><thead><tr><th>Veröffentlicht</th><th>Format</th><th>Impressionen</th><th>Erreichte Mitglieder</th><th>Link</th></tr></thead><tbody>${preview.map(p=>`<tr><td>${escapeHtml(localeDate(p.published_date,true))}</td><td>${escapeHtml(p.format)}</td><td>${fmt(p.impressions)}</td><td>${fmt(p.reach)}</td><td><a href="${escapeHtml(p.url)}" target="_blank" rel="noopener noreferrer">Beitrag ↗</a></td></tr>`).join('')}</tbody></table></div></details>
 <details><summary>Importierte Dateien (${fmt(data.import_count)})</summary>${data.imports.map(i=>`<div class="source"><div><b>${escapeHtml(i.filename)}</b><br><span>${escapeHtml(i.period_start+' bis '+i.period_end)} · ${escapeHtml(localeDate(i.imported_at))}</span>${i.warnings.length?`<br><span>${escapeHtml(i.warnings.join('; '))}</span>`:''}</div></div>`).join('')}</details>
 <p class="muted tiny">${escapeHtml(data.method)} ${escapeHtml(data.limitations.join(' '))}</p>`;
}
async function loadPersonalWeek(){
 const node=$('#personal-week-board');if(!node||personalAggregateLoading)return;personalAggregateLoading=true;
 try{personalAggregateData=await request('/api/personal-aggregate');if(node.isConnected)node.innerHTML=personalWeekCards(personalAggregateData)}
 catch(e){if(node.isConnected)node.textContent=e.message;message(e.message,true)}finally{personalAggregateLoading=false}
}
async function importPersonalWeek(){
 const file=$('#personal-week-file')?.files?.[0];if(!file){message('Bitte Wochenexport auswählen.',true);return}
 if(!file.name.toLowerCase().endsWith('.xlsx')){message('Bitte XLSX auswählen.',true);return}
 const button=$('#personal-week-import');button.disabled=true;
 try{const data=await request('/api/personal-aggregate/import',{method:'POST',headers:{'X-Local-App':'1','X-Filename':encodeURIComponent(file.name)},body:file});
    message(data.duplicate_file?'Datei bereits importiert – keine doppelten Tageswerte.':`Wochenexport importiert: ${data.days} Tageswerte.`);
    $('#personal-week-file').value='';await loadPersonalWeek()}
 catch(e){message(e.message,true)}finally{button.disabled=false}
}
async function importReachXlsx(){
 const file=$('#reach-xlsx-file')?.files?.[0];if(!file){message('Bitte zuerst eine Excel-Datei auswählen.',true);return}
 if(!file.name.toLowerCase().endsWith('.xlsx')){message('Bitte eine XLSX-Datei auswählen.',true);return}
 const btn=$('#reach-import');btn.disabled=true;
 try{
  const response=await request('/api/reach/import',{method:'POST',headers:{'X-Local-App':'1','X-Channel':$('#reach-xlsx-channel').value,'X-Post-Title':$('#reach-xlsx-title').value,...($('#reach-xlsx-observed').value?{'X-Observed-At':new Date($('#reach-xlsx-observed').value).toISOString()}: {})},body:file});
  message('LinkedIn-Messstand lokal gespeichert – '+fmt(response.record.impressions)+' Impressionen.');
  $('#reach-xlsx-file').value='';$('#reach-xlsx-observed').value='';await loadReach();
 }catch(e){message(e.message,true)}finally{btn.disabled=false}
}
async function submitReachForm(event){
 event.preventDefault();const form=event.currentTarget;const data=new FormData(form),body={};
 for(const [k,v] of data.entries())body[k]=String(v).trim();
 if(body.observed_local){body.observed_at=new Date(body.observed_local).toISOString()}
 delete body.observed_local;
 // Publication date is interpreted as German local time when age is displayed.
 const btn=form.querySelector('button[type="submit"]');btn.disabled=true;
 try{await request('/api/reach/observe',{method:'POST',headers:{'X-Local-App':'1','Content-Type':'application/json'},body:JSON.stringify(body)});message('Messstand gespeichert.');
  const url=body.url,title=body.title,date=body.published_at,channel=body.channel;
  form.reset();form.elements.channel.value=channel;form.elements.url.value=url;form.elements.title.value=title;form.elements.published_at.value=date;await loadReach();
 }catch(e){message(e.message,true)}finally{btn.disabled=false}
}
function render(){if(!dataset)return;const [name,desc]=pages[tab];$('#page-title').textContent=name;$('#subtitle').textContent=desc;
 $('#view').innerHTML=({overview,scores,profile,content,extended,reach,company,advice,sources}[tab])();
 document.querySelectorAll('.choose-topic,.go-score').forEach(b=>b.addEventListener('click',()=>{chosenTopic=b.dataset.topic;tab='scores';setNav();render()}));
 $('#cred-topic')?.addEventListener('change',e=>{chosenAdviceTopic=e.target.value;render()});
 $('#open-advice')?.addEventListener('click',()=>{tab='advice';setNav();render()});
 $('#extended-load')?.addEventListener('click',loadExtended);
 $('#extended-reload')?.addEventListener('click',loadExtended);
 $('#extended-filter')?.addEventListener('input',e=>{extendedFilter=e.target.value;const cur=e.target.selectionStart;render();const target=$('#extended-filter');if(target){target.focus();target.setSelectionRange(cur,cur)}});
 $('#import-btn')?.addEventListener('click',importZip);
 $('#reach-import')?.addEventListener('click',importReachXlsx);
 $('#personal-week-import')?.addEventListener('click',importPersonalWeek);
 $('#company-import')?.addEventListener('click',importCompanyFile);
 $('#storage-optimize')?.addEventListener('click',optimizeStorage);
 $('#reach-form')?.addEventListener('submit',submitReachForm);
 $('#sync-btn')?.addEventListener('click',()=>doSync(false));
 $('#probe-btn')?.addEventListener('click',()=>doSync(true));
 $('#retry-errors-btn')?.addEventListener('click',retryFailedDomains);

 if(tab==='sources'){renderSourceAudit();renderDomainList();renderDiagnostics();renderStorageHealth();}
 if(tab==='reach'){loadReach();loadPersonalWeek();}
 if(tab==='company'){loadCompany();}
 $('#report-type')?.addEventListener('change',e=>{const ext=e.target.value==='extended';const link=$('#report-download');if(link){link.href=ext?'/api/extended-report?full=1&download=1':'/api/export';link.download=ext?'linkedin-extended-report.json':'linkedin-kuratierter-bericht.json'}});
 $('#report-btn')?.addEventListener('click',async()=>{
   if($('#report-type')?.value==='extended'){
      // Extended exports are intentionally downloaded to the browser, not to
      // the share-safe reports/current.json used by other workflows.
      const anchor=$('#report-download');if(anchor)anchor.click();
      return;
   }
   try{const r=await request('/api/report',{method:'POST',headers:{'X-Local-App':'1','Content-Type':'application/json'},body:'{}'});message('Bericht lokal gespeichert: '+r.path)}catch(e){message(e.message,true)}
 });
}
async function renderSourceAudit(){
 const target=$('#source-audit');if(!target)return;
 try{
  const selected=$('#snapshot')?.value||'';
  const data=await request('/api/source-audit'+(selected?'?snapshot='+encodeURIComponent(selected):''));
  if(!target.isConnected)return;
  const sum=data.summary||{},score=data.scores||{},problems=data.api_errors||[];
  const row=(d)=>{
    const a=d.api,z=d.zip,ident=d.strict_overlap;
    const note=d.note?`<div class="muted tiny">${escapeHtml(d.note)}</div>`:'';
    let sub='';
    if(d.domain==='ENDORSEMENTS')sub=`<div class="muted tiny">API: ${fmt(a?.received)} erhalten / ${fmt(a?.given)} vergeben. ZIP (erhalten): ${fmt(z?.received)}.</div>`;
    return `<tr><td><strong>${escapeHtml(d.domain)}</strong>${note}${sub}</td><td>${a?fmt(a.unique):'–'}${a?`<div class="muted tiny">#${fmt(a.snapshot_id)}</div>`:''}</td><td>${z?fmt(z.unique):'–'}${z?`<div class="muted tiny">#${fmt(z.snapshot_id)}</div>`:''}</td><td>${d.status==='same'?'Gleich':d.status==='different'?'Unterschiedlich':d.status==='only_api'?'Nur API':'Nur ZIP'}${ident!==undefined?`<div class="muted tiny">${fmt(ident)} exakt gemeinsam; ${fmt(d.api_only)} nur API; ${fmt(d.zip_only)} nur ZIP</div>`:''}</td></tr>`;
  };
  const domains=(data.domains||[]);
  const focus=['ENDORSEMENTS','POSITIONS','EDUCATION','SKILLS','PROFILE','ALL_COMMENTS','ALL_LIKES','CONNECTIONS','INBOX','MEMBER_SHARE_INFO','INFERENCE_TAKEOUT'];
  const priority=domains.filter(d=>focus.includes(d.domain));
  const rest=domains.filter(d=>!focus.includes(d.domain));
  const table=items=>`<div class="scroll-table"><table class="table inventory-table"><thead><tr><th>Datenbereich</th><th>API</th><th>ZIP</th><th>Strikter Vergleich</th></tr></thead><tbody>${items.map(row).join('')}</tbody></table></div>`;
  target.innerHTML=`<div class="stats audit-stats">${stat('Abgeglichene Bereiche',sum.total)}${stat('Beide Quellen',sum.in_both)}${stat('Exakt gleich',sum.matching)}${stat('Mit Unterschieden',sum.different)}</div>
   <div class="notice"><strong>Letzte Score-Messung ${escapeHtml(score.latest_measured_at||'unbekannt')}</strong> · ${fmt(score.unique_points_on_date||0)} unterschiedliche Werte dieses Datums. Letzter Import mit Scores ${escapeHtml(localeDate(score.last_imported_at||''))} (${escapeHtml(score.last_import_source||'–')}). Diese Zeitpunkte sind nicht austauschbar.<p class="muted tiny">Die DMA-API lieferte bislang keine historischen Credibility-Messwerte. „Gleich“ bedeutet exakte Datensatzidentität, nicht automatisch identischer Datenumfang zu allen Zeiten.</p></div>
   ${table(priority)}<details><summary>Weitere ${fmt(rest.length)} Bereiche vergleichen</summary>${table(rest)}</details>
   ${problems.length?`<details><summary>${fmt(problems.length)} Fehler beim letzten API-Abruf – Ursachen ansehen</summary>${problems.map(x=>`<div class="source"><div><b>${escapeHtml(x.domain)}</b><p class="muted tiny">${escapeHtml(x.state)}${x.http_status?' · HTTP '+fmt(x.http_status):''} · ${escapeHtml(x.reason||'Keine Fehlermeldung gespeichert')}</p></div></div>`).join('')}</details>`:''}
   <p class="muted tiny">${escapeHtml(data.method||'')}</p>`;
 }catch(e){if(target.isConnected)target.textContent='Quellenabgleich derzeit nicht verfügbar: '+e.message}
}

async function renderDomainList(){
 const target=$('#domain-list');if(!target)return;
 try{
  const selected=$('#snapshot')?.value||'';const info=await request('/api/domains'+(selected?'?snapshot='+encodeURIComponent(selected):''));
  if(!target.isConnected)return;
  const items=info.domains||[];
  if(!items.length){target.innerHTML=empty('Noch keine Daten importiert.');return}
  const checked=(dataset?.latest_api_sync?.status_by_domain||{});
  const checkedAt=dataset?.latest_api_sync?.executed_at;
  const trs=items.map(d=>{
    const detail=checked[d.domain];
    const statusLabels={ready:'Erfolgreich abgerufen',not_yet_available_or_empty:'LinkedIn meldet leer / noch nicht bereit',empty_response:'API-Antwort leer',http_error:'HTTP-Fehler',error:'Abruf fehlgeschlagen'};
    const apiState=!checkedAt?'Noch kein API-Lauf':detail?`Letzte API-Prüfung ${localeDate(checkedAt)} · ${statusLabels[detail.state]||escapeHtml(detail.state)}${detail.raw_rows!==undefined?' · '+fmt(detail.raw_rows)+' Rohzeilen':''}`:'Beim letzten API-Lauf nicht angefordert';
    const original=d.source==='zip'?`ZIP-Datei: ${d.label||'unbekannt'}`:d.label||'LinkedIn API';
    const dup=(d.exact_duplicates||0)>0?`<span class="dedup-count">−${fmt(d.exact_duplicates)} Dubletten</span>`:'keine exakten Dubletten';
    return `<tr><td><strong>${escapeHtml(d.domain)}</strong><div class="tiny muted">${escapeHtml(original)}</div></td><td><b>${escapeHtml(sourceName(d.source))}</b><div class="tiny muted">Snapshot #${escapeHtml(d.snapshot_id)}</div></td><td>${escapeHtml(localeDate(d.imported_at))}<div class="tiny muted">${d.reference_date?'Referenz: '+escapeHtml(localeDate(d.reference_date,true)):''}</div></td><td>${fmt(d.effective_records)}<div class="tiny muted">${fmt(d.raw_records)} Rohzeilen · ${dup}${d.raw_archived?' · Original komprimiert':''}</div></td><td><div class="tiny muted">${escapeHtml(apiState)}</div><a href="/api/raw?domain=${encodeURIComponent(d.domain)}${selected?'&snapshot='+encodeURIComponent(selected):''}" download="linkedin-${escapeHtml(d.domain.toLowerCase())}.json">Rohdaten-JSON ↓</a></td></tr>`;
  }).join('');
  target.innerHTML=`<p class="muted tiny">Der Datenstand bedeutet <strong>zuletzt erfolgreich gespeichert</strong>. Ein späterer leerer oder fehlgeschlagener API-Abruf setzt diesen Stand nicht zurück. Zeitangaben in deutscher Ortszeit (MEZ/MESZ). Rohdaten bleiben unverändert.</p><div class="scroll-table"><table class="table inventory-table"><thead><tr><th>Datenbereich / Datei</th><th>Quelle</th><th>Gespeichert am</th><th>Bereinigt</th><th>API-Prüfung / Rohdaten</th></tr></thead><tbody>${trs}</tbody></table></div>`;
 }catch(e){if(target.isConnected)target.textContent='Dateninventar derzeit nicht lesbar: '+e.message}
}
async function importZip(){const inp=$('#filezip'),file=inp.files[0];if(!file){message('Bitte ZIP-Datei auswählen.',true);return}if(file.size>250*1024*1024){message('Datei zu groß.',true);return}
 try{message('ZIP-Import gestartet …');const result=await request('/api/import',{method:'POST',headers:{'X-Local-App':'1','X-Import-Label':file.name},body:file});message(`Snapshot #${result.snapshot_id} importiert. ${Object.keys(result.domains).length} Bereiche, ${result.score_points} Score-Messpunkte.`);$('#snapshot').value='';await reload()}catch(e){message(e.message,true)}}
async function renderDiagnostics(){
 const target=$('#sync-diagnostics'); if(!target)return;
 try{
  const data=await request('/api/diagnostics'); if(!target.isConnected)return;
  const last=data.last_sync,source=data.inventory_by_source||{}, api=source.api||{},zip=source.zip||{};
  if(!last){target.innerHTML=`<strong>Noch kein protokollierter API-Abruf.</strong><p>Die vorhandenen Daten stammen aus ZIP-Dateien oder aus dem mitgelieferten Archiv. Starte einen API-Schnelltest.</p>`;return}
  const statuses=last.domains||{},summary=last.summary||{},auth=last.authorization||{};
  const state=auth.state==='active'?`Aktiv${auth.regulated_at_ms?' seit '+localeDate(new Date(auth.regulated_at_ms).toISOString()):''}`:
    `Nicht bestätigt (${auth.state||'unbekannt'}${auth.http_status?', HTTP '+auth.http_status:''})`;
  const priority=['PROFILE','SKILLS','POSITIONS','MEMBER_SHARE_INFO','ALL_COMMENTS','ALL_LIKES','INFERENCE_TAKEOUT','INBOX'];
  const ordered=[...new Set([...priority,...Object.keys(statuses)])].filter(x=>statuses[x]);
  let rows=ordered.map(key=>{const x=statuses[key],n=x.rows||0;const stat=x.state==='ready'?'DATEN GELADEN':x.state==='not_yet_available_or_empty'?'LEER / IN VERARBEITUNG':x.state==='http_error'?'HTTP-FEHLER':x.state==='empty_response'?'LEER':'FEHLER';
   return `<div class="source"><div><b>${escapeHtml(key)}</b><br><span>${escapeHtml(stat)} · ${fmt(n)} per API · ${fmt(zip[key]||0)} aus ZIP</span><br><small>${escapeHtml(short(x.message||''))}${x.warning?' · '+escapeHtml(short(x.warning)):''}${x.error_category?' · '+escapeHtml(x.error_category):''}${x.page_requests!==undefined?' · '+fmt(x.page_requests)+' Seitenabrufe':''}</small></div></div>`}).join('');
  target.innerHTML=`<b>Letzter API-Lauf: ${escapeHtml(localeDate(last.executed_at))}</b><p>Autorisierung: ${escapeHtml(state)}<br>Von ${fmt(last.requested)} abgefragten Bereichen: ${fmt(summary.ready||0)} mit Daten, ${fmt(summary.not_yet_available_or_empty||0)} leer/noch in Verarbeitung, ${fmt(summary.errors||0)} Fehler.</p><p><strong>Quelle beachten:</strong> ZIP-Bestände sind keine API-Erfolge. Der erste Snapshot kann bei LinkedIn zeitversetzt erscheinen.</p><p class="tiny muted">Die gespeicherten Datenstände je Bereich siehst Du darunter in der Tabelle. Eine API-Prüfung ist nicht automatisch ein neuer Datenstand.</p><details><summary>Einzelstatus aller abgefragten Bereiche anzeigen (${fmt(ordered.length)})</summary>${rows}</details>`;
 }catch(e){if(target.isConnected)target.textContent='API-Diagnose konnte nicht gelesen werden: '+e.message}
}
async function retryFailedDomains(){
 const btn=$('#retry-errors-btn');if(btn)btn.disabled=true;
 try{
  const plan=await request('/api/api-retry-plan');
  if(!plan.count){message('Keine zuletzt fehlgeschlagenen API-Bereiche bekannt. Kein Abruf nötig.');return;}
  message(`Prüfe gezielt ${plan.count} fehlerhafte API-Bereiche erneut (ohne Changelog) …`);
  const x=await request('/api/sync',{method:'POST',headers:{'X-Local-App':'1','Content-Type':'application/json'},body:JSON.stringify({domains:plan.domains,changelog:false})});
  const values=Object.values(x.domains||{}),ok=values.filter(y=>y.state==='ready').length;
  const failed=values.filter(y=>y.state==='error'||y.state==='http_error').length;
  message(`Gezielte API-Prüfung abgeschlossen: ${ok} Bereiche mit Daten, ${failed} weiter fehlerhaft, ${values.length-ok-failed} leer. Alte Daten bleiben bei Fehlern erhalten.`,failed>0);
  await reload();if(tab==='sources'){await renderDiagnostics();await renderDomainList();await renderSourceAudit();}
 }catch(e){message(e.message,true)}finally{if(btn)btn.disabled=false}
}
async function doSync(quick=false){
 const btn=quick?$('#probe-btn'):$('#sync-btn');if(btn)btn.disabled=true;
 try{
  message(quick?'API-Schnelltest der vier wichtigsten Bereiche gestartet …':'Vollständiger API-Abruf gestartet …');
  const payload={changelog:!quick};
  if(quick)payload.domains=['PROFILE','MEMBER_SHARE_INFO','ALL_COMMENTS','INFERENCE_TAKEOUT'];
  const x=await request('/api/sync',{method:'POST',headers:{'X-Local-App':'1','Content-Type':'application/json'},body:JSON.stringify(payload)});
  const values=Object.values(x.domains),ok=values.filter(y=>y.rows>0).length;
  const failures=values.filter(y=>y.state==='http_error'||y.state==='error').length;
  if(!ok)message(`API lieferte für keinen der ${values.length} angefragten Bereiche Daten. ${failures} Fehler. Details unter API-Diagnose.`,true);
  else message(`API hat für ${ok} von ${values.length} Bereichen Daten geliefert. ${failures} Fehler. Details unter API-Diagnose.`);
  await reload(); if(tab==='sources'){await renderDiagnostics();await renderDomainList();}
 }catch(e){message(e.message,true)}finally{if(btn)btn.disabled=false}
}
function setNav(){document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab))}
document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>{tab=b.dataset.tab;setNav();render()}));
renderVersion();$('#refresh').addEventListener('click',reload);$('#snapshot').addEventListener('change',reload);reload();


// V2.9: Official LinkedIn Page exports are local uploads and never part of the personal DMA API.
const COMPANY_LABELS={organic_unique_impressions:'Individuelle organische Impressionen',organic_impressions:'Organische Impressionen',sponsored_impressions:'Bezahlte Impressionen',organic_clicks:'Organische Klicks',sponsored_clicks:'Bezahlte Klicks',impressions:'Impressionen',unique_impressions:'Eindeutige Impressionen',reach:'Erreichte Mitglieder',clicks:'Klicks',click_through_rate:'Klickrate',reactions:'Reaktionen',organic_reactions:'Organische Reaktionen',sponsored_reactions:'Gesponserte Reaktionen',comments:'Kommentare',organic_comments:'Organische Kommentare',sponsored_comments:'Gesponserte Kommentare',reposts:'Geteilte Beiträge',organic_reposts:'Organisch geteilte Beiträge',sponsored_reposts:'Gesponsert geteilte Beiträge',engagement_rate:'Interaktionsrate',organic_engagement_rate:'Organische Interaktionsrate',sponsored_engagement_rate:'Gesponserte Interaktionsrate',post_views:'Beitragsaufrufe',offsite_views:'Externe Aufrufe',new_followers:'Neue Follower',total_followers:'Follower gesamt',organic_followers:'Organische Follower',sponsored_followers:'Gesponserte Follower',visitors:'Besucher',unique_visitors:'Eindeutige Besucher',page_views:'Seitenaufrufe',custom_button_clicks:'Button-Klicks'};
const companyMetricLabel=k=>COMPANY_LABELS[k]||k;
function company(){
 return `<div class="notice"><strong>Die Unternehmensseite ist ein eigenständiger Datenkanal.</strong> Ihre Statistik kommt aus manuell exportierten LinkedIn-Seitenanalysen und wird nie mit Privatprofil- oder DMA-Daten zusammengerechnet. Schon importierte Daten bleiben lokal erhalten. Doppelt geladene Dateien werden erkannt; überlappende Zeiträume werden pro Kennzahl zusammengeführt, nicht addiert.</div>
 <div class="grid2 grid-equal">${panel('Seitenanalyse importieren',`<p class="muted tiny">Unternehmensseite auf LinkedIn öffnen → Analytics / Analysen → Content, Follower oder Besucher → Excel bzw. CSV exportieren. Die unveränderte XLS-/XLSX-/CSV-Datei lokal auswählen (max. 15 MB). Mehrere Exporte können nacheinander importiert werden.</p>
 <label for="company-file" class="field-label">Seitenstatistik als XLS, XLSX oder CSV</label><input id="company-file" type="file" accept=".xls,.xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv"/>
 <button class="btn primary" id="company-import">Unternehmensdaten importieren</button><div id="company-import-message" class="tiny muted"></div>`,'Ohne Unternehmensseiten-API')}
 ${panel('Methodische Trennung',`<p class="muted">Die Daten werden nach Kalenderdatum und Kennzahl zusammengeführt. Mehrfach exportierte Tage und Beiträge werden nicht doppelt gezählt. Unbekannte oder nicht unterstützte Blätter erhalten einen konkreten Importhinweis.</p><p class="muted tiny">Für einzelne Diskussionen kannst Du weiterhin „Reichweite & Diskussion“ nutzen. Dort lassen sich auch Screenshots und eigenständige Messstände des Firmenprofils erfassen.</p>`,'Keine Vermutungen über Reichweitenstrafen')}</div>
 ${panel('Unternehmensseite · Datenentwicklung',`<div id="company-board">Analysedaten werden geladen …</div>`,'Nur wirklich vorhandene Kennzahlen')}`;
}
function metricDisplay(key,val){return (['engagement_rate','organic_engagement_rate','sponsored_engagement_rate','click_through_rate'].includes(key))?fmt(Number(val)*100)+' %':fmt(val)}
function companyCards(data){
 if(!data?.import_count)return empty('Noch keine Unternehmensseiten-Statistik importiert. Bitte den Originalexport aus LinkedIn Analytics hochladen.');
 const stats=data.summary||{},priority=['total_followers','new_followers','impressions','clicks','comments','reactions','unique_visitors','visitors','page_views','engagement_rate'];
 const metrics=priority.filter(k=>stats[k]!==undefined).map(k=>{
   const x=stats[k];const foot=x.method==='last'?'Letzter Messwert · '+localeDate(x.date,true):'Summe über max. 30 verfügbare Tage · '+fmt(x.observed_days||0)+' Tage';
   return `<div class="stat"><div class="kicker">${escapeHtml(companyMetricLabel(k))}</div><div class="num">${escapeHtml(metricDisplay(k,x.value))}</div><div class="foot">${escapeHtml(foot)}</div></div>`;
 }).join('');
 const keys=['impressions','new_followers','unique_visitors','page_views'].filter(k=>data.daily.some(d=>d[k]!==undefined));
 const trend=keys.length?keys.map(k=>{
   const dates=data.daily.filter(x=>x[k]!==undefined).slice(-20);const largest=Math.max(...dates.map(x=>Number(x[k])),1);
   return `<div class="company-series"><h3>${escapeHtml(companyMetricLabel(k))}</h3><div class="company-bars">${dates.map(v=>`<div class="company-bar"><span class="company-bar-value">${escapeHtml(fmt(v[k]))}</span><div class="company-bar-core" style="height:${Math.max(4,Math.round(v[k]/largest*100))}%" title="${escapeHtml(localeDate(v.date,true)+' · '+fmt(v[k]))}"></div><span class="company-bar-day">${escapeHtml(v.date.slice(5))}</span></div>`).join('')}</div><p class="muted tiny">Letzte ${fmt(dates.length)} tatsächlich vorhandene Tageswerte; fehlende Tage bleiben unbekannt.</p></div>`;
 }).join(''):empty('Bisher keine erkannten Tagesreihen für diese Kategorien.');
 const posts=(data.posts||[]).slice(0,30).map(p=>`<tr><td>${escapeHtml(localeDate(p.date,true))}</td><td>${/^https:\/\/(www\.)?linkedin\.com\//i.test(p.post)?`<a href="${escapeHtml(p.post)}" target="_blank" rel="noopener noreferrer">${escapeHtml(short(p.title||p.post))} ↗</a>`:escapeHtml(short(p.title||p.post))}</td><td>${fmt(p.metrics.impressions)}</td><td>${fmt(p.metrics.clicks)}</td><td>${fmt(p.metrics.comments)}</td><td>${fmt(p.metrics.reactions)}</td></tr>`).join('');
 const imports=data.imports.map(x=>`<div class="source"><div><b>${escapeHtml(x.filename)}</b><br><span>Importiert ${escapeHtml(localeDate(x.imported_at))}</span>${x.warnings.length?`<details><summary>${fmt(x.warnings.length)} Hinweise zu nicht gelesenen Tabellen</summary>${x.warnings.map(w=>`<p class="muted tiny">${escapeHtml(w)}</p>`).join('')}</details>`:''}</div><small>#${x.id}</small></div>`).join('');
 return `<div class="company-head"><div class="stats">${stat('Excel-/CSV-Importe',data.import_count)}${stat('Erfasste Tage',data.daily.length)}${stat('Erfasste Beiträge',data.post_total||0)}</div><p class="muted tiny">Letzter erfasster Tag: ${escapeHtml(localeDate(data.last_day,true))}. Keine automatische Aktualisierung, bis neue Dateien importiert werden.</p></div>
 ${metrics?`<div class="company-kpis">${metrics}</div>`:empty('Erkannte Werte wurden nicht für die Übersicht klassifiziert.')}
 <div class="company-charts">${trend}</div>
 ${posts?`<h3>Beitragszahlen aus den Seitenexporten</h3><div class="scroll-table"><table class="table"><thead><tr><th>Veröffentlichung</th><th>Beitragskennung</th><th>Impressionen</th><th>Klicks</th><th>Kommentare</th><th>Reaktionen</th></tr></thead><tbody>${posts}</tbody></table></div>`:''}
 <details class="company-imports"><summary>Verwendete Dateien und nicht erkannte Tabellen (${fmt(data.import_count)})</summary>${imports}</details><p class="muted tiny">${escapeHtml(data.method)}</p>`;
}
async function loadCompany(){
 const node=$('#company-board');if(!node||companyLoading)return;companyLoading=true;
 try{companyData=await request('/api/company');if(node.isConnected)node.innerHTML=companyCards(companyData)}
 catch(e){if(node.isConnected)node.textContent='Seitenstatistik nicht lesbar: '+e.message}
 finally{companyLoading=false}
}
async function importCompanyFile(){
 const file=$('#company-file')?.files?.[0];if(!file){message('Bitte eine LinkedIn-Seitenanalyse als XLS, XLSX oder CSV auswählen.',true);return}
 if(file.size>15*1024*1024){message('Datei größer als 15 MB.',true);return}
 const btn=$('#company-import');btn.disabled=true;
 try{const info=await request('/api/company/import',{method:'POST',headers:{'X-Local-App':'1','X-Filename':encodeURIComponent(file.name)},body:file});
  if(info.duplicate_file)message('Diese Datei ist bereits importiert; keine doppelten Daten gespeichert.');
  else message(`${fmt(info.imported_rows)} Zeilen aus ${fmt(info.sheets.length)} erkannten Tabellen importiert. ${fmt(info.warnings.length)} Hinweise.`);
  const tag=$('#company-import-message');if(tag)tag.textContent=info.warnings?.join(' · ')||'';
  $('#company-file').value='';await loadCompany();
 }catch(e){message('Seitenanalyse nicht importiert: '+e.message,true)}finally{btn.disabled=false}
}
async function renderStorageHealth(){
 const node=$('#storage-health');if(!node)return;
 try{const info=await request('/api/storage');if(!node.isConnected)return;
  const kb=n=>fmt(Math.round(n/1024))+' KB';
  node.innerHTML=`<div class="stats">${stat('Datenbank',kb(info.db_bytes))}${stat('Komprimierte Originale',kb(info.archived_raw_bytes))}${stat('Originalarchive',info.files_on_disk)}</div><p class="muted tiny">${fmt(info.archived_exact_duplicates)} exakte Kopien sind in den komprimierten Roharchiven nachprüfbar, werden aber nicht erneut in der auswertbaren Arbeitskopie gespeichert. Alte Datenbestände bleiben bis zu Deiner ausdrücklichen Optimierung unverändert.</p><button class="btn outline" id="storage-optimize">Ältere API-Dubletten nach Backup archivieren</button><div id="storage-optimize-info" class="muted tiny"></div>`;
  $('#storage-optimize')?.addEventListener('click',optimizeStorage);
 }catch(e){if(node.isConnected)node.textContent='Speichernutzung nicht lesbar: '+e.message}
}

async function optimizeStorage(){
 if(!confirm('Vor der Optimierung wird eine vollständige SQLite-Sicherung auf Deinem Rechner erstellt. Historische API-Rohdaten werden danach komprimiert archiviert, ihre auswertbaren Kopien bereinigt. Fortfahren?'))return;
 const btn=$('#storage-optimize');if(btn)btn.disabled=true;
 const info=$('#storage-optimize-info');if(info)info.textContent='Lokale Datensicherung und Optimierung laufen … Bitte warten.';
 try{
  const data=await request('/api/storage/compact',{method:'POST',headers:{'X-Local-App':'1','Content-Type':'application/json'},body:'{"confirm":true}'});
  message(`${fmt(data.compacted)} API-Datensätze optimiert; ${fmt(data.duplicates_archived)} Dubletten nur noch im Roharchiv.`);
  if(info)info.textContent=data.backup?'Sicherung auf diesem Rechner: '+data.backup:'Keine älteren API-Daten zum Optimieren.';
  await renderStorageHealth();await renderDomainList();
 }catch(e){message('Speicheroptimierung fehlgeschlagen: '+e.message,true);if(info)info.textContent='Die bestehenden Daten wurden nicht absichtlich gelöscht.'}
 finally{if(btn)btn.disabled=false}
}
