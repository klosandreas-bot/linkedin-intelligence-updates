"""V2.8: offline, data-quality and privacy tests."""
from __future__ import annotations
import io, json, sqlite3, unittest, zipfile
from analytics import reach_monitor,save_post_observation,delete_post_observation,_post_identity
from ingest import parse_linkedin_post_analytics_xlsx


def tables():
    cx=sqlite3.connect(':memory:')
    cx.row_factory=sqlite3.Row
    cx.executescript('''CREATE TABLE post_observations (
       id INTEGER PRIMARY KEY AUTOINCREMENT,channel TEXT,post_key TEXT,post_url TEXT,
       title TEXT,published_at TEXT,observed_at TEXT,source TEXT,impressions INTEGER,
       reach INTEGER,reactions INTEGER,comments INTEGER,reposts INTEGER,saves INTEGER,
       clicks INTEGER,video_views INTEGER,substantive_comments INTEGER,
       new_participants INTEGER,own_comments INTEGER,avg_watch_seconds REAL,notes TEXT);''')
    return cx


class ReachTest(unittest.TestCase):
    def setUp(self):self.cx=tables()
    def tearDown(self):self.cx.close()

    def sample(self,**kw):
        obj={'channel':'company','title':'CBAM: Lieferkette','published_at':'2026-10-15T08:00:00',
             'impressions':107,'comments':5,'reactions':7}
        obj.update(kw)
        return obj

    def test_manual_comments_not_automatically_classified(self):
        save_post_observation(self.cx,self.sample())
        post=reach_monitor(self.cx)['posts'][0]
        self.assertEqual(post['latest']['comments'],5)
        self.assertIsNone(post['latest']['substantive_comments'])
        self.assertIsNone(post['latest']['new_participants'])
        self.assertIn('Ein einzelner Datenstand',post['diagnosis']['detail'] if post['latest']['impressions']>=100 else 'Ein einzelner Datenstand')

    def test_discussion_stalled_reach_only_with_two_observations(self):
        save_post_observation(self.cx,self.sample(observed_at='2026-10-15T10:00:00+02:00',comments=2))
        save_post_observation(self.cx,self.sample(observed_at='2026-10-15T14:00:00+02:00',comments=5,substantive_comments=3,new_participants=2))
        post=reach_monitor(self.cx)['posts'][0]
        self.assertEqual(post['latest']['substantive_comments'],3)
        self.assertEqual(post['latest']['new_participants'],2)
        self.assertEqual(post['diagnosis']['level'],'watch')
        self.assertIn('keine zusätzlichen Impressionen',post['diagnosis']['detail'])

    def test_actual_growth_no_penalty_invented(self):
        save_post_observation(self.cx,self.sample(impressions=107,observed_at='2026-10-15T10:00:00+02:00'))
        save_post_observation(self.cx,self.sample(impressions=208,observed_at='2026-10-15T20:00:00+02:00'))
        self.assertIn('101 zusätzliche Impressionen',reach_monitor(self.cx)['posts'][0]['diagnosis']['detail'])

    def test_optional_fields_not_assumed_zero(self):
        save_post_observation(self.cx,self.sample(comments=None,reactions=None))
        post=reach_monitor(self.cx)['posts'][0]
        self.assertIsNone(post['latest']['comments'])
        self.assertIsNone(post['latest']['reactions'])

    def test_reject_fake_metadata(self):
        bad=[{'substantive_comments':6},{'new_participants':6},{'impressions':-1},
             {'url':'https://malware.invalid/posts/abc'},
             {'url':'javascript:alert(1)'}]
        for case in bad:
            with self.subTest(case=case),self.assertRaises(ValueError):
                save_post_observation(self.cx,self.sample(**case))

    def test_same_post_across_host_aliases_and_delete(self):
        r1=save_post_observation(self.cx,self.sample(url='https://www.linkedin.com/posts/something',impressions=2))
        r2=save_post_observation(self.cx,self.sample(url='https://linkedin.com/posts/something?trackingid=123',impressions=8))
        self.assertEqual(r1['post_key'],r2['post_key'])
        self.assertEqual(reach_monitor(self.cx)['total_posts'],1)
        self.assertTrue(delete_post_observation(self.cx,r1['id']))
        self.assertEqual(reach_monitor(self.cx)['posts'][0]['measurements'],1)

    def test_no_old_data_modified(self):
        save_post_observation(self.cx,self.sample())
        self.assertEqual(self.cx.execute('select count(*) from post_observations').fetchone()[0],1)

    def test_xlsx_minimal_file_no_external_libs(self):
        workbook='''<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Beitragsanalysen" sheetId="1" r:id="rId1"/></sheets></workbook>'''
        rel='''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml"/></Relationships>'''
        rows=[('URL des Beitrags','https://www.linkedin.com/posts/example'),('Veröffentlicht am','16.10.2026'),('Uhrzeit für die Veröffentlichung des Beitrags','07:30'),('Impressions','37'),('Erreichte Mitglieder','27'),('Kommentare','0'),('Gespeicherte Beiträge','1')]
        s='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
        for i,(a,b) in enumerate(rows,1):
            s+=f'<row r="{i}"><c r="A{i}" t="inlineStr"><is><t>{a}</t></is></c><c r="B{i}" t="inlineStr"><is><t>{b}</t></is></c></row>'
        s+='</sheetData></worksheet>'
        dest=io.BytesIO()
        with zipfile.ZipFile(dest,'w') as z:
            z.writestr('xl/workbook.xml',workbook)
            z.writestr('xl/_rels/workbook.xml.rels',rel)
            z.writestr('xl/worksheets/sheet1.xml',s)
        item=parse_linkedin_post_analytics_xlsx(dest.getvalue())
        self.assertEqual(item['impressions'],37)
        self.assertEqual(item['saves'],1)
        self.assertEqual(item['comments'],0)
        self.assertIsNone(item['reactions'])
        self.assertIsNone(item.get('substantive_comments'))




class DistributionSmokeTest(unittest.TestCase):
    def test_importable_and_version(self):
        import advisory, updater, server
        self.assertEqual(updater.local_version(), "2.9.5")

class SourceAuditTest(unittest.TestCase):
    """Synthetic source coverage tests; no private LinkedIn data in fixtures."""
    def setUp(self):
        from storage import db
        import tempfile, os
        self.tmp=tempfile.TemporaryDirectory()
        import storage
        self.old_path=storage.DB_PATH
        storage.DB_PATH=__import__('pathlib').Path(self.tmp.name)/'test.sqlite'
        self.cx=db()
        from storage import new_snapshot,put_data
        a=new_snapshot(self.cx,'api','API');z=new_snapshot(self.cx,'zip','ZIP')
        put_data(self.cx,a,'ENDORSEMENTS',[
            {'Endorser First Name':'Jane','Endorser Public Url':'https://sample.invalid/jane','Skill Name':'ESG'},
            {'Endorsee First Name':'John','Endorsee Public Url':'https://sample.invalid/john','Skill Name':'ESG'}])
        put_data(self.cx,z,'ENDORSEMENTS',[
            {'Endorser First Name':'Jane','Endorser Public Url':'https://sample.invalid/jane','Skill Name':'ESG'}])
        put_data(self.cx,a,'POSITIONS',[{'Title':'Berater','Started On':'2010-01'}])
        put_data(self.cx,z,'POSITIONS',[{'Title':'Berater','Started On':'2010-01'}])
        put_data(self.cx,a,'ALL_COMMENTS',[{'Message':'secret one'},{'Message':'secret two'}])
        put_data(self.cx,z,'ALL_COMMENTS',[{'Message':'secret one'},{'Message':'secret three'}])
        self.cx.execute('INSERT INTO scores VALUES (?,?,?,?,?,?)',(z,'Credibility','EU Compliance','Tenure and experience','2026-10-15',4.0))
        self.cx.commit()
    def tearDown(self):
        self.cx.close();self.tmp.cleanup()
        import storage
        storage.DB_PATH=self.old_path
    def test_comparison_direction_and_no_secrets(self):
        from analytics import source_audit
        result=source_audit(self.cx)
        indexed={d['domain']:d for d in result['domains']}
        self.assertEqual(indexed['ENDORSEMENTS']['api']['received'],1)
        self.assertEqual(indexed['ENDORSEMENTS']['api']['given'],1)
        self.assertEqual(indexed['ENDORSEMENTS']['zip']['received'],1)
        self.assertEqual(indexed['ENDORSEMENTS']['strict_overlap'],1)
        self.assertEqual(indexed['POSITIONS']['status'],'same')
        self.assertEqual(indexed['ALL_COMMENTS']['strict_overlap'],1)
        self.assertEqual(indexed['ALL_COMMENTS']['api_only'],1)
        self.assertEqual(indexed['ALL_COMMENTS']['zip_only'],1)
        self.assertEqual(result['scores']['latest_measured_at'],'2026-10-15')
        output=json.dumps(result)
        for secret in ('secret one','secret two','secret three','sample.invalid','Jane','John'):
            self.assertNotIn(secret,output)
    def test_snapshot_boundary(self):
        from analytics import source_audit
        result=source_audit(self.cx,until=1)
        indexed={d['domain']:d for d in result['domains']}
        self.assertEqual(indexed['ENDORSEMENTS']['status'],'only_api')
        self.assertIsNone(result['scores']['latest_measured_at'])


class PersonalAggregateV293Test(unittest.TestCase):
    """Generated test files only. No user export packaged into distribution."""
    def setUp(self):
        import tempfile
        import storage
        from pathlib import Path
        self.temp=tempfile.TemporaryDirectory()
        self.old=storage.DB_PATH
        storage.DB_PATH=Path(self.temp.name)/'test.db'
        self.storage=storage
        self.cx=storage.db()
    def tearDown(self):
        self.cx.close()
        self.storage.DB_PATH=self.old
        self.temp.cleanup()

    @staticmethod
    def fixture(impression_day=100,include_bad_post_video=False):
        import html
        ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
        rns='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
        sheets={
         'AUFFINDBARKEIT':[['Performance insgesamt','20.10.2026 bis 21.10.2026'],
                           ['Impressions',str(impression_day+50)],['Erreichte Mitglieder','60']],
         'ENGAGEMENT':[['Datum','Impressions','Engagement'],
                       ['20.10.2026',str(impression_day),'6'],['21.10.2026','50','8']],
         'FOLLOWER_INNEN':[['Follower:innen insgesamt am 21.10.2026:','500'],
                           ['Datum','Neue Follower:innen'],['20.10.2026','8'],['21.10.2026','2']],
         'NEUESTE BEITRÄGE':[['URL des Beitrags','Beitrag veröffentlicht am','Art des Beitrags','Impressions','Erreichte Mitglieder','Aufrufe'],
                             ['https://www.linkedin.com/posts/synthetic','20.10.2026','Bild','100','70','49']]}
        def letters(n):
            x=''
            while n:n,m=divmod(n-1,26);x=chr(65+m)+x
            return x
        dest=io.BytesIO()
        with zipfile.ZipFile(dest,'w') as z:
            workbook=f'<workbook xmlns="{ns}" xmlns:r="{rns}"><sheets>'
            rels='<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            for idx,(name,rows) in enumerate(sheets.items(),1):
                workbook+=f'<sheet name="{name}" sheetId="{idx}" r:id="rId{idx}"/>'
                rels+=f'<Relationship Id="rId{idx}" Target="worksheets/sheet{idx}.xml"/>'
                xml=f'<worksheet xmlns="{ns}"><sheetData>'
                for i,row in enumerate(rows,1):
                    xml+=f'<row r="{i}">'
                    for j,val in enumerate(row,1):
                        addr=letters(j)+str(i)
                        xml+=f'<c r="{addr}" t="inlineStr"><is><t>{html.escape(val)}</t></is></c>'
                    xml+='</row>'
                xml+='</sheetData></worksheet>'
                z.writestr(f'xl/worksheets/sheet{idx}.xml',xml)
            z.writestr('xl/workbook.xml',workbook+'</sheets></workbook>')
            z.writestr('xl/_rels/workbook.xml.rels',rels+'</Relationships>')
        return dest.getvalue()

    def test_daily_import_no_double_count_no_image_video(self):
        from analytics import save_personal_aggregate,personal_aggregate_report
        from ingest import parse_personal_aggregate_xlsx
        first=parse_personal_aggregate_xlsx(self.fixture(100),'AggregateAnalytics.xlsx')
        later=parse_personal_aggregate_xlsx(self.fixture(130),'AggregateAnalytics.xlsx')
        self.assertIsNone(first['posts'][0]['video_views'])
        self.assertEqual(save_personal_aggregate(self.cx,first)['days'],2)
        self.assertTrue(save_personal_aggregate(self.cx,first)['duplicate_file'])
        self.assertFalse(save_personal_aggregate(self.cx,later)['duplicate_file'])
        view=personal_aggregate_report(self.cx)
        self.assertEqual(view['import_count'],2)
        self.assertEqual(view['daily'][0]['impressions'],130)
        self.assertEqual(view['daily'][1]['impressions'],50)
        self.assertEqual(len(view['daily']),2)
        self.assertEqual(view['latest_summary']['total_followers'],500)
        self.assertEqual(self.cx.execute('SELECT COUNT(*) FROM post_observations').fetchone()[0],0)

    def test_annotations_persist_without_touching_observations(self):
        from analytics import save_post_observation,save_post_context,reach_monitor
        obj={'channel':'private','title':'PPWR Abstimmung','published_at':'2026-10-20T07:26',
             'impressions':356,'url':'https://www.linkedin.com/posts/synthetic'}
        info=save_post_observation(self.cx,obj)
        key=info['post_key']
        save_post_context(self.cx,{'channel':'private','post_key':key,'stage':'preview',
                                   'series':'PPWR-Abstimmung 20.10.2026','context_note':'Vorab-Szenarien'})
        report=reach_monitor(self.cx)
        self.assertEqual(report['posts'][0]['editorial']['stage'],'preview')
        self.assertEqual(report['posts'][0]['editorial']['series'],'PPWR-Abstimmung 20.10.2026')
        self.assertEqual(report['posts'][0]['latest']['impressions'],356)
        with self.assertRaises(ValueError):
            save_post_context(self.cx,{'channel':'private','post_key':key,'stage':'algorithm_bonus'})
        with self.assertRaises(ValueError):
            save_post_context(self.cx,{'channel':'private','post_key':'0'*28,'stage':'preview'})

    def test_import_without_valid_structure_fails(self):
        from ingest import parse_personal_aggregate_xlsx
        with self.assertRaises(ValueError):
            parse_personal_aggregate_xlsx(b'not an xlsx','AggregateAnalytics.xlsx')
