"""Local SQLite snapshot store. Secrets are never stored here."""
from __future__ import annotations
import json, os, sqlite3, time, gzip, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('LI_DB_PATH', ROOT / 'data' / 'linkedin.db')).expanduser()


def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    cx = sqlite3.connect(DB_PATH)
    cx.row_factory = sqlite3.Row
    cx.execute('PRAGMA journal_mode=WAL')
    cx.execute('PRAGMA foreign_keys=ON')
    cx.executescript('''
        CREATE TABLE IF NOT EXISTS snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT NOT NULL, label TEXT NOT NULL, imported_at TEXT NOT NULL,
            reference_date TEXT, note TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS datasets (
            snapshot_id INTEGER NOT NULL REFERENCES snapshots(id) ON DELETE CASCADE,
            domain TEXT NOT NULL, payload TEXT NOT NULL,
            PRIMARY KEY(snapshot_id,domain)
        );
        CREATE TABLE IF NOT EXISTS scores (
            snapshot_id INTEGER NOT NULL REFERENCES snapshots(id) ON DELETE CASCADE,
            score_type TEXT NOT NULL, topic TEXT NOT NULL, category TEXT NOT NULL,
            measured_at TEXT NOT NULL, value REAL NOT NULL,
            PRIMARY KEY(snapshot_id,score_type,topic,category,measured_at)
        );
        CREATE TABLE IF NOT EXISTS change_events (
            event_id TEXT PRIMARY KEY, event_time TEXT, resource TEXT, method TEXT,
            summary TEXT, captured_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS change_event_payloads (
            event_id TEXT PRIMARY KEY REFERENCES change_events(event_id) ON DELETE CASCADE,
            payload TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_scores_date ON scores(measured_at);
        CREATE TABLE IF NOT EXISTS post_observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            channel TEXT NOT NULL CHECK(channel IN ('private','company')),
            post_key TEXT NOT NULL,
            post_url TEXT NOT NULL DEFAULT '',
            title TEXT NOT NULL DEFAULT '',
            published_at TEXT NOT NULL DEFAULT '',
            observed_at TEXT NOT NULL,
            source TEXT NOT NULL CHECK(source IN ('manual','linkedin_xlsx')),
            impressions INTEGER NOT NULL CHECK(impressions>=0),
            reach INTEGER CHECK(reach IS NULL OR reach>=0),
            reactions INTEGER CHECK(reactions IS NULL OR reactions>=0),
            comments INTEGER CHECK(comments IS NULL OR comments>=0),
            reposts INTEGER CHECK(reposts IS NULL OR reposts>=0),
            saves INTEGER CHECK(saves IS NULL OR saves>=0),
            clicks INTEGER CHECK(clicks IS NULL OR clicks>=0),
            video_views INTEGER CHECK(video_views IS NULL OR video_views>=0),
            avg_watch_seconds REAL CHECK(avg_watch_seconds IS NULL OR avg_watch_seconds>=0),
            substantive_comments INTEGER CHECK(substantive_comments IS NULL OR substantive_comments>=0),
            new_participants INTEGER CHECK(new_participants IS NULL OR new_participants>=0),
            own_comments INTEGER CHECK(own_comments IS NULL OR own_comments>=0),
            notes TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_post_observations_key ON post_observations(channel,post_key,observed_at);
        CREATE TABLE IF NOT EXISTS api_raw_archives (
            snapshot_id INTEGER NOT NULL REFERENCES snapshots(id) ON DELETE CASCADE,
            domain TEXT NOT NULL, sha256 TEXT NOT NULL,
            raw_records INTEGER NOT NULL, effective_records INTEGER NOT NULL,
            packed_bytes INTEGER NOT NULL,
            PRIMARY KEY(snapshot_id,domain)
        );
        CREATE TABLE IF NOT EXISTS company_imports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sha256 TEXT NOT NULL UNIQUE,
            filename TEXT NOT NULL, imported_at TEXT NOT NULL,
            payload TEXT NOT NULL, warnings_json TEXT NOT NULL DEFAULT '[]'
        );
        CREATE TABLE IF NOT EXISTS personal_aggregate_imports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sha256 TEXT NOT NULL UNIQUE,
            filename TEXT NOT NULL,
            imported_at TEXT NOT NULL,
            period_start TEXT NOT NULL,
            period_end TEXT NOT NULL,
            payload TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS post_editorial_context (
            channel TEXT NOT NULL CHECK(channel IN ('private','company')),
            post_key TEXT NOT NULL,
            stage TEXT NOT NULL DEFAULT 'unknown',
            series TEXT NOT NULL DEFAULT '',
            context_note TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL,
            PRIMARY KEY(channel,post_key)
        );
        CREATE TABLE IF NOT EXISTS sync_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            executed_at TEXT NOT NULL, requested INTEGER NOT NULL,
            statuses_json TEXT NOT NULL
        );
    ''')
    cx.commit()
    return cx


def new_snapshot(cx, source, label, reference_date='', note=''):
    cx.execute('INSERT INTO snapshots(source,label,imported_at,reference_date,note) VALUES(?,?,?,?,?)',
               (source,label,time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),reference_date,note))
    return cx.execute('SELECT last_insert_rowid()').fetchone()[0]


def put_data(cx, sid, domain, rows):
    cx.execute('INSERT OR REPLACE INTO datasets VALUES (?,?,?)',
               (sid, domain.upper(), json.dumps(rows, ensure_ascii=False, separators=(',',':'))))


def get_data(cx, sid, domain):
    r=cx.execute('SELECT payload FROM datasets WHERE snapshot_id=? AND domain=?', (sid,domain.upper())).fetchone()
    return json.loads(r['payload']) if r else []


def snapshot_list(cx):
    return [dict(r) for r in cx.execute('SELECT * FROM snapshots ORDER BY id DESC')]


def latest_domain(cx, domain, until=None):
    sql='SELECT d.payload FROM datasets d JOIN snapshots s ON s.id=d.snapshot_id WHERE d.domain=?'
    params=[domain.upper()]
    if until is not None:
        sql+=' AND s.id<=?'
        params.append(int(until))
    sql+=' ORDER BY s.id DESC LIMIT 1'
    r=cx.execute(sql,params).fetchone()
    return json.loads(r['payload']) if r else []


def scores_history(cx, until=None):
    """Unique time-series keyed by exact topic and dimension, newest import wins."""
    sql='SELECT score_type,topic,category,measured_at,value,snapshot_id FROM scores'
    params=[]
    if until is not None:
        sql+=' WHERE snapshot_id<=?'
        params=[int(until)]
    sql+=' ORDER BY snapshot_id DESC'
    seen=set(); result=[]
    for r in cx.execute(sql,params):
        key=(r['score_type'],r['topic'],r['category'],r['measured_at'])
        if key in seen: continue
        seen.add(key); result.append(dict(r))
    return result


def put_api_data(cx, sid, domain, records):
    """Keep an exact compressed raw copy; database works on unique full-record matches.

    Retains original page order and every duplicate in local data/api_raw. Identical
    original payloads across snapshots use one content-addressed compressed file.
    No previous data is modified; archives can be recovered with get_data(raw=True).
    """
    if not isinstance(records,list):
        put_data(cx,sid,domain,records)
        return {'raw_records':1,'effective_records':1,'packed_bytes':0}
    from advisory import distinct_rows
    raw=json.dumps(records,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    digest=hashlib.sha256(raw).hexdigest()
    out=ROOT/'data'/'api_raw'/ (digest+'.json.gz')
    out.parent.mkdir(parents=True,exist_ok=True)
    if not out.exists():
        import tempfile
        # Safe atomic write, no overwrite when a content-addressed archive exists.
        with tempfile.NamedTemporaryFile(dir=out.parent,prefix='.incoming-',delete=False) as tf:
            temporary=Path(tf.name)
            try:
                tf.write(gzip.compress(raw,compresslevel=9,mtime=0))
            except Exception:
                temporary.unlink(missing_ok=True)
                raise
        temporary.replace(out)
    compact=distinct_rows(records)
    put_data(cx,sid,domain,compact)
    cx.execute('INSERT INTO api_raw_archives VALUES (?,?,?,?,?,?)',
               (sid,domain.upper(),digest,len(records),len(compact),out.stat().st_size))
    return {'raw_records':len(records),'effective_records':len(compact),
            'packed_bytes':out.stat().st_size,'sha256':digest}


def latest_domain_record(cx,domain,until=None):
    sql=('SELECT d.snapshot_id,d.domain,d.payload FROM datasets d '
         'JOIN snapshots s ON s.id=d.snapshot_id WHERE d.domain=?')
    args=[domain.upper()]
    if until is not None:sql+=' AND s.id<=?';args.append(int(until))
    sql+=' ORDER BY s.id DESC LIMIT 1'
    return cx.execute(sql,args).fetchone()


def get_raw_domain(cx,domain,until=None):
    """Retrieve exact original data where archived, original legacy JSON otherwise."""
    row=latest_domain_record(cx,domain,until)
    if row is None:return None
    archive=cx.execute('SELECT sha256 FROM api_raw_archives WHERE snapshot_id=? AND domain=?',
                       (row['snapshot_id'],domain.upper())).fetchone()
    if not archive:return json.loads(row['payload'])
    compressed=ROOT/'data'/'api_raw'/(archive['sha256']+'.json.gz')
    if not compressed.is_file():raise RuntimeError('Originalarchiv fehlt: '+domain)
    # 250 MB decompressed ceiling protects against corrupted compression bombs.
    with gzip.open(compressed,'rb') as z:
        payload=z.read(250*1024*1024+1)
    if len(payload)>250*1024*1024:raise RuntimeError('Rohdatenarchiv zu groß.')
    if hashlib.sha256(payload).hexdigest()!=archive['sha256']:
        raise RuntimeError('Rohdatenarchiv beschädigt: '+domain)
    return json.loads(payload)


def storage_health(cx):
    """Statistics only; do not read private payloads or change historic snapshots."""
    database=DB_PATH.stat().st_size if DB_PATH.exists() else 0
    wal=Path(str(DB_PATH)+'-wal')
    if wal.exists():database+=wal.stat().st_size
    row=cx.execute('SELECT count(*) n,coalesce(sum(packed_bytes),0) bytes, '
                   'coalesce(sum(raw_records-effective_records),0) duplicates FROM api_raw_archives').fetchone()
    distinct_files=list((ROOT/'data'/'api_raw').glob('*.json.gz')) if (ROOT/'data'/'api_raw').exists() else []
    return {'db_bytes':database,'archived_payloads':row['n'],
            'archived_raw_bytes':sum(x.stat().st_size for x in distinct_files),
            'archived_exact_duplicates':row['duplicates'],
            'files_on_disk':len(distinct_files),
            'legacy_snapshots_untouched':True}


def optimize_legacy_api_snapshots(cx):
    """Explicitly requested lossless compaction of legacy API snapshot duplicates.

    Preconditions: make a complete SQLite backup via SQLite backup API.
    Original order/duplicates remain in content-addressed local gzip files and
    are returned on raw download. ZIP-origin records are never modified.
    Do not remove any old snapshots, scores or user-provided company exports.
    """
    pending=cx.execute('''SELECT count(*) FROM datasets d JOIN snapshots s ON s.id=d.snapshot_id
                          WHERE s.source='api' AND NOT EXISTS
                            (SELECT 1 FROM api_raw_archives a WHERE a.snapshot_id=d.snapshot_id AND a.domain=d.domain)''').fetchone()[0]
    if pending==0:
        return {'checked':0,'compacted':0,'duplicates_archived':0,'backup':None,'message':'Keine älteren API-Datensätze zur Optimierung vorhanden.'}
    backup_dir=ROOT/'data'/'backups'
    backup_dir.mkdir(parents=True,exist_ok=True)
    import datetime as _dt
    now=_dt.datetime.now(_dt.timezone.utc).strftime('%Y%m%d-%H%M%S')
    destination=backup_dir/('linkedin-before-compaction-'+now+'.sqlite3')
    if destination.exists():raise RuntimeError('Backupname bereits vorhanden. Bitte erneut versuchen.')
    with sqlite3.connect(destination) as backup_cx:
        cx.backup(backup_cx)
        result=backup_cx.execute('PRAGMA integrity_check').fetchone()[0]
        if result!='ok':
            destination.unlink(missing_ok=True)
            raise RuntimeError('SQLite-Datensicherung hat Integritätsfehler.')
    before=DB_PATH.stat().st_size if DB_PATH.exists() else 0
    records=cx.execute('''SELECT d.snapshot_id,d.domain,d.payload FROM datasets d
        JOIN snapshots s ON s.id=d.snapshot_id WHERE s.source='api' AND NOT EXISTS
        (SELECT 1 FROM api_raw_archives a WHERE a.snapshot_id=d.snapshot_id AND a.domain=d.domain)
        ORDER BY d.snapshot_id,d.domain''').fetchall()
    count=0;removed=0
    for rec in records:
        value=json.loads(rec['payload'])
        if not isinstance(value,list):continue
        from advisory import distinct_rows
        unique=distinct_rows(value)
        if len(unique)==len(value):continue
        # put_api_data writes raw archive before replacing the stored working copy.
        put_api_data(cx,rec['snapshot_id'],rec['domain'],value)
        count+=1;removed+=len(value)-len(unique)
    cx.commit()
    if count:
        cx.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        cx.execute('VACUUM')
    after=DB_PATH.stat().st_size if DB_PATH.exists() else 0
    return {'checked':len(records),'compacted':count,'duplicates_archived':removed,
            'backup':str(destination),'backup_bytes':destination.stat().st_size,
            'db_bytes_before':before,'db_bytes_after':after,
            'method':'Originale gzip-archiviert; SQLite gesichert; keine Snapshots oder Scores gelöscht.'}
