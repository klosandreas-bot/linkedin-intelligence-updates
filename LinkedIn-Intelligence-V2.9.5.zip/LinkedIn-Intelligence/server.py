"""Loopback-only dashboard. No external dependencies. Local writes require a custom header."""
from __future__ import annotations
import json, mimetypes, socket, threading, webbrowser
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from storage import db,snapshot_list,latest_domain,get_raw_domain,storage_health,optimize_legacy_api_snapshots
from ingest import load_zip
from analytics import overview,reach_monitor,save_post_observation,delete_post_observation,company_page_report,save_company_export,source_audit
from cli import sync,report

ROOT=Path(__file__).resolve().parent
MAX_UPLOAD=250*1024*1024

class Handler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args):
        # Avoid logging request bodies or tokens
        print('[Dashboard]',fmt%args)
    def respond(self,status,content,typ='application/json; charset=utf-8',attachment=None):
        if isinstance(content,(dict,list)):content=json.dumps(content,ensure_ascii=False).encode('utf-8')
        elif isinstance(content,str):content=content.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type',typ)
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'self'")
        if attachment:self.send_header('Content-Disposition','attachment; filename="'+attachment+'"')
        self.send_header('Content-Length',str(len(content)))
        self.end_headers();self.wfile.write(content)
    def bad_host(self):
        return self.headers.get('Host','').split(':')[0].lower() not in ('127.0.0.1','localhost')
    def do_GET(self):
        if self.bad_host():return self.respond(403,{'error':'Nur localhost.'})
        route=urlsplit(self.path).path
        query=parse_qs(urlsplit(self.path).query)
        if route=='/api/extended-report':
            from analytics import extended_content_report
            try:
                until=int(query['snapshot'][0]) if query.get('snapshot') else None
                include_text=(query.get('full') or ['1'])[0]=='1'
                with db() as cx: data=extended_content_report(cx,until,include_text)
                attachment='linkedin-extended-report.json' if (query.get('download') or ['0'])[0]=='1' else None
                return self.respond(200,data,attachment=attachment)
            except (ValueError,TypeError) as exc:return self.respond(400,{'error':str(exc)})
        if route=='/api/personal-aggregate':
            from analytics import personal_aggregate_report
            with db() as cx:data=personal_aggregate_report(cx)
            return self.respond(200,data)
        if route=='/api/company':
            with db() as cx:result=company_page_report(cx)
            return self.respond(200,result)
        if route=='/api/reach':
            with db() as cx: data=reach_monitor(cx)
            return self.respond(200,data)
        if route=='/api/version':
            from updater import local_version
            return self.respond(200,{'version':local_version(ROOT)})
        if route=='/api/data':
            try:
                until=int(query['snapshot'][0]) if query.get('snapshot') else None
                with db() as cx:data=overview(cx,until)
                return self.respond(200,data)
            except Exception as e:return self.respond(400,{'error':str(e)})
        if route=='/api/api-retry-plan':
            from cli import failed_domains_from_history
            with db() as cx: domains=failed_domains_from_history(cx)
            return self.respond(200,{'domains':domains,'count':len(domains)})
        if route=='/api/diagnostics':
            with db() as cx:
                last=cx.execute('SELECT executed_at,requested,statuses_json FROM sync_runs ORDER BY id DESC LIMIT 1').fetchone()
                by_source={}
                for r in cx.execute("""SELECT s.source AS source,d.domain AS domain,d.payload AS payload
                                     FROM datasets d JOIN snapshots s ON d.snapshot_id=s.id
                                     WHERE s.id IN (SELECT max(s2.id) FROM datasets d2 JOIN snapshots s2 ON d2.snapshot_id=s2.id
                                                    WHERE s2.source=s.source AND d2.domain=d.domain)"""):
                    try:
                        val=json.loads(r['payload']);count=len(val) if isinstance(val,list) else 1
                    except ValueError:count=None
                    by_source.setdefault(r['source'],{})[r['domain']]=count
                if last:
                    detail=json.loads(last['statuses_json'])
                    status=detail.get('domains',detail)
                    auth=detail.get('authorization',{'state':'not_checked'})
                    summary={
                        'ready':sum(v.get('state')=='ready' or v.get('rows',0)>0 for v in status.values()),
                        'not_yet_available_or_empty':sum(v.get('state')=='not_yet_available_or_empty' or (v.get('rows',0)==0 and 'nicht verfügbar' in v.get('message','')) for v in status.values()),
                        'errors':sum(v.get('state') in ('http_error','error') or 'HTTP ' in v.get('message','') for v in status.values()),
                    }
                    last_sync={'executed_at':last['executed_at'],'requested':last['requested'],
                               'authorization':auth,'summary':summary,'domains':status}
                else:last_sync=None
            return self.respond(200,{'last_sync':last_sync,'inventory_by_source':by_source})
        if route=='/api/source-audit':
            try:
                until=int(query['snapshot'][0]) if query.get('snapshot') else None
                with db() as cx:data=source_audit(cx,until)
                return self.respond(200,data)
            except (ValueError,TypeError) as exc:return self.respond(400,{'error':str(exc)})
        if route=='/api/storage':
            with db() as cx:data=storage_health(cx)
            return self.respond(200,data)
        if route=='/api/domains':
            from analytics import data_inventory
            until=int(query['snapshot'][0]) if query.get('snapshot') else None
            with db() as cx:
                records=data_inventory(cx,until)
            return self.respond(200,{'domains':records,'total_domains':len(records)})
        if route=='/api/raw':
            domain=(query.get('domain') or [''])[0]
            if not domain or len(domain)>250 or any(c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_' for c in domain):
                return self.respond(400,{'error':'Ungültiger Datenbereich.'})
            until=int(query['snapshot'][0]) if query.get('snapshot') else None
            with db() as cx:
                params=(domain,int(until)) if until is not None else (domain,)
                exists=cx.execute('SELECT 1 FROM datasets WHERE domain=?'+(' AND snapshot_id<=?' if until is not None else '')+' LIMIT 1',params).fetchone()
                rows=get_raw_domain(cx,domain,until)
            if not exists:return self.respond(404,{'error':'Datenbereich nicht vorhanden.'})
            return self.respond(200,{'domain':domain,'records':rows},attachment='linkedin-'+domain.lower()+'.json')
        if route=='/api/export':
            generated=report()
            return self.respond(200,Path(generated).read_bytes(),attachment='linkedin-kuratierter-bericht.json')
        if route=='/' or route in ('/index.html','/app.js','/style.css'):
            path=ROOT/'static'/(route.strip('/') or 'index.html')
            if path.is_file():
                typ=mimetypes.guess_type(str(path))[0] or 'application/octet-stream'
                return self.respond(200,path.read_bytes(),typ)
        self.respond(404,{'error':'Not found'})
    def do_POST(self):
        if self.bad_host() or self.headers.get('X-Local-App')!='1':
            return self.respond(403,{'error':'Lokaler Schreibschutz aktiv.'})
        route=urlsplit(self.path).path
        try:
            count=int(self.headers.get('Content-Length','0'))
            if count<1 or count>MAX_UPLOAD:return self.respond(413,{'error':'Anfrage zu groß oder leer.'})
            if route in ('/api/reach/import','/api/company/import','/api/personal-aggregate/import') and count>15*1024*1024:
                return self.respond(413,{'error':'Excel-Datei darf höchstens 15 MB groß sein.'})
            raw=self.rfile.read(count)
            if route=='/api/personal-aggregate/import':
                from ingest import parse_personal_aggregate_xlsx
                from analytics import save_personal_aggregate
                from urllib.parse import unquote
                name=unquote(self.headers.get('X-Filename','').strip())[:180]
                export=parse_personal_aggregate_xlsx(raw,name)
                with db() as cx:result=save_personal_aggregate(cx,export)
                return self.respond(200,result)
            if route=='/api/reach/context':
                from analytics import save_post_context
                if count>1200:raise ValueError('Kontextangaben zu groß.')
                body=json.loads(raw)
                with db() as cx:result=save_post_context(cx,body)
                return self.respond(200,result)
            if route=='/api/company/import':
                from ingest import parse_company_analytics_export
                from urllib.parse import unquote
                filename=unquote(self.headers.get('X-Filename','').strip())[:180]
                parsed=parse_company_analytics_export(raw,filename)
                with db() as cx:result=save_company_export(cx,parsed,raw)
                return self.respond(200,result)
            if route=='/api/storage/compact':
                if raw!=b'{"confirm":true}':raise ValueError('Bestätigung zur Optimierung fehlt.')
                with db() as cx:result=optimize_legacy_api_snapshots(cx)
                return self.respond(200,result)
            if route=='/api/reach/import':
                from ingest import parse_linkedin_post_analytics_xlsx
                record=parse_linkedin_post_analytics_xlsx(raw,self.headers.get('X-Channel','private'))
                custom_title=self.headers.get('X-Post-Title','').strip()
                if custom_title:record['title']=custom_title[:240]
                observed=self.headers.get('X-Observed-At','').strip()
                if observed:record['observed_at']=observed
                with db() as cx: data=save_post_observation(cx,record,source='linkedin_xlsx')
                return self.respond(200,{'result':data,'record':record})
            if route=='/api/reach/observe':
                if count>20000:raise ValueError('Messstand ist zu groß.')
                record=json.loads(raw)
                with db() as cx: data=save_post_observation(cx,record)
                return self.respond(200,{'result':data})
            if route=='/api/reach/delete':
                record=json.loads(raw)
                if not isinstance(record,dict) or type(record.get('id')) is not int:
                    raise ValueError('Ungültige Messstand-ID.')
                with db() as cx: deleted=delete_post_observation(cx,record['id'])
                return self.respond(200,{'deleted':deleted})
            if route=='/api/import':
                label=self.headers.get('X-Import-Label','Lokaler ZIP-Import')[:150]
                with db() as cx:data=load_zip(cx,raw,label)
                return self.respond(200,data)
            if route=='/api/sync':
                payload=json.loads(raw)
                from linkedin_api import DEFAULT_DOMAINS
                domains=payload.get('domains')
                if domains is not None:
                    if (not isinstance(domains,list) or not domains or len(domains)!=len(set(str(d) for d in domains))
                            or any(not isinstance(d,str) or d not in DEFAULT_DOMAINS for d in domains)):
                        raise ValueError('Ungültige Datenbereichsliste; nur offizielle Bereiche erlaubt.')
                data=sync(domains,bool(payload.get('changelog',True)))
                return self.respond(200,data)
            if route=='/api/report':
                return self.respond(200,{'path':report()})
            return self.respond(404,{'error':'Unbekannte Aktion'})
        except Exception as e:return self.respond(400,{'error':str(e)[:350]})


def serve(port=8765):
    addr=('127.0.0.1',port)
    app=ThreadingHTTPServer(addr,Handler)
    print(f'LinkedIn Intelligence läuft nur lokal auf http://127.0.0.1:{port}')
    print('Mit Strg+C beenden. Keine Datenübertragung an andere Server außer bei bewusstem API-Abruf.')
    threading.Timer(0.7,lambda:webbrowser.open(f'http://127.0.0.1:{port}')).start()
    try:app.serve_forever()
    except KeyboardInterrupt:pass
    finally:app.server_close()
