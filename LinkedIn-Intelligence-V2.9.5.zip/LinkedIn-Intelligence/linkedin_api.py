"""Official LinkedIn DMA member portability client. No scraping, no password login."""
from __future__ import annotations
import json, os, time, urllib.error, urllib.parse, urllib.request, hashlib

BASE='https://api.linkedin.com/rest/'
VERSION='202312' # LinkedIn explicitly restricts DMA endpoints to this version.
# Complete official snapshot-domain list, 2026-04-15 documentation.
# https://learn.microsoft.com/en-us/linkedin/dma/member-data-portability/shared/snapshot-domain
# Do not silently exclude messages, identity, security, or ads: this is the owner's LOCAL archive.
DEFAULT_DOMAINS = ['ADS_CLICKED', 'MEMBER_FOLLOWING', 'LOGIN', 'RICH_MEDIA', 'SEARCHES', 'INFERENCE_TAKEOUT', 'ALL_COMMENTS', 'CONTACTS', 'EVENTS', 'RECEIPTS', 'AD_TARGETING', 'REGISTRATION', 'REVIEWS', 'ARTICLES', 'PATENTS', 'GROUPS', 'COMPANY_FOLLOWS', 'INVITATIONS', 'PHONE_NUMBERS', 'CONNECTIONS', 'EMAIL_ADDRESSES', 'JOB_POSTINGS', 'JOB_APPLICATIONS', 'JOB_SEEKER_PREFERENCES', 'LEARNING', 'INBOX', 'SAVED_JOBS', 'SAVED_JOB_ALERTS', 'PROFILE', 'SKILLS', 'POSITIONS', 'EDUCATION', 'TEST_SCORES', 'CAUSES_YOU_CARE_ABOUT', 'PUBLICATIONS', 'PROJECTS', 'ORGANIZATIONS', 'LANGUAGES', 'HONORS', 'COURSES', 'CERTIFICATIONS', 'RECOMMENDATIONS', 'ENDORSEMENTS', 'MEMBER_SHARE_INFO', 'SECURITY_CHALLENGE_PIPE', 'TRUSTED_GRAPH', 'MARKETPLACE_ENGAGEMENTS', 'MARKETPLACE_PROVIDERS', 'MARKETPLACE_OPPORTUNITIES', 'ACTOR_SAVE_ITEM', 'JOB_APPLICANT_SAVED_ANSWERS', 'TALENT_QUESTION_SAVED_RESPONSE', 'PROFILE_SUMMARY', 'ALL_LIKES', 'ALL_VOTES', 'RECEIPTS_LBP', 'EASYAPPLY_BLOCKING', 'LEARNING_COACH_AI_TAKEOUT', 'LEARNING_COACH_INBOX', 'LEARNING_ROLEPLAY_INBOX', 'VOLUNTEERING_EXPERIENCES', 'ACCOUNT_HISTORY', 'INSTANT_REPOSTS', 'IDENTITY_CREDENTIALS_AND_ASSETS', 'ADS_LAN']


def token():
    val=os.environ.get('LINKEDIN_ACCESS_TOKEN','').strip()
    if not val: raise RuntimeError('LINKEDIN_ACCESS_TOKEN fehlt. Lokal in .env bzw. bei GitHub als Repository Secret hinterlegen.')
    return val


def call(path, params=None, method='GET', body=None):
    url=BASE+path
    if params:url+='?'+urllib.parse.urlencode(params)
    headers={'Authorization':'Bearer '+token(), 'Linkedin-Version':VERSION,
             'X-Restli-Protocol-Version':'2.0.0','Accept':'application/json',
             'Content-Type':'application/json'}
    data=json.dumps(body).encode() if body is not None else None
    req=urllib.request.Request(url,headers=headers,data=data,method=method)
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req,timeout=40) as r:
                raw=r.read(25*1024*1024+1)
                if len(raw)>25*1024*1024:raise RuntimeError('API-Antwort zu groß')
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            text=e.read(4000).decode('utf-8',errors='replace')
            if e.code in (429,502,503,504) and attempt<2:
                time.sleep(2**attempt*2);continue
            raise APIError(e.code, text[:400]) from None
        except urllib.error.URLError as e:
            raise RuntimeError(f'Netzwerkfehler: {e.reason}') from None


class APIError(Exception):
    def __init__(self,status,message):
        self.status=status; self.message=message
        super().__init__(f'HTTP {status}: {message}')


def authorization_status():
    """Check whether the member actually authorized this developer application.

    Only retain non-sensitive status/timestamps, never member URNs or raw responses.
    """
    try:
        data=call('memberAuthorizations',{'q':'memberAndApplication'})
        elements=data.get('elements',[])
        valid=[e for e in elements if isinstance(e,dict) and 'DMA' in e.get('memberComplianceScopes',[])]
        return {'state':'active' if valid else 'not_confirmed',
                'regulated_at_ms':min((e['regulatedAt'] for e in valid if isinstance(e.get('regulatedAt'),int)),default=None)}
    except APIError as exc:
        return {'state':'http_error','http_status':exc.status,
                'note':('Zugriff verweigert' if exc.status in (401,403) else 'API-Fehler bei Autorisierungsprüfung')}
    except Exception:
        return {'state':'network_error','note':'Autorisierungsprüfung nicht erreichbar'}


class PaginationError(RuntimeError):
    """A snapshot page cannot be trusted. Never import its partial results."""


def _is_terminal_404(exc):
    return (isinstance(exc,APIError) and exc.status==404
            and ('no data found' in exc.message.lower() or 'data not found' in exc.message.lower()))


def _page_items(data, domain):
    if not isinstance(data,dict):
        raise PaginationError(f'{domain}: Unerwartetes Antwortformat (kein JSON-Objekt)')
    elements=data.get('elements',[])
    if isinstance(elements,dict):elements=[elements]
    if not isinstance(elements,list):
        raise PaginationError(f'{domain}: Unerwartetes Antwortformat (elements)')
    output=[]
    for element in elements:
        if not isinstance(element,dict):
            raise PaginationError(f'{domain}: Unerwarteter Seiteneintrag')
        if 'snapshotData' not in element:continue
        chunk=element['snapshotData']
        if isinstance(chunk,list):output.extend(chunk)
        elif chunk is not None:output.append(chunk)
    return output


def fetch_domain(domain,max_pages=500,diagnostic=None):
    """Fetch DMA snapshot page indices 0,1,... until LinkedIn's terminal 404.

    An identical repeated page is *not* assumed to mean end of data. Probe
    exactly one succeeding index; only a terminal 404 or empty response may
    confirm it was a duplicated trailing page. On any ambiguity fail closed,
    preserving the prior successful local snapshot. Diagnostic data is numeric
    metadata only; never record snapshots or tokens in the status report.
    """
    diag=diagnostic if diagnostic is not None else {}
    diag.update(page_requests=0,pages_accepted=0,terminal_reason=None)
    rows=[]
    seen_pages={}

    def request_page(page):
        diag['page_requests']+=1
        diag['last_page_index']=page
        return call('memberSnapshotData',{'q':'criteria','domain':domain,'start':page})

    for page in range(max_pages):
        try:
            data=request_page(page)
        except APIError as exc:
            if _is_terminal_404(exc):
                diag['terminal_reason']='no_data_404'
                return rows, ('not_yet_available_or_empty' if page==0 else None)
            raise
        page_items=_page_items(data,domain)
        if not page_items:
            diag['terminal_reason']='empty_page'
            return rows, ('empty_response' if not rows else None)
        digest=hashlib.sha256(json.dumps(page_items,sort_keys=True,ensure_ascii=False,default=str,separators=(',',':')).encode('utf-8')).hexdigest()
        if digest in seen_pages:
            diag['repeated_page_index']=page
            diag['repeated_original_index']=seen_pages[digest]
            # One bounded, explicit check prevents treating a repeat in the
            # *middle* of a listing as a successful complete download.
            try:
                probe=request_page(page+1)
            except APIError as exc:
                if _is_terminal_404(exc):
                    diag['terminal_reason']='repeated_last_page_verified_by_404'
                    diag['warning']='LinkedIn lieferte die letzte Datenseite doppelt; Folgeseite meldete keine Daten.'
                    return rows,'verified_repeated_terminal'
                raise PaginationError(f'{domain}: Wiederholte Seite {page}; Folgeabruf HTTP {exc.status}, Vollständigkeit unklar') from None
            probe_items=_page_items(probe,domain)
            if not probe_items:
                diag['terminal_reason']='repeated_last_page_verified_by_empty_page'
                diag['warning']='LinkedIn lieferte die letzte Datenseite doppelt; Folgeseite war leer.'
                return rows,'verified_repeated_terminal'
            raise PaginationError(f'{domain}: API-Seite {page} ist identisch mit Seite {seen_pages[digest]}; Folgeseite enthält Daten, Abruf nicht gespeichert')
        seen_pages[digest]=page
        rows.extend(page_items)
        diag['pages_accepted']+=1
    raise PaginationError(f'{domain}: mehr als {max_pages} Seiten; Schutzlimit erreicht')


def fetch_domains(domains=None):
    domains=domains if domains is not None else DEFAULT_DOMAINS
    data={};statuses={}
    for domain in domains:
        started=time.monotonic()
        diag={}
        try:
            rows,note=fetch_domain(domain,diagnostic=diag)
            state=('ready' if rows else ('not_yet_available_or_empty' if note=='not_yet_available_or_empty' else 'empty_response'))
            from advisory import distinct_rows
            effective=len(distinct_rows(rows))
            entry={'state':state,'rows':effective,'raw_rows':len(rows),'exact_duplicates':len(rows)-effective,
                   'message':(f'{effective} eindeutige Datensätze ({len(rows)-effective} exakte Kopien)' if rows else ('LinkedIn meldet: No data found (leer oder noch in Verarbeitung)' if state=='not_yet_available_or_empty' else 'Leere API-Antwort')),
                   'elapsed_seconds':round(time.monotonic()-started,2)}
            entry.update(diag)
            if rows:data[domain]=rows
            statuses[domain]=entry
        except APIError as exc:
            msg=exc.message.lower()
            unsupported=(exc.status==400 and 'not supported' in msg and 'domain' in msg)
            statuses[domain]={'state':'http_error','rows':0,'http_status':exc.status,
                              'error_category':'unsupported_domain' if unsupported else ('authorization' if exc.status in (401,403) else 'http_error'),
                              'message':('LinkedIn unterstützt diesen Datenbereich derzeit nicht (HTTP 400).' if unsupported else 'HTTP '+str(exc.status)+': '+exc.message[:160]),
                              'elapsed_seconds':round(time.monotonic()-started,2),**diag}
        except PaginationError as exc:
            statuses[domain]={'state':'error','error_category':'pagination_incomplete','rows':0,
                              'message':str(exc)[:160],
                              'elapsed_seconds':round(time.monotonic()-started,2),**diag}
        except Exception as exc:
            statuses[domain]={'state':'error','error_category':'unexpected','rows':0,'message':str(exc)[:160],
                              'elapsed_seconds':round(time.monotonic()-started,2),**diag}
    return data,statuses


def fetch_changes(start_ms=None, max_pages=40):
    """Conservative changelog fetching. Deduplicate repeated inclusive timestamp events."""
    unique={}
    cursor=start_ms
    for _ in range(max_pages):
        args={'q':'memberAndApplication','count':50}
        if cursor: args['startTime']=int(cursor)
        data=call('memberChangeLogs',args)
        items=data.get('elements',[])
        if not items:break
        for x in items:
            if isinstance(x,dict): unique[str(x.get('activityId') or x.get('id'))]=x
        times=[int(x['processedAt']) for x in items if x.get('processedAt')]
        if not times:break
        m=max(times)
        if not cursor or m>cursor:cursor=m
        else:break # avoid endless polling of repeated boundary event
        if len(items)<50: break
    return list(unique.values())
