# LinkedIn Intelligence V2.9

Lokales Windows-Dashboard zur Auswertung eigener LinkedIn-Daten. Keine Verbindung zu LinkedIn ohne eigene Autorisierung.

1. Python 3.11 oder neuer installieren.
2. Dieses ZIP in einen eigenen Ordner entpacken.
3. `Start-Dashboard.bat` doppelklicken.
4. Eigenen LinkedIn-ZIP-Export importieren oder den eigenen DMA-API-Zugriff einrichten.
5. Unter „Datenquellen & Abruf“ die Datenstände pro Bereich ansehen.

Seit V2.4 werden bei jedem Start signierte Softwareupdates von GitHub geprüft. Lokale SQLite-Daten, Exporte, Token und persönliche Berichte bleiben unverändert. Für die initiale Installation sind keine fremden Entwicklerzugangsdaten erforderlich.

Neu in V2.7: echte Versionsanzeige aus `version.json`, exakte Dublettenbereinigung bei Kennzahlen, Datenstand pro Bereich mit Quelle und letztem erfolgreichen Import, letzte API-Prüfung separat, Zeitanzeige in MEZ/MESZ sowie die Bezeichnung „Bericht für KI Auswertung / GitHub“.

Eine Zeile wird nur dann bei den Kennzahlen zusammengefasst, wenn ihr JSON-Inhalt vollständig identisch ist. Ähnliche Ereignisse werden nicht allein nach Namen oder Datum zusammengelegt. Originaldateien und gespeicherte Snapshots bleiben vollständig erhalten. Für Kontakte wird die Anzahl unterschiedlicher Kennungen getrennt ausgewiesen.

Scoring-Daten sind interne LinkedIn-Modellwerte, keine veröffentlichten Feed-Rankingfaktoren. Dieses Projekt ist unabhängig von LinkedIn.


## V2.8 – Reichweite & Diskussion

Die neue Seite „Reichweite & Diskussion“ importiert den offiziellen LinkedIn-Einzelbeitrags-Excel-Export (XLSX, Spalten A/B) lokal. Für eigene Unternehmensseitenbeiträge und Screenshots können Messstände manuell erfasst werden. Erfasste Beobachtungen werden separat in der lokalen SQLite-Datenbank gespeichert; die Rohdaten-/API-Snapshots bleiben unverändert.

Erst **zwei Messstände desselben Beitrags** erlauben Aussagen über dessen zeitlichen Verlauf. Die Analyse benennt beobachtete Veränderungen, behauptet aber weder Algorithmus-Sanktionen noch die Ursache einer geringen Ausspielung. Die fachliche Qualität von Kommentaren, die Zahl neuer Diskussionsteilnehmer und eigene Kommentare werden nur bei ausdrücklich erfassten Angaben berücksichtigt. Persönliche Bekanntschaften werden niemals als Gefälligkeitsreaktionen abgewertet.

Die persönliche Member Data Portability API liefert nicht zuverlässig Kommentare anderer Mitglieder unter eigenen Beiträgen und keine allgemeinen Unternehmensseiten-Analysen. Der Monitor versendet keine Messwerte an GitHub; sie sind auch nicht Bestandteil des kuratierten Berichtsexports.


## V2.9 – Unternehmensseite, API-Dubletten und transparente Datenstände

**Unternehmensseite:** Der neue Menüpunkt „Unternehmensseite“ importiert offizielle Seitenanalysen als XLS (altes Excel-Format), XLSX oder CSV. Inhalte/Beiträge, Follower und Besucher können einzeln exportiert und später kombiniert werden. Das Programm nutzt keine fremden Zugangsdaten und keine Unternehmensseiten-API. Es unterstützt eindeutig erkannte Tages- und Beitragskennzahlen; nicht erkannte Tabellen werden gemeldet, nicht mit geratenen Werten ergänzt. Importierte Originaldateien werden nur lokal unter `data/company_exports/` archiviert. Ein identischer Export wird nur einmal importiert; bei überlappenden Zeiträumen ersetzt der jeweils neuere Export den älteren Wert derselben Kennzahl. **Nicht** mehrere Exporte addieren.

Export auf LinkedIn in der Unternehmensseiten-Adminansicht: **Analysen → Inhalte** (oder Besucher/Follower) **→ Exportieren → Zeitraum wählen**. Bei unterschiedlichen Exportformaten kann es nötig sein, Tabellenüberschriften nach einem echten Beispiel gezielt zu ergänzen. Fehlende Tage bleiben unbekannt. Kein pauschaler Ranking- oder Benchmarkvergleich wird behauptet.

**Statusanzeige:** „Letzter API-Lauf“ und der Prüfstatus jedes angefragten Bereichs werden nun auch im lokalen Dashboard tatsächlich mitgesendet. Ein erfolgreicher Import ist von einer erfolglosen erneuten API-Abfrage unterscheidbar. Die lokale MEZ/MESZ-Anzeige bleibt erhalten.

**Dubletten & Speicher:** Bei neuen API-Importen führt nur vollständig gleicher Inhalt zur Deduplizierung der Auswertung. Das ungekürzte Original inklusive aller Zeilen wird lokal unter `data/api_raw/` als SHA-256-verifiziertes gzip-Archiv gespeichert und ist weiterhin als JSON abrufbar. Erkennen wir während der API-Seitennavigation dieselbe ganze Seite erneut, wird der betroffene Bereich als fehlerhaft gemeldet und nicht als unvollständiger neuer Snapshot gespeichert.

**Altbestände optimieren (freiwillig):** Unter „Datenquellen & Abruf → Lokaler Speicher & Dubletten“ steht eine manuell bestätigte verlustfreie Bereinigung vorhandener API-Snapshots. Zuerst entsteht eine vollständige und geprüfte SQLite-Sicherung unter `data/backups/`. Danach werden identische API-Rohzeilen komprimiert archiviert und die gespeicherten Arbeitskopien platzsparend gehalten. Historische Snapshot-IDs, Scores, ZIP-Dateien und sämtliche Unternehmenswerte bleiben erhalten. **Niemals manuell das Verzeichnis `data/` leeren.**

Sicherheit: Originaldateien und Sicherungen bleiben auf dem Rechner. Für den kuratierten KI-Bericht werden keine privaten Unternehmensseitenrohdaten an GitHub oder Dritte übermittelt.


## V2.9.1 – Originaler LinkedIn-Inhalteexport repariert

Der native deutsche XLS-Export der Unternehmensseite wird jetzt mit seinen beiden Blättern
**„Kennzahlen“** und **„Alle Beiträge“** korrekt eingelesen. Erkannt werden die
organischen, gesponserten und gesamten Tageswerte, die individuellen organischen Impressionen,
die Interaktionsrate sowie die Beitragskennzahlen einschließlich der Klickrate. Die
Tagesdaten aus dem LinkedIn-Export stehen im US-Datumsformat Monat/Tag/Jahr;
die Anwendung erkennt dieses Format anhand eindeutiger Tagesangaben. Für europäische
CSV-Formate wird Tag/Monat/Jahr ebenfalls unterstützt.

Ein und derselbe Beitrag wird anhand seines dauerhaften LinkedIn-Links wiedererkannt;
aktualisierte Zahlen ersetzen bei überlappenden Exporten die bisherigen Werte.
Die lesbare Beitragsüberschrift bleibt separat erhalten. „Insgesamt“ darf niemals
mit den bereits darin enthaltenen organischen/gesponserten Zahlen addiert werden.
Vorherige V2.9-Importe anderer Exportformate und persönliche Daten bleiben unberührt.

## V2.9.2 – API-/ZIP-Abgleich und nachvollziehbare Profiländerungen (lokale Testfassung)

Die neue Sektion „API-/ZIP-Quellenabgleich“ in „Datenquellen & Abruf“ vergleicht **pro Datenbereich** den letzten gespeicherten API-Datensatz mit dem letzten gespeicherten ZIP-Datensatz. Sie zeigt Anzahl eindeutiger Datensätze, exakte Überschneidungen, nur in einer Quelle vorhandene Datensätze und abweichende Feldnamen. Alle Daten bleiben lokal. Der Vergleich ist **schreibgeschützt** und verändert weder die alten Snapshots noch die bestehende Auswahl der Anzeigedaten. Eine größere Anzahl bedeutet nicht automatisch eine bessere oder aktuellere Quelle; bei Nachrichten und Kommentaren ist eine automatische Zusammenführung ausdrücklich noch nicht freigegeben.

Erhaltene und vergebene Kenntnisbestätigungen werden innerhalb des API-Bestands gesondert gezählt. ZIP-Dateien können diese Arten in getrennten CSV-Dateien führen. Bei abweichenden Strukturen ist die Schnittmenge nur die Schnittmenge exakt gleicher Datensätze und keine Aussage über die Identität einzelner fachlicher Ereignisse.

Die Seite „Credibility & Notability“ sortiert Fachgebiete nach dem jüngsten tatsächlichen Dimensions-Messdatum. Frühere Bewertungen, die mehr als 14 Tage vor dem letzten **verfügbaren Messdatum** liegen, werden als älter markiert. Dies ist eine rein lokale Darstellungskonvention, kein von LinkedIn bestätigtes Aktualitätskriterium. Ähnlich benannte Fachgebiete werden nicht automatisch verbunden, Score-Import und Score-Messung werden voneinander getrennt.

Die Seite „Profil & Änderungen“ zeigt nachweisbare Änderungen zwischen den jüngsten zwei **inhaltlich unterschiedlichen** gespeicherten Ständen von Ausbildung, Berufsstationen und Profilkenntnissen. Eine Änderung kann nach einem früheren Import stattgefunden haben; ihr exaktes LinkedIn-Änderungsdatum ist damit nicht belegt. Ein Zusammenhang mit späteren Scores wird nicht als Kausalität behandelt.

Die API-Fehler des letzten Laufs bleiben sichtbar; die abrufende LinkedIn-API und ihre Pagination werden in dieser Testfassung **nicht geändert**. Der zweite Teil eines angeforderten vollständigen LinkedIn-Exports kann weitere Dateien enthalten und später nochmals importiert werden.

**Installation als Testfassung:** Die manuelle Aktualisierung enthält nur Programmmodule. Vorher Dashboard und Startfenster schließen, den vollständigen Ordner vorsichtshalber kopieren und die fünf aktualisierten Programmdateien über die bestehende Installation kopieren. `data/`, `reports/`, `.env` und private Exporte bleiben unangetastet. Der GitHub-Updatekanal bleibt bis zu einer gesonderten signierten Freigabe bei V2.9.1.


## V2.9.3 – Privatprofil-Wochenstatistik und Berichterstattungsfolgen

- Im Bereich „Reichweite & Diskussion“ können jetzt `AggregateAnalytics_…xlsx`-Exporte des Privatprofils importiert werden. Neue Exportdateien mit sich überschneidenden Berichtszeiträumen ersetzen die Tageswerte, ohne diese doppelt zu summieren. Die importierten Dateien werden an ihrem SHA-256-Wert eindeutig erkannt.
- Die täglichen Impressionen und Engagement-Ereignisse sowie die tägliche Followerentwicklung werden separat gespeichert; erreichte Personen verschiedener Tage werden nicht addiert.
- Die Übersicht „Neueste Beiträge“ eines Wochenexports ist kein vollständiger Einzelbeitragsverlauf. Diese Angaben werden separat angezeigt und niemals als neue Messstände der Einzelbeiträge gespeichert. Nicht-Video-Formate erhalten keine künstlichen Videoaufrufe.
- Bereits separat erfasste Beiträge können nun manuell als Vorschau, Live-Beobachtung, Ergebnisbericht, fachliche Vertiefung oder Grundlagenbeitrag gekennzeichnet und einer namentlichen Berichterstattungsfolge zugeordnet werden. Die Zuordnung beeinflusst keine Messzahlen und wird nicht automatisch aus Schlagwörtern geschlossen.
- Neu ist eine lokale SQLite-Tabelle für Wochenexporte und eine für redaktionellen Kontext. Beide werden beim ersten Start angelegt. Vor dem Update ist eine Sicherung der Datenbank sinnvoll.
- Dies ist eine lokale Testversion. Der öffentliche, signierte Auto-Updatekanal wird nicht geändert.


## V2.9.4 – Schonender API-Fehlernachabruf und kontrollierte Pagination (lokale Testfassung)

- Neuer Button **„Nur API-Fehler erneut prüfen“** unter „Datenquellen & Abruf“. Er liest ausschließlich den Verlauf der lokalen API-Statusmeldungen, prüft nur aktuell noch fehlerhafte Bereiche und ruft keinen Changelog ab. Ein späterer Schnelltest mit nur vier Bereichen löscht die früheren Fehlerhinweise der anderen Bereiche nicht. Nachweislich von LinkedIn als „domain not supported“ gemeldete Kategorien werden bei weiteren gezielten Wiederholungen übersprungen; bei einem vollständigen Abruf werden weiterhin alle 65 offiziell dokumentierten Bereiche angefragt.
- Die Seitennavigation meldet Anzahl versuchter/akzeptierter Seiten ohne Speicherung personenbezogener Inhaltsteile im Statusprotokoll. Bei einer exakt wiederholten Seite wird **genau eine** weitere Seite als Endkontrolle angefragt. Nur wenn LinkedIn dort nachweislich „No data found“ oder eine leere Antwort liefert, kann die vorhandene Folge mit Warnhinweis übernommen werden. Bei einer belegten Datenfortsetzung oder unklarer Antwort gilt der Abruf weiterhin als unvollständig und wird **nicht** als neuer Snapshot gespeichert.
- Explizit als nicht unterstützt gemeldete HTTP-400-Datenbereiche werden separat bezeichnet, bleiben aber im Fehlerstatus sichtbar. Andere HTTP-400-Fälle bleiben normale Fehler.
- Bekannte Sicherheitsgrenzen, historische Snapshots, lokale Daten, Datenbanken, ZIP-Archive, signierter GitHub-Updatekanal und API-Version 202312 bleiben unverändert. Keine neuen automatischen Jobs. **Kein Live-API-Test ohne OAuth-Token des Nutzers:** Die Offline-Regressionen prüfen lediglich simulierte Antworten. Die tatsächliche Verbesserung muss der nächste gezielte lokale Abruf zeigen.

**Manuelles Update:** Das Dashboard vollständig schließen, den bestehenden Installationsordner sichern und ausschließlich die sechs enthaltenen Anwendungsdateien über die Installation V2.9.3 kopieren. `.env`, `data/` und `reports/` bleiben unberührt. GitHub-Autoupdate weiterhin V2.9.1.
